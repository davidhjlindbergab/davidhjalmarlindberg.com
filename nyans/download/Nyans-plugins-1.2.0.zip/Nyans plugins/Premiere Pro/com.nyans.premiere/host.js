/* Nyans for Premiere Pro: the panel around the app. The app runs in a WebView this script makes; this side speaks to Premiere Pro through
   its UXP API.
   grab: exports the frame under the playhead of the active sequence and hands it to the app.
   apply: writes the baked grade as a .cube LUT and puts Lumetri Color on the clips, with its Look pointed at the LUT wherever Premiere's
   API takes a path for it (otherwise the LUT's location is on the clipboard for Lumetri's Browse).
   save: writes an export the app makes (a LUT zip, a still) where the user chooses. */
(function () {
  'use strict';
  // ------------------------------------------------------------------ the WebView with the app. It is made first, before anything that
  // touches Premiere, so the app shows even if part of Premiere's API is missing. The panel's own text (index.html) stays visible only
  // while the app is not on screen, and says why.
  const APP = 'plugin:/nyans/index.html';
  const BOOT_MS = window.__nyansBootMs || 12000;   // time for the app to say it is running, before one reload and then a message
  const bootText = document.getElementById('bootText'), bootRetry = document.getElementById('bootRetry');
  function say(text, retry) { try { bootText.textContent = text; bootRetry.style.display = retry ? 'inline-block' : 'none'; } catch (e) { /* no panel text */ } }
  const web = document.createElement('webview');
  web.id = 'nyans'; web.className = 'app';
  try { web.uxpAllowInspector = 'true'; web.setAttribute('uxpAllowInspector', 'true'); } catch (e) { /* inspector is optional */ }
  let ready = false, reloads = 0, watchdog = 0;
  function watch() {
    clearTimeout(watchdog);
    watchdog = setTimeout(() => {
      if (ready) return;
      if (reloads < 1) {   // (a WebView can come up blank once; a reload brings it)
        reloads++; console.warn('Nyans: the app did not start, reloading it');
        try { web.reload(); } catch (e) { web.src = APP; }
        watch(); return;
      }
      fail('Nyans did not start in this panel.');
    }, BOOT_MS);
  }
  function fail(why) {
    console.error('Nyans: ' + why);
    clearTimeout(watchdog);
    web.style.display = 'none';
    say(why + ' Press Try again, or close this panel and open it again from Window › UXP Plugins › Nyans. If it stays empty, restart Premiere Pro.', true);
  }
  function appReady() {
    if (ready) return;
    ready = true; clearTimeout(watchdog); say(''); web.style.display = '';   // (also after a load error that did not stop the app)
    console.log('Nyans: the app is running');
    pushStatus(true);
  }
  web.addEventListener('loadstart', e => console.log('Nyans: loading ' + ((e && e.url) || APP)));
  web.addEventListener('loadstop', e => console.log('Nyans: loaded ' + ((e && e.url) || APP)));
  web.addEventListener('loaderror', e => {
    if (e && Number(e.code) === -999) return;   // (macOS: a load cancelled by the next one, as in a reload)
    console.error('Nyans: load error', e && e.url, e && e.code, e && e.message);
    if (!ready) fail('Nyans could not open its page (' + ((e && e.message) || 'no reason given') + (e && e.code != null ? ', code ' + e.code : '') + ').');
  });
  bootRetry.addEventListener('click', () => {
    ready = false; reloads = 0; web.style.display = ''; say('Opening Nyans…');
    try { web.reload(); } catch (e) { web.src = APP; }
    watch();
  });
  web.src = APP;
  document.body.appendChild(web);
  watch();

  // ------------------------------------------------------------------ the WebView follows the panel's size. Its stylesheet size (100vw x
  // 100vh) is taken when the panel opens and does not follow a resize, so the panel is measured (an element pinned to its four edges,
  // laid out by UXP; else the window) and the WebView is given that size in pixels, on every resize signal UXP sends and once a second.
  const fill = document.getElementById('fill');
  let fitW = 0, fitH = 0;
  function panelSize() {
    let w = 0, h = 0;
    try { if (fill) { const r = fill.getBoundingClientRect(); w = r.width; h = r.height; } } catch (e) { w = h = 0; }
    if (!(w > 40 && h > 40)) { try { w = window.innerWidth; h = window.innerHeight; } catch (e) { w = h = 0; } }
    return w > 40 && h > 40 && isFinite(w) && isFinite(h) ? { w: Math.floor(w), h: Math.floor(h) } : null;   // (else the stylesheet size stays)
  }
  function fit() {
    const s = panelSize(); if (!s || (s.w === fitW && s.h === fitH)) return;
    fitW = s.w; fitH = s.h;
    web.style.width = s.w + 'px'; web.style.height = s.h + 'px';
  }
  window.addEventListener('resize', fit);
  if (fill) { try { fill.addEventListener('resize', fit); } catch (e) { /* UXP sends resize to elements; browsers do not */ } }
  try { if (typeof ResizeObserver === 'function' && fill) new ResizeObserver(fit).observe(fill); } catch (e) { /* UXP 8.1 and later */ }
  setInterval(fit, 1000);
  setTimeout(fit, 0);

  // ------------------------------------------------------------------ Premiere and UXP
  let ppro = null, premiereError = '';
  try { ppro = require('premierepro'); } catch (e) { premiereError = (e && e.message) || String(e); console.error('Nyans: Premiere Pro\'s plugin API is not available', e); }
  const uxp = require('uxp');
  let fs = null; try { fs = require('fs'); } catch (e) { /* the storage API covers it */ }
  let os = null; try { os = require('os'); } catch (e) { /* derived from the data folder instead */ }
  const { localFileSystem, types, formats } = uxp.storage;
  const PART = 262144;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let HANDLERS = {};

  // ------------------------------------------------------------------ transport (parts of at most 256K characters each way)
  let seq = 0;
  const parts = new Map();
  function send(obj) {
    const s = JSON.stringify(obj), id = 'h' + (++seq), n = Math.max(1, Math.ceil(s.length / PART));
    for (let i = 0; i < n; i++) web.postMessage({ __nyans: 1, kind: 'part', id, i, n, s: s.slice(i * PART, (i + 1) * PART) });
  }
  window.addEventListener('message', ev => {
    let m = ev.data;
    if (typeof m === 'string') { try { m = JSON.parse(m); } catch (e) { return; } }
    if (!m || m.__nyans !== 1) return;
    appReady();   // (any message from the app means it is running)
    if (m.kind !== 'part') return;
    let a = parts.get(m.id); if (!a) parts.set(m.id, a = { got: 0, s: new Array(m.n) });
    if (a.s[m.i] == null) { a.s[m.i] = m.s; a.got++; }
    if (a.got < m.n) return;
    parts.delete(m.id);
    let call; try { call = JSON.parse(a.s.join('')); } catch (e) { return; }
    if (call && call.kind === 'call') handle(call);
  });
  async function handle(c) {
    try {
      if (!ppro && !['hello', 'http', 'open', 'store'].includes(c.type)) throw new Error('Premiere Pro\'s plugin API is not available here (' + premiereError + '). Nyans needs Premiere Pro 25.6 or later.');
      const fn = HANDLERS[c.type];
      if (!fn) throw new Error('Unknown request: ' + c.type);
      send({ __nyans: 1, kind: 'reply', id: c.id, ok: true, result: await fn(c.payload || {}) });
    } catch (e) { send({ __nyans: 1, kind: 'reply', id: c.id, ok: false, error: (e && e.message) || String(e) }); }
  }

  // ------------------------------------------------------------------ helpers
  const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  function toBase64(buf) {   // (in pieces of 48K bytes, a multiple of 3, so the pieces join into one base64 text; a 4K frame is tens of MB)
    const u = new Uint8Array(buf), n = u.length, CH = 49152, out = [];
    for (let o = 0; o < n; o += CH) {
      const end = Math.min(n, o + CH);
      if (typeof btoa === 'function') { let s = ''; for (let i = o; i < end; i += 8192) s += String.fromCharCode.apply(null, u.subarray(i, Math.min(end, i + 8192))); out.push(btoa(s)); continue; }
      const q = []; let i = o;
      for (; i + 2 < end; i += 3) { const v = (u[i] << 16) | (u[i + 1] << 8) | u[i + 2]; q.push(B64[v >> 18] + B64[(v >> 12) & 63] + B64[(v >> 6) & 63] + B64[v & 63]); }
      if (i < end) { const v = (u[i] << 16) | ((i + 1 < end ? u[i + 1] : 0) << 8); q.push(B64[v >> 18] + B64[(v >> 12) & 63] + (i + 1 < end ? B64[(v >> 6) & 63] : '=') + '='); }
      out.push(q.join(''));
    }
    return out.join('');
  }
  function fromBase64(s) {
    const L = new Int16Array(128).fill(0); for (let i = 0; i < 64; i++) L[B64.charCodeAt(i)] = i;
    s = s.replace(/[^A-Za-z0-9+/]/g, '');
    const full = Math.floor(s.length / 4), rem = s.length % 4, out = new Uint8Array(full * 3 + (rem > 1 ? rem - 1 : 0));
    let o = 0, i = 0;
    for (let q = 0; q < full; q++, i += 4) { const v = (L[s.charCodeAt(i)] << 18) | (L[s.charCodeAt(i + 1)] << 12) | (L[s.charCodeAt(i + 2)] << 6) | L[s.charCodeAt(i + 3)]; out[o++] = v >> 16; out[o++] = (v >> 8) & 255; out[o++] = v & 255; }
    if (rem > 1) { const v = (L[s.charCodeAt(i)] << 18) | (L[s.charCodeAt(i + 1)] << 12) | (rem > 2 ? L[s.charCodeAt(i + 2)] << 6 : 0); out[o++] = v >> 16; if (rem > 2) out[o++] = (v >> 8) & 255; }
    return out.buffer;
  }
  /** 'image/png' or 'image/jpeg' when buf is a whole image of that kind (written to its end), else null */
  function wholeImage(buf) {
    if (!buf || buf.byteLength < 64) return null;
    const u = new Uint8Array(buf), n = u.length;
    if (u[0] === 0x89 && u[1] === 0x50 && u[2] === 0x4E && u[3] === 0x47) return u[n - 8] === 0x49 && u[n - 7] === 0x45 && u[n - 6] === 0x4E && u[n - 5] === 0x44 ? 'image/png' : null;   // IEND
    if (u[0] === 0xFF && u[1] === 0xD8) return u[n - 2] === 0xFF && u[n - 1] === 0xD9 ? 'image/jpeg' : null;   // EOI
    return null;
  }
  // ------------------------------------------------------------------ the frame under the playhead
  // Premiere's Exporter writes the frame in the background (its promise says only that the export started), and some versions put the
  // extension on twice ("….png.png"). So the frame goes to a folder of Nyans' own, is found by the start of its name, and is read once
  // it is whole.
  const listed = async folder => { try { return (await folder.getEntries()) || []; } catch (e) { return []; } };
  async function framesFolder() {
    const data = await localFileSystem.getDataFolder();
    let f = null;
    try { f = await data.getEntry('frames'); } catch (e) { f = null; }
    if (!f || !f.isFolder) f = await data.createFolder('frames');
    return { folder: f, parent: data };
  }
  /** sizes: [[w, h], …] tried in turn (a smaller frame first, then the sequence's own size), each given its time to arrive */
  async function exportFrame(sequence, t, sizes) {
    const { folder, parent } = await framesFolder();
    for (const e of await listed(folder)) if (!e.isFolder) { try { await e.delete(); } catch (err) { /* removed next time */ } }   // (earlier grabs)
    const dir = folder.nativePath, sep = dir.indexOf('\\') >= 0 ? '\\' : '/', into = dir.endsWith(sep) ? dir : dir + sep;
    const bases = []; let seen = [], said = false;
    for (let k = 0; k < sizes.length; k++) {
      const [w, h] = sizes[k], base = 'nyans-frame-' + Date.now() + '-' + k;
      let ok = false;
      try { ok = await ppro.Exporter.exportSequenceFrame(sequence, t, base + '.png', into, w, h); }
      catch (e) { console.warn('Nyans: exportSequenceFrame ' + w + 'x' + h + ' failed', e); }
      console.log('Nyans: exportSequenceFrame ' + w + 'x' + h + ' to ' + into + ' -> ' + ok);
      if (!ok) continue;
      said = true; bases.push(base);
      const t0 = Date.now(), wait = k === sizes.length - 1 ? 30000 : 8000;
      while (Date.now() - t0 < wait) {
        const mine = e => bases.some(b => String(e.name).indexOf(b) >= 0);
        const found = (await listed(folder)).concat((await listed(parent)).filter(mine));   // (also beside the folder)
        seen = found.map(e => e.name);
        for (const e of found) {
          if (e.isFolder) continue;
          let buf = null; try { buf = await e.read({ format: formats.binary }); } catch (err) { buf = null; }
          const type = wholeImage(buf);
          if (type) { try { await e.delete(); } catch (err) { /* removed on the next grab */ } return { buf, type }; }
        }
        await sleep(150);
      }
    }
    if (!said) throw new Error('Premiere Pro could not export the frame at the playhead. Put the playhead over a clip in the active sequence and press Grab frame again.');
    console.error('Nyans: no frame from Premiere Pro in ' + into + ' (there: ' + (seen.join(', ') || 'nothing') + ')');
    throw new Error('Premiere Pro did not write the frame. Press Grab frame again. If it keeps happening, export the frame with the camera button under the Program monitor and open it in Nyans.');
  }
  function tc(t) { const s = Math.max(0, (t && t.seconds) || 0), m = Math.floor(s / 60), r = s - m * 60; return String(m).padStart(2, '0') + ':' + r.toFixed(2).padStart(5, '0'); }
  const plural = (n, w) => n + ' ' + w + (n === 1 ? '' : 's');
  async function active() {
    const project = await ppro.Project.getActiveProject(); if (!project) throw new Error('Open a project in Premiere Pro first');
    const sequence = await project.getActiveSequence(); if (!sequence) throw new Error('Open a sequence in the timeline first');
    return { project, sequence };
  }
  function transact(project, label, build) {
    let ok = false;
    project.lockedAccess(() => { ok = project.executeTransaction(ca => build(ca), label); });
    return ok;
  }
  const CLIP = ppro && ppro.Constants && ppro.Constants.TrackItemType ? ppro.Constants.TrackItemType.CLIP : 1;
  async function selectedVideoItems(sequence) {
    const sel = await sequence.getSelection(); const items = sel ? await sel.getTrackItems() : [];
    return items.filter(it => (ppro.VideoClipTrackItem ? it instanceof ppro.VideoClipTrackItem : typeof it.getComponentChain === 'function'));
  }
  async function clipAtPlayhead(sequence) {
    const t = (await sequence.getPlayerPosition()).seconds, n = await sequence.getVideoTrackCount();
    for (let i = n - 1; i >= 0; i--) {   // (the topmost clip is the one seen)
      const track = await sequence.getVideoTrack(i); if (!track) continue;
      for (const it of track.getTrackItems(CLIP, false) || []) {
        const s = (await it.getStartTime()).seconds, e = (await it.getEndTime()).seconds;
        if (t >= s && t < e && !(await it.isDisabled())) return [it];
      }
    }
    return [];
  }

  // ------------------------------------------------------------------ where the LUTs go
  function platform() { try { if (os && os.platform) return os.platform(); } catch (e) { /* below */ } return /^[A-Za-z]:[\\/]/.test(dataPath || '') ? 'win32' : 'darwin'; }
  let dataPath = null;
  async function homeDir() {
    try { if (os && os.homedir) { const h = os.homedir(); if (h) return h.replace(/\\/g, '/'); } } catch (e) { /* below */ }
    try { const d = await localFileSystem.getDataFolder(); dataPath = d.nativePath; const m = /^(\/Users\/[^/]+|[A-Za-z]:[\\/]Users[\\/][^\\/]+)/.exec(d.nativePath); if (m) return m[1].replace(/\\/g, '/'); } catch (e) { /* none */ }
    return null;
  }
  async function ensureFolder(path) {
    const url = p => 'file:' + (p.startsWith('/') ? p : '/' + p);
    const segs = path.split('/'); let cur = '';
    for (let i = 0; i < segs.length; i++) {
      cur = i === 0 ? segs[0] : cur + '/' + segs[i]; if (!cur || /^[A-Za-z]:$/.test(cur)) continue;
      let ok = false; try { const e = await localFileSystem.getEntryWithUrl(url(cur)); ok = !!(e && e.isFolder); } catch (e) { ok = false; }
      if (!ok) await localFileSystem.createEntryWithUrl(url(cur), { type: types.folder });
    }
    return localFileSystem.getEntryWithUrl(url(path));
  }
  /** Premiere's own Creative LUT folder for this user (the LUT is also listed under Lumetri > Creative > Look after a restart), else the
      plugin's data folder */
  async function saveLut(fileName, cube) {
    const home = await homeDir();
    if (home) {
      const dir = platform() === 'win32' ? home + '/AppData/Roaming/Adobe/Common/LUTs/Creative/Nyans' : home + '/Library/Application Support/Adobe/Common/LUTs/Creative/Nyans';
      try { const folder = await ensureFolder(dir); const f = await folder.createFile(fileName, { overwrite: true }); await f.write(cube, { format: formats.utf8 }); return { path: f.nativePath, listed: true }; }
      catch (e) { console.warn('Nyans: could not write to the Lumetri LUT folder', e); }
    }
    const data = await localFileSystem.getDataFolder(); const f = await data.createFile(fileName, { overwrite: true }); await f.write(cube, { format: formats.utf8 });
    return { path: f.nativePath, listed: false };
  }

  // ------------------------------------------------------------------ Lumetri
  const LUMETRI = 'AE.ADBE Lumetri';
  async function lumetriOf(chain) {
    let found = null; const n = chain.getComponentCount();
    for (let i = 0; i < n; i++) { const c = chain.getComponentAtIndex(i); try { if ((await c.getMatchName()) === LUMETRI) found = c; } catch (e) { /* skip */ } }
    return found;
  }
  async function addLumetri(project, chain) {
    const comp = await ppro.VideoFilterFactory.createComponent(LUMETRI);
    if (!transact(project, 'Nyans: add Lumetri Color', ca => ca.addAction(chain.createAppendComponentAction(comp)))) return null;
    return chain.getComponentAtIndex(chain.getComponentCount() - 1);
  }
  /** Lumetri's Look (Creative): 'free' when this Premiere takes a path for it and it holds none or a Nyans one, 'taken' when it holds
      someone else's look, 'list' when Premiere offers it only as a list (chosen by hand) */
  async function lookParam(comp) {
    const n = comp.getParamCount();
    for (let i = 0; i < n; i++) { const p = comp.getParam(i); if (p && /^look$/i.test((p.displayName || '').trim())) return p; }
    return null;
  }
  async function lookState(comp) {
    const p = await lookParam(comp); if (!p) return 'list';
    try { const v = await p.getValueAtTime(ppro.TickTime.TIME_ZERO); if (!v || typeof v.value !== 'string') return 'list'; return !v.value || /nyans/i.test(v.value) ? 'free' : 'taken'; }
    catch (e) { return 'list'; }
  }
  async function pointLook(project, comp, path) {
    const p = await lookParam(comp); if (!p) return false;
    try { const kf = p.createKeyframe(path); return transact(project, 'Nyans: Look', ca => ca.addAction(p.createSetValueAction(kf, true))); }
    catch (e) { return false; }
  }
  async function copyText(t) { try { await navigator.clipboard.setContent({ 'text/plain': t }); return true; } catch (e) { return false; } }

  // ------------------------------------------------------------------ the licence's notes, in the data folder (licence.json)
  let notes = null, notesWrite = Promise.resolve();
  async function readNotes() {
    if (notes) return notes;
    try { const f = await (await localFileSystem.getDataFolder()).getEntry('licence.json'); notes = JSON.parse(await f.read({ format: formats.utf8 })) || {}; }
    catch (e) { notes = {}; }
    if (typeof notes !== 'object' || Array.isArray(notes)) notes = {};
    return notes;
  }
  function writeNotes(all) {   // (one write at a time, each with everything)
    notesWrite = notesWrite.then(async () => {
      const f = await (await localFileSystem.getDataFolder()).createFile('licence.json', { overwrite: true });
      await f.write(JSON.stringify(all), { format: formats.utf8 });
    }).catch(e => console.warn('Nyans: could not keep the licence notes', e));
    return notesWrite;
  }

  // ------------------------------------------------------------------ requests
  HANDLERS = {
    async hello() { return { status: await statusText() }; },
    /** the licence check: Lemon Squeezy's licence API only */
    async http({ url, body }) {
      if (!/^https:\/\/api\.lemonsqueezy\.com\/v1\/licenses\/(activate|validate|deactivate)$/.test(String(url))) throw new Error('Nyans talks only to Lemon Squeezy here');
      const r = await fetch(url, { method: 'POST', headers: { Accept: 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' }, body: String(body || '') });
      return { status: r.status, text: await r.text() };
    },
    /** what the licence keeps between sessions (the trial's start, the key): Premiere's WebView has no localStorage for a plugin's own
        page, so the panel keeps it, in the plugin's data folder */
    async store({ op, k, v }) {
      const all = await readNotes();
      if (op === 'all') return { all };
      if (op !== 'set' || typeof k !== 'string' || !/^nyans\./.test(k)) throw new Error('Unknown store request');
      if (v == null) delete all[k]; else all[k] = String(v);
      await writeNotes(all);
      return { ok: true };
    },
    /** the page to buy a licence, in the default browser */
    async open({ url }) {
      if (!/^https:\/\/davidhjalmarlindberg\.com\//.test(String(url))) throw new Error('Nyans opens only its own pages');
      await uxp.shell.openExternal(url, 'Nyans opens the page where you can buy a licence.');
      return { opened: true };
    },
    async grab({ maxSide }) {
      const { sequence } = await active();
      const t = await sequence.getPlayerPosition();
      let w = 1920, h = 1080;
      try { const r = await sequence.getFrameSize(); if (r && r.width > 0 && r.height > 0) { w = r.width; h = r.height; } } catch (e) { /* the default size */ }
      const k = Math.min(1, (maxSide || 1920) / Math.max(w, h)), sw = Math.max(2, Math.round(w * k / 2) * 2), sh = Math.max(2, Math.round(h * k / 2) * 2);
      const got = await exportFrame(sequence, t, sw === w && sh === h ? [[w, h]] : [[sw, sh], [w, h]]);   // (the sequence's own size if a smaller one never comes)
      const where = (sequence.name || 'the sequence') + ' at ' + tc(t);
      return { data: toBase64(got.buf), type: got.type, name: (sequence.name || 'Sequence') + ' ' + tc(t), note: 'Frame read from ' + where + '. Press Generate.' };
    },
    async apply({ name, cube, target }) {
      const { project, sequence } = await active();
      let items = target === 'playhead' ? [] : await selectedVideoItems(sequence);
      if (!items.length) items = await clipAtPlayhead(sequence);
      if (!items.length) throw new Error('Select the clips to grade, or put the playhead over one');
      const fileName = String(name || 'Nyans').replace(/[\\/:*?"<>|]+/g, '') + '.cube', lut = await saveLut(fileName, cube);
      let added = 0, pointed = 0;
      for (const it of items) {
        const chain = await it.getComponentChain();
        let lum = await lumetriOf(chain), st = lum ? await lookState(lum) : null;
        if (!lum || st === 'taken') { lum = await addLumetri(project, chain); if (lum) { added++; st = await lookState(lum); } }   // (someone's Look is never replaced)
        if (lum && st === 'free' && (await pointLook(project, lum, lut.path))) pointed++;
      }
      const clips = plural(items.length, 'clip');
      if (pointed === items.length) return { ok: true, message: 'Applied to ' + clips, note: '' };
      const copied = await copyText(lut.path);
      return {
        ok: true,
        message: (added ? 'Lumetri Color added to ' + plural(added, 'clip') : 'LUT ready for ' + clips) + '. Pick it under Look.',
        note: 'In Lumetri Color › Creative › Look, choose Browse… and pick “' + fileName + '”' + (copied ? ' (its location is on your clipboard)' : ' in ' + lut.path) + '.' +
          (lut.listed ? ' After Premiere restarts, it is also listed under Look.' : ''),
      };
    },
    async save({ name, data }) {
      const ext = (String(name).split('.').pop() || '').toLowerCase();
      const f = await localFileSystem.getFileForSaving(name, ext ? { types: [ext] } : undefined);
      if (!f) return { cancelled: true };
      await f.write(fromBase64(data), { format: formats.binary });
      return { path: f.nativePath };
    },
  };

  // ------------------------------------------------------------------ the sequence and playhead, shown in the app's bar
  async function statusText() {
    if (!ppro) return '';
    try { const p = await ppro.Project.getActiveProject(); const s = p && (await p.getActiveSequence()); if (!s) return 'no sequence'; return (s.name || 'Sequence') + '  ' + tc(await s.getPlayerPosition()); }
    catch (e) { return ''; }
  }
  let lastStatus = null;
  async function pushStatus(force) {
    const t = await statusText();
    if (t === lastStatus && !force) return;
    lastStatus = t;
    if (ready) { try { web.postMessage({ __nyans: 1, kind: 'status', text: t }); } catch (e) { /* the page is reloading */ } }
  }
  setInterval(() => { pushStatus(false); }, 1500);
  window.__nyansHost = { HANDLERS, toBase64, fromBase64, state: () => ({ ready, reloads, shown: web.style.display !== 'none', text: bootText ? bootText.textContent : '' }), fail };   // (for tests)
})();
