// main.m: Nyans for Final Cut Pro, the app that carries the effect (Contents/PlugIns/NyansEffect.pluginkit) and its Final Cut
// effect template. Opening it checks the installation, puts the template where Final Cut Pro looks for effects
// (Movies/Motion Templates/Effects/Nyans), registers the effect with macOS and says how to use it.
#import <Cocoa/Cocoa.h>

static NSString *const kNyTemplateCategory = @"Nyans";

@interface NyansAppDelegate : NSObject <NSApplicationDelegate>
@end

@implementation NyansAppDelegate {
    NSWindow *_window;
    NSTextField *_status;
    NSButton *_openFCP;
}

// ------------------------------------------------------------------ the installation

- (NSString *)effectPath {
    return [NSBundle.mainBundle.builtInPlugInsPath stringByAppendingPathComponent:@"NyansEffect.pluginkit"];
}

- (BOOL)effectHasFrameworks {
    NSString *fw = [[self effectPath] stringByAppendingPathComponent:@"Contents/Frameworks"];
    NSFileManager *fm = NSFileManager.defaultManager;
    return [fm fileExistsAtPath:[fw stringByAppendingPathComponent:@"FxPlug.framework/FxPlug"]]
        && [fm fileExistsAtPath:[fw stringByAppendingPathComponent:@"PluginManager.framework/PluginManager"]];
}

- (NSURL *)templateDestination {
    NSURL *movies = [NSFileManager.defaultManager URLsForDirectory:NSMoviesDirectory inDomains:NSUserDomainMask].firstObject;
    return [[[movies URLByAppendingPathComponent:@"Motion Templates.localized" isDirectory:YES]
             URLByAppendingPathComponent:@"Effects.localized" isDirectory:YES] URLByAppendingPathComponent:kNyTemplateCategory isDirectory:YES];
}

/** copies the effect template out of the app when it is missing or older; returns a problem or nil */
- (NSString *)installTemplate {
    NSFileManager *fm = NSFileManager.defaultManager;
    NSString *source = [NSBundle.mainBundle.resourcePath stringByAppendingPathComponent:@"Motion Templates/Nyans"];
    if (![fm fileExistsAtPath:source]) return @"the effect template is missing from the app";
    NSURL *category = [self templateDestination];
    NSURL *dest = [category URLByAppendingPathComponent:@"Nyans" isDirectory:YES];
    if ([fm contentsEqualAtPath:source andPath:dest.path]) return nil;
    NSError *e = nil;
    if (![fm createDirectoryAtURL:category withIntermediateDirectories:YES attributes:nil error:&e]) return e.localizedDescription;
    if ([fm fileExistsAtPath:dest.path] && ![fm removeItemAtURL:dest error:&e]) return e.localizedDescription;
    if (![fm copyItemAtPath:source toPath:dest.path error:&e]) return e.localizedDescription;
    return nil;
}

- (void)registerEffect {
    NSString *path = [self effectPath];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        NSTask *t = [[NSTask alloc] init];
        t.executableURL = [NSURL fileURLWithPath:@"/usr/bin/pluginkit"];
        t.arguments = @[ @"-a", path ];
        t.standardOutput = NSFileHandle.fileHandleWithNullDevice;
        t.standardError = NSFileHandle.fileHandleWithNullDevice;
        NSError *e = nil;
        if ([t launchAndReturnError:&e]) [t waitUntilExit];
        else NSLog(@"[Nyans] pluginkit did not run: %@", e);
    });
}

- (NSURL *)finalCutURL {
    return [NSWorkspace.sharedWorkspace URLForApplicationWithBundleIdentifier:@"com.apple.FinalCut"];
}

- (void)refresh {
    NSMutableArray<NSString *> *lines = [NSMutableArray array];
    BOOL ready = YES;
    if ([self effectHasFrameworks]) {
        [lines addObject:@"✓  The Nyans effect is installed."];
        [self registerEffect];
    } else {
        ready = NO;
        [lines addObject:@"!  The effect is missing Final Cut Pro's FxPlug frameworks. Run “Install Nyans for Final Cut Pro” again."];
    }
    NSString *problem = [self installTemplate];
    if (problem) {
        ready = NO;
        [lines addObject:[@"!  The effect template could not be put in Movies › Motion Templates: " stringByAppendingString:problem]];
    } else {
        [lines addObject:@"✓  The effect template is in Movies › Motion Templates › Effects › Nyans."];
    }
    if ([self finalCutURL]) {
        [lines addObject:@"✓  Final Cut Pro is on this Mac."];
    } else {
        ready = NO;
        [lines addObject:@"!  Final Cut Pro was not found."];
    }
    if (ready) [lines addObject:@"\nIf Final Cut Pro was open while installing, quit it and open it again."];
    _status.stringValue = [lines componentsJoinedByString:@"\n"];
    _openFCP.enabled = [self finalCutURL] != nil;
}

// ------------------------------------------------------------------ the window

- (NSTextField *)label:(NSString *)text size:(CGFloat)size weight:(NSFontWeight)weight color:(NSColor *)color {
    NSTextField *t = [NSTextField wrappingLabelWithString:text];
    t.font = [NSFont systemFontOfSize:size weight:weight];
    t.textColor = color;
    t.selectable = NO;
    return t;
}

- (void)buildWindow {
    NSWindow *w = [[NSWindow alloc] initWithContentRect:NSMakeRect(0, 0, 600, 430)
                                              styleMask:NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskMiniaturizable
                                                backing:NSBackingStoreBuffered defer:NO];
    w.title = @"Nyans for Final Cut Pro";
    w.appearance = [NSAppearance appearanceNamed:NSAppearanceNameDarkAqua];
    w.backgroundColor = [NSColor colorWithSRGBRed:0.063 green:0.063 blue:0.063 alpha:1];
    w.releasedWhenClosed = NO;
    NSView *v = w.contentView;

    NSImageView *icon = [NSImageView imageViewWithImage:NSApp.applicationIconImage];
    icon.frame = NSMakeRect(32, 330, 72, 72);
    [v addSubview:icon];

    NSTextField *title = [self label:@"Nyans for Final Cut Pro" size:22 weight:NSFontWeightSemibold color:NSColor.whiteColor];
    title.frame = NSMakeRect(122, 366, 440, 30);
    [v addSubview:title];
    NSTextField *sub = [self label:@"Looks composed from your own frame, inside Final Cut Pro." size:13 weight:NSFontWeightRegular
                             color:[NSColor colorWithWhite:0.7 alpha:1]];
    sub.frame = NSMakeRect(122, 340, 440, 20);
    [v addSubview:sub];

    NSString *how = @"1.  In Final Cut Pro, open the Effects browser and choose the Nyans category.\n"
                    @"2.  Drag Nyans onto a clip, or select the clip and double-click Nyans.\n"
                    @"3.  In the Video inspector, click Open Nyans. Nyans reads the frame under the playhead.\n"
                    @"4.  Press Generate, pick a look, refine it, then press Apply to clip.\n"
                    @"     Mix in the inspector blends the look with the clip.";
    NSTextField *steps = [self label:how size:13 weight:NSFontWeightRegular color:[NSColor colorWithWhite:0.9 alpha:1]];
    steps.frame = NSMakeRect(32, 214, 540, 104);
    [v addSubview:steps];

    _status = [self label:@"" size:12 weight:NSFontWeightRegular color:[NSColor colorWithWhite:0.62 alpha:1]];
    _status.frame = NSMakeRect(32, 76, 540, 124);
    [v addSubview:_status];

    _openFCP = [NSButton buttonWithTitle:@"Open Final Cut Pro" target:self action:@selector(openFinalCut:)];
    _openFCP.frame = NSMakeRect(398, 24, 172, 32);
    _openFCP.keyEquivalent = @"\r";
    [v addSubview:_openFCP];
    NSButton *show = [NSButton buttonWithTitle:@"Show Template" target:self action:@selector(showTemplate:)];
    show.frame = NSMakeRect(250, 24, 140, 32);
    [v addSubview:show];
    NSButton *quit = [NSButton buttonWithTitle:@"Quit" target:NSApp action:@selector(terminate:)];
    quit.frame = NSMakeRect(28, 24, 90, 32);
    [v addSubview:quit];

    [w center];
    _window = w;
    [w makeKeyAndOrderFront:nil];
}

- (void)buildMenu {
    NSMenu *bar = [[NSMenu alloc] init];
    NSMenuItem *appItem = [[NSMenuItem alloc] init];
    [bar addItem:appItem];
    NSMenu *appMenu = [[NSMenu alloc] initWithTitle:@"Nyans"];
    [appMenu addItemWithTitle:@"Quit Nyans" action:@selector(terminate:) keyEquivalent:@"q"];
    appItem.submenu = appMenu;
    NSMenuItem *editItem = [[NSMenuItem alloc] init];
    [bar addItem:editItem];
    NSMenu *edit = [[NSMenu alloc] initWithTitle:@"Edit"];
    [edit addItemWithTitle:@"Copy" action:@selector(copy:) keyEquivalent:@"c"];
    editItem.submenu = edit;
    NSApp.mainMenu = bar;
}

- (void)openFinalCut:(id)sender {
    NSURL *url = [self finalCutURL];
    if (!url) return;
    [NSWorkspace.sharedWorkspace openApplicationAtURL:url configuration:[NSWorkspaceOpenConfiguration configuration] completionHandler:nil];
}

- (void)showTemplate:(id)sender {
    NSURL *dest = [[self templateDestination] URLByAppendingPathComponent:@"Nyans" isDirectory:YES];
    if ([NSFileManager.defaultManager fileExistsAtPath:dest.path]) [NSWorkspace.sharedWorkspace activateFileViewerSelectingURLs:@[ dest ]];
}

// ------------------------------------------------------------------ the app

- (void)applicationDidFinishLaunching:(NSNotification *)notification {
    [self buildMenu];
    [self buildWindow];
    [self refresh];
    [NSApp activateIgnoringOtherApps:YES];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender {
    return YES;
}

@end

int main(int argc, const char *argv[]) {
    @autoreleasepool {
        static NyansAppDelegate *delegate;   // (NSApplication keeps its delegate weakly)
        NSApplication *app = [NSApplication sharedApplication];
        delegate = [[NyansAppDelegate alloc] init];
        app.delegate = delegate;
        [app setActivationPolicy:NSApplicationActivationPolicyRegular];
        [app run];
    }
    return 0;
}
