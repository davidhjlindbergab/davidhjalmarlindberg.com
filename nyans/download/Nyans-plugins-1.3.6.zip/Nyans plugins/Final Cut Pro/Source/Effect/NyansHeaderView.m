// NyansHeaderView.m: see NyansHeaderView.h
#import "NyansHeaderView.h"
#import "NyansPlugIn.h"

@implementation NyansHeaderView {
    __weak NyansPlugIn *_plugIn;
    NSButton *_button;
    NSTextField *_label;
}

- (instancetype)initWithPlugIn:(NyansPlugIn *)plugIn {
    if ((self = [super initWithFrame:NSMakeRect(0, 0, 240, 56)])) {
        _plugIn = plugIn;
        _button = [NSButton buttonWithTitle:@"Open Nyans" target:self action:@selector(open:)];
        _button.frame = NSMakeRect(0, 26, 150, 28);
        _button.autoresizingMask = NSViewMaxXMargin | NSViewMinYMargin;
        [self addSubview:_button];
        _label = [NSTextField labelWithString:@""];
        _label.font = [NSFont systemFontOfSize:11];
        _label.textColor = NSColor.secondaryLabelColor;
        _label.lineBreakMode = NSLineBreakByTruncatingTail;
        _label.frame = NSMakeRect(2, 4, 236, 16);
        _label.autoresizingMask = NSViewWidthSizable | NSViewMinYMargin;
        [self addSubview:_label];
        [self setLookTitle:nil];
    }
    return self;
}

- (void)setLookTitle:(NSString *)title {
    _label.stringValue = title.length ? title : @"No look on this clip yet";
    _label.toolTip = title.length ? [@"The Nyans look on this clip: " stringByAppendingString:title] : @"Open Nyans, grab the frame, pick a look and apply it";
}

- (void)open:(id)sender {
    [_plugIn openPanel];
}

// (the inspector hosts this view in a window of its own: without this the first click would only focus that window)
- (BOOL)acceptsFirstMouse:(NSEvent *)event {
    return YES;
}

@end
