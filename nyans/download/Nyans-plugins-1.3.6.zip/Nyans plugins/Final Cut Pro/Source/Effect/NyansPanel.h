// NyansPanel.h: the Nyans app inside Final Cut Pro. Open Nyans asks Final Cut Pro for a window (FxRemoteWindowAPI) and puts the
// same app the web version runs (resources/nyans/index.html: the v2 engine, the interface and the Final Cut Pro bridge) in it.
// The page talks to the effect through window.webkit.messageHandlers.nyans: hello, grab (the frame under the playhead),
// apply (the baked look onto this clip) and save (exports, to Movies/Nyans).
// Closing the window keeps the page (looks, variations, refinements) for the next Open Nyans, for the two most recent clips.
#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@class NyansPlugIn;

@interface NyansPanel : NSObject
- (instancetype)initWithPlugIn:(NyansPlugIn *)plugIn;
/** opens the window (or brings it forward) */
- (void)show;
/** the effect is going away: closes the window and drops the page */
- (void)close;
/** the line next to "Final Cut Pro" in the app's header (for example the look on the clip) */
- (void)pushStatus:(nullable NSString *)status;
@end

NS_ASSUME_NONNULL_END
