// NyansFx.m: loading FxPlug at run time (see NyansFx.h)
#import "NyansFx.h"

#import <dlfcn.h>
#import <objc/message.h>
#import <objc/runtime.h>

static void *NyLoadFramework(NSString *dir, NSString *name, NSMutableArray<NSString *> *problems) {
    NSString *path = [NSString stringWithFormat:@"%@/%@.framework/%@", dir, name, name];
    if (![NSFileManager.defaultManager fileExistsAtPath:path]) {
        [problems addObject:[name stringByAppendingString:@".framework is missing from the effect (run the installer again)"]];
        return NULL;
    }
    void *h = dlopen(path.fileSystemRepresentation, RTLD_NOW | RTLD_GLOBAL);
    if (!h) {
        const char *e = dlerror();
        [problems addObject:[NSString stringWithFormat:@"%@.framework did not load: %s", name, e ? e : "unknown error"]];
    }
    return h;
}

BOOL NyFxLoadFrameworks(NSString **problem) {
    NSBundle *bundle = NSBundle.mainBundle;
    NSString *dir = bundle.privateFrameworksPath;
    if (!dir.length) dir = [[bundle.executablePath stringByDeletingLastPathComponent] stringByAppendingPathComponent:@"../Frameworks"];
    NSMutableArray<NSString *> *problems = [NSMutableArray array];
    void *pm = NyLoadFramework(dir, @"PluginManager", problems);
    void *fx = NyLoadFramework(dir, @"FxPlug", problems);
    if (problem) *problem = problems.count ? [problems componentsJoinedByString:@"; "] : nil;
    return pm != NULL && fx != NULL;
}

id NyFxAPI(id<NyFxAPIManager> manager, const char *protocolName) {
    if (!manager) return nil;
    Protocol *p = objc_getProtocol(protocolName);
    if (!p) return nil;
    @try {
        return [manager apiForProtocol:p];
    } @catch (NSException *e) {
        NSLog(@"[Nyans] %s is not available: %@", protocolName, e.reason);
        return nil;
    }
}

NSString *NyFxString(const char *symbol) {
    void *p = dlsym(RTLD_DEFAULT, symbol);
    if (!p) return nil;
    NSString *__unsafe_unretained *sp = (NSString *__unsafe_unretained *)p;
    return *sp;
}

void NyFxAdopt(Class cls, const char *protocolName) {
    Protocol *p = objc_getProtocol(protocolName);
    if (!p) { NSLog(@"[Nyans] FxPlug has no protocol %s", protocolName); return; }
    if (!class_conformsToProtocol(cls, p)) class_addProtocol(cls, p);
}

void NyFxStartService(void) {
    Class principal = NSClassFromString(@"FxPrincipal");
    SEL start = NSSelectorFromString(@"startServicePrincipal");
    if (!principal || ![principal respondsToSelector:start]) {
        NSLog(@"[Nyans] FxPlug's service principal is missing, so Final Cut Pro cannot reach the effect");
        exit(1);
    }
    ((void (*)(id, SEL))objc_msgSend)(principal, start);
    exit(0);
}

NSString *NyFxErrorDomain(void) {
    NSString *d = NyFxString("FxPlugErrorDomain");
    return d.length ? d : @"com.nyans.fcp";
}
