// NyansLook.m: see NyansLook.h
#import "NyansLook.h"
#import "nyans_core.h"

#import <os/lock.h>

static NSString *const kNyPayloadPrefix = @"nyans1:";
static const NSUInteger kNyStoreCapacity = 12;

@interface NyansLUT ()
- (instancetype)initWithID:(NSString *)lookID size:(int)size rgba:(NSData *)rgba;
@end

@implementation NyansLUT

- (instancetype)initWithID:(NSString *)lookID size:(int)size rgba:(NSData *)rgba {
    if ((self = [super init])) {
        _lookID = [lookID copy];
        _size = size;
        _rgba = rgba;
    }
    return self;
}

static NSString *NyLookID(const uint16_t *q, int size) {
    return [NSString stringWithFormat:@"%016llx", (unsigned long long)ny_look_hash(q, size)];
}

static NSData *NyRGBA(const uint16_t *q, int size) {
    size_t N = (size_t)size * size * size;
    NSMutableData *d = [NSMutableData dataWithLength:N * 4 * sizeof(float)];
    ny_dequantize_rgba(q, size, (float *)d.mutableBytes);
    return d;
}

+ (instancetype)lutWithCube:(NSString *)cube meta:(NSDictionary *)meta payload:(NSString **)payload error:(NSString **)error {
    *payload = nil;
    const char *text = cube.UTF8String;
    if (!text) { if (error) *error = @"the look arrived empty"; return nil; }
    int size = 0;
    float *rgb = NULL;
    const char *e = ny_cube_parse(text, strlen(text), &size, &rgb);
    if (e) { if (error) *error = [NSString stringWithUTF8String:e]; return nil; }
    size_t N = (size_t)size * size * size;
    uint16_t *q = (uint16_t *)malloc(N * 3 * sizeof(uint16_t));
    if (!q) { free(rgb); if (error) *error = @"out of memory"; return nil; }
    ny_quantize(rgb, size, q);
    free(rgb);

    NSData *json = [NSJSONSerialization isValidJSONObject:meta] ? [NSJSONSerialization dataWithJSONObject:meta options:0 error:nil] : nil;
    size_t blobLen = 0;
    uint8_t *blob = ny_pack(q, size, json.bytes, json.length, &blobLen);
    NSString *lookID = NyLookID(q, size);
    NSData *rgba = NyRGBA(q, size);
    free(q);
    if (!blob) { if (error) *error = @"the look could not be packed"; return nil; }
    NSData *blobData = [NSData dataWithBytesNoCopy:blob length:blobLen freeWhenDone:YES];
    *payload = [kNyPayloadPrefix stringByAppendingString:[blobData base64EncodedStringWithOptions:0]];
    return [[NyansLUT alloc] initWithID:lookID size:size rgba:rgba];
}

+ (instancetype)lutWithPayload:(NSString *)payload meta:(NSDictionary **)meta error:(NSString **)error {
    if (meta) *meta = nil;
    if (![payload hasPrefix:kNyPayloadPrefix]) { if (error) *error = @"the clip's look data is not from this version of Nyans"; return nil; }
    NSData *blob = [[NSData alloc] initWithBase64EncodedString:[payload substringFromIndex:kNyPayloadPrefix.length]
                                                       options:NSDataBase64DecodingIgnoreUnknownCharacters];
    if (!blob.length) { if (error) *error = @"the clip's look data is damaged"; return nil; }
    uint16_t *q = NULL;
    int size = 0;
    char *m = NULL;
    const char *e = ny_unpack(blob.bytes, blob.length, &q, &size, &m);
    if (e) { if (error) *error = [NSString stringWithUTF8String:e]; return nil; }
    if (meta && m && *m) {
        NSData *md = [NSData dataWithBytes:m length:strlen(m)];
        id obj = [NSJSONSerialization JSONObjectWithData:md options:0 error:nil];
        if ([obj isKindOfClass:NSDictionary.class]) *meta = obj;
    }
    free(m);
    NSString *lookID = NyLookID(q, size);
    NSData *rgba = NyRGBA(q, size);
    free(q);
    return [[NyansLUT alloc] initWithID:lookID size:size rgba:rgba];
}

@end

@implementation NyansLookStore {
    os_unfair_lock _lock;                         // guards _byID and _order
    NSMutableDictionary<NSString *, NyansLUT *> *_byID;
    NSMutableArray<NSString *> *_order;           // least recently used first
    NSLock *_unpacking;                           // one unpack at a time (two renders of a new look wait for the first)
}

+ (instancetype)shared {
    static NyansLookStore *store;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ store = [[NyansLookStore alloc] init]; });
    return store;
}

- (instancetype)init {
    if ((self = [super init])) {
        _lock = OS_UNFAIR_LOCK_INIT;
        _byID = [NSMutableDictionary dictionary];
        _order = [NSMutableArray array];
        _unpacking = [[NSLock alloc] init];
    }
    return self;
}

- (NyansLUT *)lutForID:(NSString *)lookID {
    if (!lookID.length) return nil;
    os_unfair_lock_lock(&_lock);
    NyansLUT *lut = _byID[lookID];
    if (lut) { [_order removeObject:lookID]; [_order addObject:lookID]; }
    os_unfair_lock_unlock(&_lock);
    return lut;
}

- (void)storeLUT:(NyansLUT *)lut asID:(NSString *)lookID {
    os_unfair_lock_lock(&_lock);
    _byID[lookID] = lut;
    [_order removeObject:lookID];
    [_order addObject:lookID];
    while (_order.count > kNyStoreCapacity) {
        [_byID removeObjectForKey:_order.firstObject];
        [_order removeObjectAtIndex:0];
    }
    os_unfair_lock_unlock(&_lock);
}

- (void)addLUT:(NyansLUT *)lut {
    [self storeLUT:lut asID:lut.lookID];
}

- (NyansLUT *)lutForID:(NSString *)lookID payload:(NSString *(^)(void))payload error:(NSString **)error {
    NyansLUT *lut = [self lutForID:lookID];
    if (lut) return lut;
    [_unpacking lock];
    lut = [self lutForID:lookID];   // (another render may have unpacked it meanwhile)
    if (!lut) {
        NSString *data = payload();
        if (!data.length) {
            if (error) *error = @"the clip has a look id but no look data";
        } else {
            lut = [NyansLUT lutWithPayload:data meta:NULL error:error];
            if (lut) {
                if (![lut.lookID isEqualToString:lookID]) NSLog(@"[Nyans] the clip's look data hashes to %@, not %@ (kept)", lut.lookID, lookID);
                [self storeLUT:lut asID:lookID];
            }
        }
    }
    [_unpacking unlock];
    return lut;
}

@end
