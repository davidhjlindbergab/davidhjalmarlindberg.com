// nyans_core.c: see nyans_core.h
#include "nyans_core.h"

#include <ctype.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>

// ------------------------------------------------------------------ .cube

static int ny_starts(const char *p, const char *end, const char *word) {
    size_t n = strlen(word);
    if ((size_t)(end - p) < n || strncmp(p, word, n) != 0) return 0;
    return p + n == end || isspace((unsigned char)p[n]);
}

/** reads up to 3 floats from [p, end) */
static int ny_floats(const char *p, const char *end, float *v, int count) {
    char buf[160];
    size_t n = (size_t)(end - p);
    if (n >= sizeof buf) n = sizeof buf - 1;
    memcpy(buf, p, n);
    buf[n] = 0;
    char *s = buf;
    int k = 0;
    for (; k < count; k++) {
        char *e = NULL;
        float f = strtof(s, &e);
        if (e == s) break;
        v[k] = f;
        s = e;
    }
    return k;
}

const char *ny_cube_parse(const char *text, size_t len, int *size, float **rgb) {
    *size = 0;
    *rgb = NULL;
    if (!text || !len) return "the look is empty";
    const char *p = text, *end = text + len;
    int n = 0;
    size_t want = 0, got = 0;
    float *out = NULL;
    while (p < end) {
        const char *nl = memchr(p, '\n', (size_t)(end - p));
        const char *le = nl ? nl : end;
        const char *a = p, *b = le;
        while (a < b && isspace((unsigned char)*a)) a++;
        while (b > a && isspace((unsigned char)b[-1])) b--;
        p = nl ? nl + 1 : end;
        if (a == b || *a == '#') continue;
        if (ny_starts(a, b, "TITLE")) continue;
        if (ny_starts(a, b, "LUT_1D_SIZE")) { free(out); return "a 1D LUT is not a Nyans look"; }
        if (ny_starts(a, b, "LUT_3D_SIZE")) {
            float f[1];
            if (out || ny_floats(a + 11, b, f, 1) != 1) { free(out); return "the look has a broken size line"; }
            n = (int)f[0];
            if (n < NY_LUT_MIN || n > NY_LUT_MAX) { free(out); return "the look has an unusual size"; }
            want = (size_t)n * n * n;
            out = (float *)malloc(want * 3 * sizeof(float));
            if (!out) return "out of memory";
            continue;
        }
        if (ny_starts(a, b, "DOMAIN_MIN") || ny_starts(a, b, "DOMAIN_MAX")) {
            float f[3];
            int lo = ny_starts(a, b, "DOMAIN_MIN");
            if (ny_floats(a + 10, b, f, 3) != 3) { free(out); return "the look has a broken domain line"; }
            for (int k = 0; k < 3; k++)
                if (fabsf(f[k] - (lo ? 0.0f : 1.0f)) > 1e-6f) { free(out); return "the look uses a domain other than 0..1"; }
            continue;
        }
        if (isalpha((unsigned char)*a)) continue;   // (any other keyword: LUT_3D_INPUT_RANGE and the like)
        if (!out) return "the look has values before its size";
        if (got >= want) { free(out); return "the look has more values than its size"; }
        float v[3];
        if (ny_floats(a, b, v, 3) != 3) { free(out); return "the look has a broken value line"; }
        out[got * 3] = v[0];
        out[got * 3 + 1] = v[1];
        out[got * 3 + 2] = v[2];
        got++;
    }
    if (!out) return "the look has no size line";
    if (got != want) { free(out); return "the look is missing values"; }
    *size = n;
    *rgb = out;
    return NULL;
}

// ------------------------------------------------------------------ quantizing

void ny_quantize(const float *rgb, int size, uint16_t *q) {
    size_t N = (size_t)size * size * size;
    for (size_t i = 0; i < N; i++)
        for (int c = 0; c < 3; c++) {
            float v = rgb[i * 3 + c];
            if (!(v > 0.0f)) v = 0.0f;   // (NaN too)
            if (v > 1.0f) v = 1.0f;
            q[c * N + i] = (uint16_t)lrintf(v * 65535.0f);
        }
}

void ny_dequantize_rgba(const uint16_t *q, int size, float *rgba) {
    size_t N = (size_t)size * size * size;
    const float k = 1.0f / 65535.0f;
    for (size_t i = 0; i < N; i++) {
        rgba[i * 4] = q[i] * k;
        rgba[i * 4 + 1] = q[N + i] * k;
        rgba[i * 4 + 2] = q[2 * N + i] * k;
        rgba[i * 4 + 3] = 1.0f;
    }
}

uint64_t ny_look_hash(const uint16_t *q, int size) {
    uint64_t h = 1469598103934665603ULL;
    const uint64_t P = 1099511628211ULL;
    uint32_t s = (uint32_t)size;
    for (int k = 0; k < 4; k++) { h ^= (s >> (8 * k)) & 0xff; h *= P; }
    size_t N = (size_t)size * size * size * 3;
    for (size_t i = 0; i < N; i++) {
        h ^= q[i] & 0xff; h *= P;
        h ^= q[i] >> 8;   h *= P;
    }
    return h;
}

// ------------------------------------------------------------------ packing
// raw:  "NYL1" | u32 size | u32 metaLen | meta | low bytes of the residuals | high bytes of the residuals
// blob: "NYZ1" | u32 raw length | zlib(raw)
// The residuals are each value minus a prediction from its already-coded neighbours (the 3D difference of the 7 lower
// corners of its cell), modulo 65536, so a smooth LUT leaves small numbers that compress well, and decoding is exact.

static inline uint16_t ny_pred(const uint16_t *P, int n, int r, int g, int b) {
#define NYAT(rr, gg, bb) ((int)P[((size_t)(bb) * n + (gg)) * n + (rr)])
    if (r > 0 && g > 0 && b > 0)
        return (uint16_t)(NYAT(r - 1, g, b) + NYAT(r, g - 1, b) + NYAT(r, g, b - 1) - NYAT(r - 1, g - 1, b) - NYAT(r - 1, g, b - 1)
                          - NYAT(r, g - 1, b - 1) + NYAT(r - 1, g - 1, b - 1));
    if (r > 0 && g > 0) return (uint16_t)(NYAT(r - 1, g, b) + NYAT(r, g - 1, b) - NYAT(r - 1, g - 1, b));
    if (r > 0) return (uint16_t)NYAT(r - 1, g, b);
    if (g > 0) return (uint16_t)NYAT(r, g - 1, b);
    if (b > 0) return (uint16_t)NYAT(r, g, b - 1);
    return 0;
#undef NYAT
}

static void ny_put32(uint8_t *p, uint32_t v) { p[0] = v & 0xff; p[1] = (v >> 8) & 0xff; p[2] = (v >> 16) & 0xff; p[3] = (v >> 24) & 0xff; }
static uint32_t ny_get32(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }

uint8_t *ny_pack(const uint16_t *q, int size, const char *meta, size_t metaLen, size_t *outLen) {
    *outLen = 0;
    if (size < NY_LUT_MIN || size > NY_LUT_MAX || metaLen > (16u << 20)) return NULL;
    size_t N = (size_t)size * size * size, V = N * 3;
    size_t rawLen = 12 + metaLen + V * 2;
    uint8_t *raw = (uint8_t *)malloc(rawLen);
    if (!raw) return NULL;
    memcpy(raw, "NYL1", 4);
    ny_put32(raw + 4, (uint32_t)size);
    ny_put32(raw + 8, (uint32_t)metaLen);
    if (metaLen) memcpy(raw + 12, meta, metaLen);
    uint8_t *lo = raw + 12 + metaLen, *hi = lo + V;
    for (int c = 0; c < 3; c++) {
        const uint16_t *P = q + c * N;
        for (int b = 0; b < size; b++)
            for (int g = 0; g < size; g++)
                for (int r = 0; r < size; r++) {
                    size_t i = ((size_t)b * size + g) * size + r;
                    uint16_t res = (uint16_t)(P[i] - ny_pred(P, size, r, g, b));
                    lo[c * N + i] = res & 0xff;
                    hi[c * N + i] = res >> 8;
                }
    }
    uLongf zl = compressBound((uLong)rawLen);
    uint8_t *blob = (uint8_t *)malloc(8 + zl);
    if (!blob) { free(raw); return NULL; }
    memcpy(blob, "NYZ1", 4);
    ny_put32(blob + 4, (uint32_t)rawLen);
    int zr = compress2(blob + 8, &zl, raw, (uLong)rawLen, 6);   // (level 9 saves 2% at 15 times the time)
    free(raw);
    if (zr != Z_OK) { free(blob); return NULL; }
    *outLen = 8 + zl;
    return blob;
}

const char *ny_unpack(const uint8_t *blob, size_t len, uint16_t **q, int *size, char **meta) {
    *q = NULL;
    *size = 0;
    *meta = NULL;
    if (!blob || len < 8 || memcmp(blob, "NYZ1", 4) != 0) return "the look data is not from Nyans";
    uint32_t rawLen = ny_get32(blob + 4);
    if (rawLen < 12 || rawLen > (64u << 20)) return "the look data has an impossible size";
    uint8_t *raw = (uint8_t *)malloc(rawLen);
    if (!raw) return "out of memory";
    uLongf rl = rawLen;
    if (uncompress(raw, &rl, blob + 8, (uLong)(len - 8)) != Z_OK || rl != rawLen) { free(raw); return "the look data is damaged"; }
    if (memcmp(raw, "NYL1", 4) != 0) { free(raw); return "the look data has an unknown version"; }
    uint32_t n = ny_get32(raw + 4), metaLen = ny_get32(raw + 8);
    if (n < NY_LUT_MIN || n > NY_LUT_MAX) { free(raw); return "the look data has an unusual size"; }
    size_t N = (size_t)n * n * n, V = N * 3;
    if ((size_t)rawLen != 12 + (size_t)metaLen + V * 2) { free(raw); return "the look data has the wrong length"; }
    char *m = (char *)malloc((size_t)metaLen + 1);
    uint16_t *out = (uint16_t *)malloc(V * sizeof(uint16_t));
    if (!m || !out) { free(m); free(out); free(raw); return "out of memory"; }
    memcpy(m, raw + 12, metaLen);
    m[metaLen] = 0;
    const uint8_t *lo = raw + 12 + metaLen, *hi = lo + V;
    for (int c = 0; c < 3; c++) {
        uint16_t *P = out + c * N;
        for (int b = 0; b < (int)n; b++)
            for (int g = 0; g < (int)n; g++)
                for (int r = 0; r < (int)n; r++) {
                    size_t i = ((size_t)b * n + g) * n + r;
                    uint16_t res = (uint16_t)(lo[c * N + i] | (hi[c * N + i] << 8));
                    P[i] = (uint16_t)(res + ny_pred(P, (int)n, r, g, b));
                }
    }
    free(raw);
    *q = out;
    *size = (int)n;
    *meta = m;
    return NULL;
}

// ------------------------------------------------------------------ PNG

static void ny_chunk(uint8_t **w, const char *type, const uint8_t *data, uint32_t len) {
    uint8_t *p = *w;
    p[0] = (len >> 24) & 0xff; p[1] = (len >> 16) & 0xff; p[2] = (len >> 8) & 0xff; p[3] = len & 0xff;
    memcpy(p + 4, type, 4);
    if (len) memcpy(p + 8, data, len);
    uLong crc = crc32(0L, Z_NULL, 0);
    crc = crc32(crc, p + 4, len + 4);
    p[8 + len] = (crc >> 24) & 0xff; p[9 + len] = (crc >> 16) & 0xff; p[10 + len] = (crc >> 8) & 0xff; p[11 + len] = crc & 0xff;
    *w = p + 12 + len;
}

uint8_t *ny_png_rgb(const uint8_t *rgba, int w, int h, size_t stride, size_t *outLen) {
    *outLen = 0;
    if (w <= 0 || h <= 0) return NULL;
    size_t rowLen = 1 + (size_t)w * 3, rawLen = rowLen * (size_t)h;
    uint8_t *raw = (uint8_t *)malloc(rawLen);
    if (!raw) return NULL;
    for (int y = 0; y < h; y++) {
        const uint8_t *s = rgba + (size_t)y * stride;
        uint8_t *d = raw + (size_t)y * rowLen;
        d[0] = 1;   // (the Sub filter: each byte minus the one to its left)
        uint8_t pr = 0, pg = 0, pb = 0;
        for (int x = 0; x < w; x++) {
            uint8_t r = s[4 * x], g = s[4 * x + 1], b = s[4 * x + 2];
            d[1 + 3 * x] = (uint8_t)(r - pr);
            d[2 + 3 * x] = (uint8_t)(g - pg);
            d[3 + 3 * x] = (uint8_t)(b - pb);
            pr = r; pg = g; pb = b;
        }
    }
    uLongf zl = compressBound((uLong)rawLen);
    uint8_t *z = (uint8_t *)malloc(zl);
    if (!z) { free(raw); return NULL; }
    if (compress2(z, &zl, raw, (uLong)rawLen, 3) != Z_OK) { free(raw); free(z); return NULL; }
    free(raw);
    size_t total = 8 + (12 + 13) + (12 + zl) + 12;
    uint8_t *png = (uint8_t *)malloc(total), *p = png;
    if (!png) { free(z); return NULL; }
    static const uint8_t sig[8] = { 0x89, 'P', 'N', 'G', 0x0d, 0x0a, 0x1a, 0x0a };
    memcpy(p, sig, 8);
    p += 8;
    uint8_t ihdr[13] = { (uint8_t)(w >> 24), (uint8_t)(w >> 16), (uint8_t)(w >> 8), (uint8_t)w,
                         (uint8_t)(h >> 24), (uint8_t)(h >> 16), (uint8_t)(h >> 8), (uint8_t)h,
                         8, 2, 0, 0, 0 };   // (8 bits per channel, RGB, deflate, adaptive filtering, no interlace)
    ny_chunk(&p, "IHDR", ihdr, 13);
    ny_chunk(&p, "IDAT", z, (uint32_t)zl);
    ny_chunk(&p, "IEND", NULL, 0);
    free(z);
    *outLen = (size_t)(p - png);
    return png;
}
