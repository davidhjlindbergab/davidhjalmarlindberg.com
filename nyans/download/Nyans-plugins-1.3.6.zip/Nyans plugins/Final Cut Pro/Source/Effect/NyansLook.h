// NyansLook.h: a look as the effect stores and renders it.
// The Nyans app bakes the whole grade into a 65-point 3D LUT (every stage of it is colour, per pixel). Apply sends its .cube;
// the effect packs it losslessly into the clip's hidden "Look Data" parameter (so the library carries the grade) and keeps
// a short id in "Look ID" (so a frame's render state stays tiny). Rendering looks the id up here.
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NyansLUT : NSObject
/** a hash of the LUT, what the clip's "Look ID" holds */
@property (nonatomic, readonly, copy) NSString *lookID;
/** points per axis */
@property (nonatomic, readonly) int size;
/** size^3 RGBA floats, R fastest: the memory of a 3D texture */
@property (nonatomic, readonly, strong) NSData *rgba;

/** From the .cube the app bakes. *payload receives the packed "Look Data" string for the clip. */
+ (nullable instancetype)lutWithCube:(NSString *)cube
                                meta:(NSDictionary *)meta
                             payload:(NSString *_Nullable *_Nonnull)payload
                               error:(NSString *_Nullable *_Nullable)error;
/** From a clip's "Look Data" string. */
+ (nullable instancetype)lutWithPayload:(NSString *)payload
                                   meta:(NSDictionary *_Nullable *_Nullable)meta
                                  error:(NSString *_Nullable *_Nullable)error;
@end

/** The looks this process has read, by id. Every Nyans effect on every clip shares it. */
@interface NyansLookStore : NSObject
+ (instancetype)shared;
- (nullable NyansLUT *)lutForID:(NSString *)lookID;
/** The LUT for this id; when it is not in memory, unpacks the string the block returns (the clip's "Look Data"). */
- (nullable NyansLUT *)lutForID:(NSString *)lookID
                        payload:(NSString *_Nullable (^)(void))payload
                          error:(NSString *_Nullable *_Nullable)error;
- (void)addLUT:(NyansLUT *)lut;
@end

NS_ASSUME_NONNULL_END
