// NyansPanel.m: see NyansPanel.h
#import "NyansPanel.h"
#import "NyansFx.h"
#import "NyansPlugIn.h"

#import <WebKit/WebKit.h>

static const NSUInteger kNyKeepClosedPages = 2;      // pages kept after their window closed, newest first
static NSMutableArray<NyansPanel *> *gClosedPanels;  // (main thread)

/** forwards the page's messages, so the content controller does not keep the panel alive */
@interface NyansMessageProxy : NSObject <WKScriptMessageHandler>
@property (nonatomic, weak) id<WKScriptMessageHandler> target;
@end

@implementation NyansMessageProxy
- (void)userContentController:(WKUserContentController *)controller didReceiveScriptMessage:(WKScriptMessage *)message {
    [self.target userContentController:controller didReceiveScriptMessage:message];
}
@end

/** holds the page; says when the window it sits in goes away */
@interface NyansContainerView : NSView
@property (nonatomic, copy, nullable) void (^windowGone)(void);
@end

@implementation NyansContainerView {
    BOOL _hadWindow;
}
- (void)viewDidMoveToWindow {
    [super viewDidMoveToWindow];
    if (self.window) {
        _hadWindow = YES;
    } else if (_hadWindow) {
        _hadWindow = NO;
        if (self.windowGone) self.windowGone();
    }
}
- (BOOL)acceptsFirstMouse:(NSEvent *)event {
    return YES;
}
@end

static NSString *NySafeFileName(NSString *name) {
    NSCharacterSet *bad = [NSCharacterSet characterSetWithCharactersInString:@"/:\\"];
    NSString *s = [[name componentsSeparatedByCharactersInSet:bad] componentsJoinedByString:@"-"];
    s = [s stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    while ([s hasPrefix:@"."]) s = [s substringFromIndex:1];
    if (s.length > 180) s = [s substringToIndex:180];
    return s.length ? s : @"Nyans export";
}

static NSURL *NyUniqueURL(NSURL *dir, NSString *name) {
    NSURL *url = [dir URLByAppendingPathComponent:name];
    NSString *base = name.stringByDeletingPathExtension, *ext = name.pathExtension;
    for (int k = 2; [NSFileManager.defaultManager fileExistsAtPath:url.path] && k < 10000; k++) {
        NSString *n = [NSString stringWithFormat:@"%@ %d", base, k];
        url = [dir URLByAppendingPathComponent:ext.length ? [n stringByAppendingPathExtension:ext] : n];
    }
    return url;
}

@interface NyansPanel () <WKScriptMessageHandler, WKUIDelegate, WKNavigationDelegate, NSWindowDelegate>
@end

@implementation NyansPanel {
    __weak NyansPlugIn *_plugIn;
    WKWebView *_web;
    NyansContainerView *_container;
    NSWindow *_ownWindow;   // (only when Final Cut Pro cannot open one)
    BOOL _opening;          // a window has been asked for
    BOOL _moving;           // the page is being moved between windows
    NSString *_status;
}

- (instancetype)initWithPlugIn:(NyansPlugIn *)plugIn {
    if ((self = [super init])) {
        _plugIn = plugIn;
        if (!gClosedPanels) gClosedPanels = [NSMutableArray array];
    }
    return self;
}

- (void)dealloc {
    [_web.configuration.userContentController removeScriptMessageHandlerForName:@"nyans"];
}

// ------------------------------------------------------------------ the window

- (void)activateApp {
    SEL activate = NSSelectorFromString(@"activate");
    if ([NSApp respondsToSelector:activate]) ((void (*)(id, SEL))[NSApp methodForSelector:activate])(NSApp, activate);
    else [NSApp activateIgnoringOtherApps:YES];
}

- (void)show {
    if (_container.window && _container.window.isVisible) {   // (open already: bring it forward)
        [_container.window makeKeyAndOrderFront:nil];
        if (_container.window == _ownWindow) [self activateApp];
        return;
    }
    if (_opening) return;
    [gClosedPanels removeObject:self];
    NyansPlugIn *p = _plugIn;
    BOOL ownWindow = [NSUserDefaults.standardUserDefaults boolForKey:@"NyansOwnWindow"];
    id<NyFxRemoteWindow> v2 = ownWindow ? nil : NyFxAPI(p.apiManager, "FxRemoteWindowAPI_v2");
    id<NyFxRemoteWindow> v1 = ownWindow || v2 ? nil : NyFxAPI(p.apiManager, "FxRemoteWindowAPI");
    __weak NyansPanel *weakSelf = self;
    void (^reply)(NSView *, NSError *) = ^(NSView *parent, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            NyansPanel *s = weakSelf;
            if (!s || !s->_opening) return;
            s->_opening = NO;
            if (parent) {
                [s attachTo:parent];
            } else {
                NSLog(@"[Nyans] Final Cut Pro did not open a window (%@), so Nyans opens its own", error.localizedDescription ?: @"no reason given");
                [s openOwnWindow];
            }
        });
    };
    if (v2 && [v2 respondsToSelector:@selector(remoteWindowWithMinimumSize:maximumSize:reply:)]) {
        _opening = YES;
        [v2 remoteWindowWithMinimumSize:CGSizeMake(1100, 700) maximumSize:CGSizeMake(5120, 2880) reply:reply];
    } else if (v1 && [v1 respondsToSelector:@selector(remoteWindowOfSize:reply:)]) {
        _opening = YES;
        [v1 remoteWindowOfSize:CGSizeMake(1320, 860) reply:reply];
    } else {
        [self openOwnWindow];
        return;
    }
    // (should Final Cut Pro never answer, open a window of Nyans' own)
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NyansPanel *s = weakSelf;
        if (s && s->_opening) { s->_opening = NO; [s openOwnWindow]; }
    });
}

- (void)openOwnWindow {
    if (!_ownWindow) {
        NSWindowStyleMask style = NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskMiniaturizable | NSWindowStyleMaskResizable;
        NSWindow *w = [[NSWindow alloc] initWithContentRect:NSMakeRect(0, 0, 1320, 860) styleMask:style backing:NSBackingStoreBuffered defer:NO];
        w.title = @"Nyans";
        w.releasedWhenClosed = NO;
        w.minSize = NSMakeSize(900, 600);
        w.appearance = [NSAppearance appearanceNamed:NSAppearanceNameDarkAqua];
        w.backgroundColor = [NSColor colorWithSRGBRed:0.063 green:0.063 blue:0.063 alpha:1];
        w.delegate = self;
        [w center];
        [w setFrameAutosaveName:@"Nyans"];
        _ownWindow = w;
    }
    [self attachTo:_ownWindow.contentView];
    [self activateApp];
    [_ownWindow makeKeyAndOrderFront:nil];
}

- (void)attachTo:(NSView *)parent {
    [self ensurePage];
    _moving = YES;
    [_container removeFromSuperview];
    _container.frame = parent.bounds;
    _container.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    [parent addSubview:_container];
    _moving = NO;
    [gClosedPanels removeObject:self];
    if (parent.window) [parent.window makeFirstResponder:_web];
    if (_status) [self pushStatus:_status];
}

/** the window closed: keep the page for the next Open Nyans, for the most recent clips only */
- (void)windowGone {
    if (_moving || !_web) return;
    [gClosedPanels removeObject:self];
    [gClosedPanels insertObject:self atIndex:0];
    while (gClosedPanels.count > kNyKeepClosedPages) {
        NyansPanel *old = gClosedPanels.lastObject;
        [gClosedPanels removeLastObject];
        [old dropPage];
    }
}

- (void)windowWillClose:(NSNotification *)notification {
    if (notification.object == _ownWindow) [self windowGone];
}

- (void)dropPage {
    [_web.configuration.userContentController removeScriptMessageHandlerForName:@"nyans"];
    [_web stopLoading];
    _moving = YES;
    [_container removeFromSuperview];
    _moving = NO;
    _container.windowGone = nil;
    _container = nil;
    _web = nil;
}

- (void)close {
    _opening = NO;
    [gClosedPanels removeObject:self];
    [self dropPage];
    if (_ownWindow) {
        _ownWindow.delegate = nil;
        [_ownWindow close];
        _ownWindow = nil;
    }
}

// ------------------------------------------------------------------ the page

- (void)ensurePage {
    if (_web) return;
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
    NyansMessageProxy *proxy = [[NyansMessageProxy alloc] init];
    proxy.target = self;
    [config.userContentController addScriptMessageHandler:proxy name:@"nyans"];
    config.websiteDataStore = WKWebsiteDataStore.defaultDataStore;
    NSRect frame = NSMakeRect(0, 0, 1320, 860);
    WKWebView *web = [[WKWebView alloc] initWithFrame:frame configuration:config];
    web.UIDelegate = self;
    web.navigationDelegate = self;
    web.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    web.underPageBackgroundColor = [NSColor colorWithSRGBRed:0.063 green:0.063 blue:0.063 alpha:1];
    if ([web respondsToSelector:NSSelectorFromString(@"setInspectable:")]) [web setValue:@YES forKey:@"inspectable"];   // (Safari's Web Inspector, macOS 13.3+)
    NyansContainerView *box = [[NyansContainerView alloc] initWithFrame:frame];
    web.frame = box.bounds;
    [box addSubview:web];
    __weak NyansPanel *weakSelf = self;
    box.windowGone = ^{ [weakSelf windowGone]; };
    _container = box;
    _web = web;
    NSURL *index = [[NSBundle bundleForClass:self.class] URLForResource:@"index" withExtension:@"html" subdirectory:@"nyans"];
    if (index) {
        [web loadFileURL:index allowingReadAccessToURL:index.URLByDeletingLastPathComponent];
    } else {
        [web loadHTMLString:@"<body style=\"background:#101010;color:#ddd;font:15px -apple-system;padding:40px\">Nyans is incomplete. Run the installer again.</body>" baseURL:nil];
    }
}

- (void)reply:(NSString *)messageID result:(NSDictionary *)result error:(NSString *)error {
    if (!_web) return;
    NSDictionary *args = @{ @"id": messageID, @"ok": @(error == nil), @"result": error ? @{ @"message": error } : (result ?: @{}) };
    [_web callAsyncJavaScript:@"if (window.__nyansReply) window.__nyansReply(id, ok, result);" arguments:args inFrame:nil
               inContentWorld:WKContentWorld.pageWorld completionHandler:nil];
}

- (void)pushStatus:(NSString *)status {
    _status = [status copy];
    if (!_web) return;
    [_web callAsyncJavaScript:@"if (window.__nyansStatus) window.__nyansStatus(text);" arguments:@{ @"text": _status ?: @"" } inFrame:nil
               inContentWorld:WKContentWorld.pageWorld completionHandler:nil];
}

- (void)userContentController:(WKUserContentController *)controller didReceiveScriptMessage:(WKScriptMessage *)message {
    NSDictionary *m = [message.body isKindOfClass:NSDictionary.class] ? message.body : nil;
    NSString *messageID = [m[@"id"] isKindOfClass:NSString.class] ? m[@"id"] : nil;
    NSString *type = [m[@"type"] isKindOfClass:NSString.class] ? m[@"type"] : @"";
    NSDictionary *payload = [m[@"payload"] isKindOfClass:NSDictionary.class] ? m[@"payload"] : @{};
    if (!messageID) return;
    __weak NyansPanel *weakSelf = self;
    void (^done)(NSDictionary *, NSString *) = ^(NSDictionary *result, NSString *error) { [weakSelf reply:messageID result:result error:error]; };
    NyansPlugIn *p = _plugIn;
    if (!p) { done(nil, @"The Nyans effect is no longer on this clip"); return; }
    if ([type isEqualToString:@"hello"]) done([p hello], nil);
    else if ([type isEqualToString:@"grab"]) [p grabFrame:payload reply:done];
    else if ([type isEqualToString:@"apply"]) [p applyLook:payload reply:done];
    else if ([type isEqualToString:@"save"]) [self save:payload reply:done];
    else done(nil, [@"Nyans does not know the request " stringByAppendingString:type]);
}

/** an export from the app (a LUT zip, a still, a clip): to Movies/Nyans */
- (void)save:(NSDictionary *)payload reply:(void (^)(NSDictionary *, NSString *))reply {
    NSString *name = [payload[@"name"] isKindOfClass:NSString.class] ? payload[@"name"] : @"Nyans export";
    NSString *base64 = [payload[@"data"] isKindOfClass:NSString.class] ? payload[@"data"] : nil;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSData *data = base64 ? [[NSData alloc] initWithBase64EncodedString:base64 options:NSDataBase64DecodingIgnoreUnknownCharacters] : nil;
        NSString *error = nil, *shown = nil;
        if (!data.length) {
            error = @"The export arrived empty";
        } else {
            NSURL *movies = [NSFileManager.defaultManager URLsForDirectory:NSMoviesDirectory inDomains:NSUserDomainMask].firstObject;
            NSURL *dir = [movies URLByAppendingPathComponent:@"Nyans" isDirectory:YES];
            [NSFileManager.defaultManager createDirectoryAtURL:dir withIntermediateDirectories:YES attributes:nil error:nil];
            NSURL *url = NyUniqueURL(dir, NySafeFileName(name));
            NSError *e = nil;
            if ([data writeToURL:url options:NSDataWritingAtomic error:&e]) shown = [@"Movies/Nyans/" stringByAppendingString:url.lastPathComponent];
            else error = e.localizedDescription ?: @"The export could not be saved";
        }
        dispatch_async(dispatch_get_main_queue(), ^{ reply(shown ? @{ @"path": shown } : nil, error); });
    });
}

// ------------------------------------------------------------------ WebKit

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)action decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    NSString *scheme = action.request.URL.scheme.lowercaseString;
    if ([scheme isEqualToString:@"http"] || [scheme isEqualToString:@"https"] || [scheme isEqualToString:@"mailto"]) {
        [NSWorkspace.sharedWorkspace openURL:action.request.URL];   // (links leave for the browser; the app stays)
        decisionHandler(WKNavigationActionPolicyCancel);
        return;
    }
    decisionHandler(WKNavigationActionPolicyAllow);
}

- (WKWebView *)webView:(WKWebView *)webView createWebViewWithConfiguration:(WKWebViewConfiguration *)configuration
   forNavigationAction:(WKNavigationAction *)action windowFeatures:(WKWindowFeatures *)features {
    NSURL *url = action.request.URL;
    if ([url.scheme.lowercaseString hasPrefix:@"http"]) [NSWorkspace.sharedWorkspace openURL:url];
    return nil;
}

- (void)webView:(WKWebView *)webView runOpenPanelWithParameters:(WKOpenPanelParameters *)parameters initiatedByFrame:(WKFrameInfo *)frame
completionHandler:(void (^)(NSArray<NSURL *> *))completionHandler {
    NSOpenPanel *panel = [NSOpenPanel openPanel];
    panel.canChooseFiles = YES;
    panel.canChooseDirectories = NO;
    panel.allowsMultipleSelection = parameters.allowsMultipleSelection;
    void (^done)(NSModalResponse) = ^(NSModalResponse r) { completionHandler(r == NSModalResponseOK ? panel.URLs : nil); };
    if (_ownWindow && _container.window == _ownWindow) {
        [panel beginSheetModalForWindow:_ownWindow completionHandler:done];
    } else {
        [self activateApp];
        [panel beginWithCompletionHandler:done];
    }
}

- (void)webViewWebContentProcessDidTerminate:(WKWebView *)webView {
    NSLog(@"[Nyans] the page stopped; reloading it");
    [webView reload];
}

@end
