// nyans_core.h: the parts of the Nyans effect that are plain C, so they build and test anywhere.
//   - reading the .cube the Nyans app bakes (65 points, R fastest)
//   - packing a LUT into the clip's hidden "Look Data" parameter and back (lossless at 16 bits, about 0.7 MB)
//   - the look id (a hash of the packed LUT), which is all a frame's render state carries
//   - a small PNG writer for the frame Nyans reads from Final Cut Pro (no colour chunks: the code values as they are)
#ifndef NYANS_CORE_H
#define NYANS_CORE_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define NY_LUT_MIN 2
#define NY_LUT_MAX 129

/** Parses .cube text. On success returns NULL, *size is the points per axis and *rgb a malloc'd array of size^3 * 3 floats
    (R fastest, then G, then B, as .cube orders them). On failure returns a short message (static storage). */
const char *ny_cube_parse(const char *text, size_t len, int *size, float **rgb);

/** float RGB (size^3 * 3, interleaved) -> planar uint16 (all R, then all G, then all B; R fastest within a plane), 0..1 -> 0..65535 */
void ny_quantize(const float *rgb, int size, uint16_t *q);

/** planar uint16 -> interleaved float RGBA with alpha 1, R fastest: the memory layout of a 3D texture (x = R, y = G, z = B) */
void ny_dequantize_rgba(const uint16_t *q, int size, float *rgba);

/** 64-bit FNV-1a of the size and the planar uint16 LUT: the look id */
uint64_t ny_look_hash(const uint16_t *q, int size);

/** Packs a LUT and a NUL-free metadata string (JSON) into a compressed blob (malloc'd, length in *outLen). NULL on failure. */
uint8_t *ny_pack(const uint16_t *q, int size, const char *meta, size_t metaLen, size_t *outLen);

/** Unpacks a blob from ny_pack: *q (malloc'd planar uint16), *size and *meta (malloc'd, NUL-terminated).
    Returns NULL on success or a short message. */
const char *ny_unpack(const uint8_t *blob, size_t len, uint16_t **q, int *size, char **meta);

/** An 8-bit RGB PNG from RGBA rows (top row first, stride bytes per row; alpha is dropped). malloc'd, length in *outLen. */
uint8_t *ny_png_rgb(const uint8_t *rgba, int w, int h, size_t stride, size_t *outLen);

#ifdef __cplusplus
}
#endif

#endif
