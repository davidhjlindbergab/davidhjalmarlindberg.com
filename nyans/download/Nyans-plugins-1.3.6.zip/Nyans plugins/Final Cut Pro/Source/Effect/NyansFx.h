// NyansFx.h: the part of FxPlug 4 that Nyans uses, declared under Nyans' own names.
//
// The effect does not link FxPlug. Final Cut Pro carries FxPlug.framework and PluginManager.framework; the installer copies
// them into the effect, main() loads them, and every FxPlug class, protocol and constant is looked up by name at run time.
// So the effect builds without the FxPlug SDK, and it never defines a protocol with one of FxPlug's names (the first definition
// of a protocol name wins in the Objective-C runtime, and FxPlug's XPC machinery must see its own).
// The selectors and types below follow Apple's FxPlug 4 reference; the numeric constants follow its headers.
#import <Cocoa/Cocoa.h>
#import <CoreMedia/CoreMedia.h>
#import <Metal/Metal.h>

NS_ASSUME_NONNULL_BEGIN

/** FxRect (Nyans only copies it, so only its size matters: four 32-bit integers) */
typedef struct { int32_t left, bottom, right, top; } NyFxRect;
typedef uint32_t NyFxParameterFlags;

// FxParameterFlags
static const NyFxParameterFlags NyFxFlag_DEFAULT = 0;
static const NyFxParameterFlags NyFxFlag_NOT_ANIMATABLE = 1u << 0;
static const NyFxParameterFlags NyFxFlag_HIDDEN = 1u << 1;
static const NyFxParameterFlags NyFxFlag_CUSTOM_UI = 1u << 6;
// FxImageColorInfo
static const NSUInteger NyFxImageColorInfo_RGB_GAMMA_VIDEO = 2;
// FxImageOrigin
static const NSUInteger NyFxImageOrigin_BOTTOM_LEFT = 0;

/** PROAPIAccessing */
@protocol NyFxAPIManager <NSObject>
- (nullable id)apiForProtocol:(Protocol *)protocol;
@end

/** FxParameterCreationAPI_v5 */
@protocol NyFxParamCreate <NSObject>
- (BOOL)addCustomParameterWithName:(NSString *)name parameterID:(UInt32)parameterID defaultValue:(id<NSCopying, NSSecureCoding, NSObject>)defaultValue parameterFlags:(NyFxParameterFlags)flags;
- (BOOL)addPercentSliderWithName:(NSString *)name parameterID:(UInt32)parameterID defaultValue:(double)defaultValue parameterMin:(double)parameterMin parameterMax:(double)parameterMax sliderMin:(double)sliderMin sliderMax:(double)sliderMax delta:(double)delta parameterFlags:(NyFxParameterFlags)flags;
- (BOOL)addStringParameterWithName:(NSString *)name parameterID:(UInt32)parameterID defaultValue:(NSString *)defaultValue parameterFlags:(NyFxParameterFlags)flags;
- (BOOL)addIntSliderWithName:(NSString *)name parameterID:(UInt32)parameterID defaultValue:(int)defaultValue parameterMin:(int)parameterMin parameterMax:(int)parameterMax sliderMin:(int)sliderMin sliderMax:(int)sliderMax delta:(int)delta parameterFlags:(NyFxParameterFlags)flags;
@end

/** FxParameterRetrievalAPI_v6 */
@protocol NyFxParamGet <NSObject>
- (BOOL)getFloatValue:(double *)value fromParameter:(UInt32)parameterID atTime:(CMTime)time;
- (BOOL)getIntValue:(int *)value fromParameter:(UInt32)parameterID atTime:(CMTime)time;
- (BOOL)getStringParameterValue:(NSString *_Nullable __autoreleasing *_Nonnull)value fromParameter:(UInt32)parameterID;
@end

/** FxParameterSettingAPI_v5 */
@protocol NyFxParamSet <NSObject>
- (BOOL)setIntValue:(int)value toParameter:(UInt32)parameterID atTime:(CMTime)time;
- (BOOL)setStringParameterValue:(NSString *)value toParameter:(UInt32)parameterID;
@end

/** FxCustomParameterActionAPI_v4 */
@protocol NyFxAction <NSObject>
- (void)startAction:(id)sender;
- (void)endAction:(id)sender;
- (CMTime)currentTime;
@end

/** FxTimingAPI_v4 */
@protocol NyFxTiming <NSObject>
- (void)timelineTime:(CMTime *)timelineTime fromInputTime:(CMTime)inputTime;
- (NSInteger)timelineFpsNumeratorForEffect:(id)effect;
- (NSInteger)timelineFpsDenominatorForEffect:(id)effect;
@end

/** FxRemoteWindowAPI (v1) and FxRemoteWindowAPI_v2 */
@protocol NyFxRemoteWindow <NSObject>
- (void)remoteWindowOfSize:(CGSize)contentSize reply:(void (^)(NSView *_Nullable parentView, NSError *_Nullable error))reply;
- (void)remoteWindowWithMinimumSize:(CGSize)minimumSize maximumSize:(CGSize)maximumSize reply:(void (^)(NSView *_Nullable parentView, NSError *_Nullable error))reply;
@end

/** FxImageTile */
@protocol NyFxImageTile <NSObject>
- (NyFxRect)imagePixelBounds;
- (NyFxRect)tilePixelBounds;
- (uint64_t)deviceRegistryID;
- (NSUInteger)imageOrigin;
- (nullable CGColorSpaceRef)colorSpace;
- (nullable id<MTLTexture>)metalTextureForDevice:(id<MTLDevice>)device;
@end

#ifdef __cplusplus
extern "C" {
#endif

/** Loads PluginManager.framework and FxPlug.framework from the effect's own Frameworks folder. NO (with a reason) if missing. */
BOOL NyFxLoadFrameworks(NSString *_Nullable *_Nullable problem);
/** The host's API object for an FxPlug protocol name ("FxParameterCreationAPI_v5"), or nil when the host does not offer it. */
id _Nullable NyFxAPI(id<NyFxAPIManager> _Nullable manager, const char *protocolName);
/** An NSString constant FxPlug exports (kFxPropertyKey_...), or nil. */
NSString *_Nullable NyFxString(const char *symbol);
/** Makes cls conform to the FxPlug protocol of that name (once FxPlug is loaded). */
void NyFxAdopt(Class cls, const char *protocolName);
/** Hands the process to FxPlug's XPC service. Does not return. */
void NyFxStartService(void) __attribute__((noreturn));
/** The error domain FxPlug uses, or Nyans' own. */
NSString *NyFxErrorDomain(void);

#ifdef __cplusplus
}
#endif

NS_ASSUME_NONNULL_END
