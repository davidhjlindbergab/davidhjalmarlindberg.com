// NyansRenderer.m: see NyansRenderer.h
#import "NyansRenderer.h"
#import "NyansLook.h"

typedef struct { float mix; uint32_t size, wide, pad; } NyU;                              // (NyansShaders.metal: NyU)
typedef struct { float rx, ry, srcW, srcH; uint32_t flipY, wide, pad0, pad1; } NyC;       // (NyansShaders.metal: NyC)

static const NSUInteger kNyTexturesPerGPU = 6;

@implementation NyansCapture
@end

/** one GPU: its queue, the compiled shaders, a pipeline per pixel format and the LUT textures */
@interface NyansGPU : NSObject
@property (nonatomic, strong, readonly) id<MTLDevice> device;
@property (nonatomic, strong, readonly) id<MTLCommandQueue> queue;
- (instancetype)initWithDevice:(id<MTLDevice>)device;
- (nullable id<MTLRenderPipelineState>)pipelineForFormat:(MTLPixelFormat)format;
- (nullable id<MTLRenderPipelineState>)capturePipeline;
- (nullable id<MTLTexture>)textureForLUT:(NyansLUT *)lut;
- (nullable id<MTLTexture>)emptyLUT;
@end

@implementation NyansGPU {
    NSLock *_lock;
    id<MTLLibrary> _library;
    BOOL _triedLibrary;
    NSMutableDictionary<NSNumber *, id<MTLRenderPipelineState>> *_pipelines;
    id<MTLRenderPipelineState> _capture;
    NSMutableDictionary<NSString *, id<MTLTexture>> *_luts;
    NSMutableArray<NSString *> *_order;
    id<MTLTexture> _empty;
}

- (instancetype)initWithDevice:(id<MTLDevice>)device {
    if ((self = [super init])) {
        _device = device;
        _queue = [device newCommandQueue];
        _lock = [[NSLock alloc] init];
        _pipelines = [NSMutableDictionary dictionary];
        _luts = [NSMutableDictionary dictionary];
        _order = [NSMutableArray array];
    }
    return self;
}

/** (under _lock) the shaders, compiled once from the effect's resources */
- (id<MTLLibrary>)library {
    if (!_triedLibrary) {
        _triedLibrary = YES;
        NSString *path = [[NSBundle bundleForClass:self.class] pathForResource:@"NyansShaders" ofType:@"metal"];
        NSString *source = path ? [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil] : nil;
        if (!source.length) {
            NSLog(@"[Nyans] NyansShaders.metal is missing from the effect, so looks show as the clip is");
        } else {
            NSError *e = nil;
            _library = [_device newLibraryWithSource:source options:nil error:&e];
            if (!_library) NSLog(@"[Nyans] the shaders did not compile on %@: %@", _device.name, e);
        }
    }
    return _library;
}

- (id<MTLRenderPipelineState>)pipelineNamed:(NSString *)fragment format:(MTLPixelFormat)format {
    id<MTLLibrary> lib = [self library];
    if (!lib) return nil;
    MTLRenderPipelineDescriptor *d = [[MTLRenderPipelineDescriptor alloc] init];
    d.vertexFunction = [lib newFunctionWithName:@"nyans_vs"];
    d.fragmentFunction = [lib newFunctionWithName:fragment];
    d.colorAttachments[0].pixelFormat = format;
    NSError *e = nil;
    id<MTLRenderPipelineState> ps = [_device newRenderPipelineStateWithDescriptor:d error:&e];
    if (!ps) NSLog(@"[Nyans] no pipeline for %@ (pixel format %lu): %@", fragment, (unsigned long)format, e);
    return ps;
}

- (id<MTLRenderPipelineState>)pipelineForFormat:(MTLPixelFormat)format {
    [_lock lock];
    id<MTLRenderPipelineState> ps = _pipelines[@(format)];
    if (!ps) {
        ps = [self pipelineNamed:@"nyans_fs" format:format];
        if (ps) _pipelines[@(format)] = ps;
    }
    [_lock unlock];
    return ps;
}

- (id<MTLRenderPipelineState>)capturePipeline {
    [_lock lock];
    if (!_capture) _capture = [self pipelineNamed:@"nyans_cap" format:MTLPixelFormatRGBA8Unorm];
    id<MTLRenderPipelineState> ps = _capture;
    [_lock unlock];
    return ps;
}

- (id<MTLTexture>)newLUTTexture:(int)n bytes:(const void *)bytes {
    MTLTextureDescriptor *d = [[MTLTextureDescriptor alloc] init];
    d.textureType = MTLTextureType3D;
    d.pixelFormat = MTLPixelFormatRGBA32Float;
    d.width = (NSUInteger)n;
    d.height = (NSUInteger)n;
    d.depth = (NSUInteger)n;
    d.usage = MTLTextureUsageShaderRead;
    d.storageMode = _device.hasUnifiedMemory ? MTLStorageModeShared : MTLStorageModeManaged;
    id<MTLTexture> t = [_device newTextureWithDescriptor:d];
    if (t && bytes)
        [t replaceRegion:MTLRegionMake3D(0, 0, 0, (NSUInteger)n, (NSUInteger)n, (NSUInteger)n) mipmapLevel:0 slice:0 withBytes:bytes
             bytesPerRow:(NSUInteger)n * 16 bytesPerImage:(NSUInteger)n * (NSUInteger)n * 16];
    return t;
}

- (id<MTLTexture>)textureForLUT:(NyansLUT *)lut {
    [_lock lock];
    id<MTLTexture> t = _luts[lut.lookID];
    if (!t) {
        t = [self newLUTTexture:lut.size bytes:lut.rgba.bytes];
        if (t) {
            _luts[lut.lookID] = t;
            while (_order.count >= kNyTexturesPerGPU) {
                [_luts removeObjectForKey:_order.firstObject];
                [_order removeObjectAtIndex:0];
            }
        }
    } else {
        [_order removeObject:lut.lookID];
    }
    if (t) [_order addObject:lut.lookID];
    [_lock unlock];
    return t;
}

- (id<MTLTexture>)emptyLUT {
    [_lock lock];
    if (!_empty) {
        static const float zero[2 * 2 * 2 * 4] = { 0 };
        _empty = [self newLUTTexture:2 bytes:zero];
    }
    id<MTLTexture> t = _empty;
    [_lock unlock];
    return t;
}

@end

static BOOL NyIsWideGamut(id<NyFxImageTile> tile) {
    if (![tile respondsToSelector:@selector(colorSpace)]) return NO;
    CGColorSpaceRef cs = [tile colorSpace];
    if (!cs) return NO;
    CFStringRef name = CGColorSpaceCopyName(cs);
    if (!name) return NO;
    NSString *n = (__bridge_transfer NSString *)name;
    return [n containsString:@"2020"] || [n containsString:@"2100"];
}

static BOOL NyFail(NSError **error, NSString *message) {
    NSLog(@"[Nyans] %@", message);
    if (error) *error = [NSError errorWithDomain:NyFxErrorDomain() code:1 userInfo:@{ NSLocalizedDescriptionKey: message }];
    return NO;
}

@implementation NyansRenderer {
    NSLock *_lock;
    NSMutableDictionary<NSNumber *, NyansGPU *> *_gpus;
}

+ (instancetype)shared {
    static NyansRenderer *r;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ r = [[NyansRenderer alloc] init]; });
    return r;
}

- (instancetype)init {
    if ((self = [super init])) {
        _lock = [[NSLock alloc] init];
        _gpus = [NSMutableDictionary dictionary];
    }
    return self;
}

- (NyansGPU *)gpuForRegistryID:(uint64_t)registryID {
    [_lock lock];
    NyansGPU *gpu = _gpus[@(registryID)];
    if (!gpu) {
        for (id<MTLDevice> d in MTLCopyAllDevices())
            if (d.registryID == registryID) { gpu = [[NyansGPU alloc] initWithDevice:d]; break; }
        if (!gpu) {   // (a single-GPU Mac whose id did not match: use the system GPU)
            id<MTLDevice> d = MTLCreateSystemDefaultDevice();
            if (d) gpu = [[NyansGPU alloc] initWithDevice:d];
        }
        if (gpu) _gpus[@(registryID)] = gpu;
    }
    [_lock unlock];
    return gpu;
}

- (BOOL)renderSource:(id<NyFxImageTile>)src
         destination:(id<NyFxImageTile>)dst
                 lut:(NyansLUT *)lut
                 mix:(float)mix
             capture:(NyansCapture *)capture
               error:(NSError **)error {
    NyansGPU *gpu = [self gpuForRegistryID:[dst deviceRegistryID]];
    if (!gpu || !gpu.queue) return NyFail(error, @"the GPU Final Cut Pro renders on is not available");
    id<MTLTexture> inTex = [src metalTextureForDevice:gpu.device];
    id<MTLTexture> outTex = [dst metalTextureForDevice:gpu.device];
    if (!inTex || !outTex) return NyFail(error, @"Final Cut Pro gave the effect no textures for this frame");
    NSUInteger w = MIN(inTex.width, outTex.width), h = MIN(inTex.height, outTex.height);
    BOOL wide = NyIsWideGamut(src);

    id<MTLCommandBuffer> cb = [gpu.queue commandBuffer];
    cb.label = @"Nyans";
    id<MTLRenderPipelineState> ps = [gpu pipelineForFormat:outTex.pixelFormat];
    if (ps) {
        MTLRenderPassDescriptor *rp = [MTLRenderPassDescriptor renderPassDescriptor];
        rp.colorAttachments[0].texture = outTex;
        rp.colorAttachments[0].loadAction = (w == outTex.width && h == outTex.height) ? MTLLoadActionDontCare : MTLLoadActionLoad;
        rp.colorAttachments[0].storeAction = MTLStoreActionStore;
        id<MTLRenderCommandEncoder> enc = [cb renderCommandEncoderWithDescriptor:rp];
        MTLViewport vp = { 0.0, 0.0, (double)w, (double)h, 0.0, 1.0 };
        [enc setViewport:vp];
        [enc setRenderPipelineState:ps];
        id<MTLTexture> lt = lut ? [gpu textureForLUT:lut] : nil;
        [enc setFragmentTexture:inTex atIndex:0];
        [enc setFragmentTexture:(lt ? lt : [gpu emptyLUT]) atIndex:1];
        NyU u = { mix, lt ? (uint32_t)lut.size : 0u, wide ? 1u : 0u, 0u };
        [enc setFragmentBytes:&u length:sizeof u atIndex:0];
        [enc drawPrimitives:MTLPrimitiveTypeTriangle vertexStart:0 vertexCount:3];
        [enc endEncoding];
    } else if (inTex.pixelFormat == outTex.pixelFormat) {
        // (no shaders: show the clip as it is rather than garbage)
        id<MTLBlitCommandEncoder> bl = [cb blitCommandEncoder];
        [bl copyFromTexture:inTex sourceSlice:0 sourceLevel:0 sourceOrigin:MTLOriginMake(0, 0, 0) sourceSize:MTLSizeMake(w, h, 1)
                  toTexture:outTex destinationSlice:0 destinationLevel:0 destinationOrigin:MTLOriginMake(0, 0, 0)];
        [bl endEncoding];
    }

    id<MTLBuffer> capBuf = nil;
    NSUInteger cw = 0, ch = 0;
    if (capture) {
        double scale = MIN(1.0, (double)MAX(capture.maxSide, (NSInteger)64) / (double)MAX(w, h));
        cw = MAX((NSUInteger)1, (NSUInteger)lround((double)w * scale));
        ch = MAX((NSUInteger)1, (NSUInteger)lround((double)h * scale));
        MTLTextureDescriptor *td = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatRGBA8Unorm width:cw height:ch mipmapped:NO];
        td.usage = MTLTextureUsageRenderTarget | MTLTextureUsageShaderRead;
        td.storageMode = MTLStorageModePrivate;
        id<MTLTexture> ct = [gpu.device newTextureWithDescriptor:td];
        capBuf = [gpu.device newBufferWithLength:cw * ch * 4 options:MTLResourceStorageModeShared];
        id<MTLRenderPipelineState> cps = [gpu capturePipeline];
        if (ct && capBuf && cps) {
            MTLRenderPassDescriptor *rp = [MTLRenderPassDescriptor renderPassDescriptor];
            rp.colorAttachments[0].texture = ct;
            rp.colorAttachments[0].loadAction = MTLLoadActionDontCare;
            rp.colorAttachments[0].storeAction = MTLStoreActionStore;
            id<MTLRenderCommandEncoder> enc = [cb renderCommandEncoderWithDescriptor:rp];
            MTLViewport vp = { 0.0, 0.0, (double)cw, (double)ch, 0.0, 1.0 };
            [enc setViewport:vp];
            [enc setRenderPipelineState:cps];
            [enc setFragmentTexture:inTex atIndex:0];
            BOOL bottomUp = [src respondsToSelector:@selector(imageOrigin)] && [src imageOrigin] == NyFxImageOrigin_BOTTOM_LEFT;
            NyC k = { (float)w / (float)cw, (float)h / (float)ch, (float)w, (float)h, bottomUp ? 1u : 0u, wide ? 1u : 0u, 0u, 0u };
            [enc setFragmentBytes:&k length:sizeof k atIndex:0];
            [enc drawPrimitives:MTLPrimitiveTypeTriangle vertexStart:0 vertexCount:3];
            [enc endEncoding];
            id<MTLBlitCommandEncoder> bl = [cb blitCommandEncoder];
            [bl copyFromTexture:ct sourceSlice:0 sourceLevel:0 sourceOrigin:MTLOriginMake(0, 0, 0) sourceSize:MTLSizeMake(cw, ch, 1)
                       toBuffer:capBuf destinationOffset:0 destinationBytesPerRow:cw * 4 destinationBytesPerImage:cw * ch * 4];
            [bl endEncoding];
        } else {
            capBuf = nil;
            capture.failure = @"the frame could not be copied on the GPU";
        }
    }

    [cb commit];
    [cb waitUntilCompleted];
    if (cb.status == MTLCommandBufferStatusError) {
        if (capture) capture.failure = @"the GPU stopped while copying the frame";
        return NyFail(error, [NSString stringWithFormat:@"the GPU stopped: %@", cb.error.localizedDescription ?: @"unknown error"]);
    }
    if (capture && capBuf) {
        capture.rgba = [NSData dataWithBytes:capBuf.contents length:cw * ch * 4];
        capture.width = (int)cw;
        capture.height = (int)ch;
    }
    return YES;
}

@end
