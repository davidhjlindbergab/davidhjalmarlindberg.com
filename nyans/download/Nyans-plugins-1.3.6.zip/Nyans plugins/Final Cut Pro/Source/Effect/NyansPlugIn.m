// NyansPlugIn.m: see NyansPlugIn.h
#import "NyansPlugIn.h"
#import "NyansHeaderView.h"
#import "NyansLook.h"
#import "NyansPanel.h"
#import "NyansRenderer.h"
#import "nyans_core.h"

#import <os/lock.h>

// ------------------------------------------------------------------ the render state of one frame (pluginState)

static const uint32_t kNyStateMagic = 0x3153594e;   // 'NYS1'
static const uint32_t kNyStateTimed = 1u << 0;      // timeSec is the frame's timeline time

typedef struct {
    uint32_t magic;
    uint32_t flags;
    double mix;
    double timeSec;
    int32_t frameRequest;
    uint32_t reserved;
    char lookID[40];
} NyState;

static BOOL NyReadState(NSData *data, NyState *s) {
    memset(s, 0, sizeof *s);
    s->mix = 1.0;
    if (data.length != sizeof(NyState)) return NO;
    memcpy(s, data.bytes, sizeof *s);
    s->lookID[sizeof s->lookID - 1] = 0;
    return s->magic == kNyStateMagic;
}

static BOOL NyError(NSError **error, NSString *message) {
    NSLog(@"[Nyans] %@", message);
    if (error) *error = [NSError errorWithDomain:NyFxErrorDomain() code:2 userInfo:@{ NSLocalizedDescriptionKey: message }];
    return NO;
}

static NSString *NyFrameName(double sec, double fps) {
    if (!(fps > 0) || !isfinite(sec) || sec < 0) return @"Playhead frame";
    long nominal = MAX(1L, lround(fps));
    long long frames = llround(sec * fps), s = frames / nominal, f = frames % nominal;
    return [NSString stringWithFormat:@"Frame at %02lld:%02lld:%02lld:%02lld", s / 3600, (s / 60) % 60, s % 60, f];
}

// ------------------------------------------------------------------ a Grab frame request

@interface NyansGrab : NSObject
@property (nonatomic) int token;          // the Frame Request value that marks the renders it asked for
@property (nonatomic) BOOL timed;         // the playhead time is known
@property (nonatomic) double playhead;    // timeline seconds
@property (nonatomic) double tolerance;   // half a frame
@property (nonatomic) double fps;
@property (nonatomic) NSInteger maxSide;
@property (nonatomic) BOOL done;
@property (nonatomic) BOOL matchTaken;    // a render of the playhead frame is being copied
@property (nonatomic) BOOL standInTaken;  // a render of another frame is being copied, in case the playhead frame never renders
@property (nonatomic, strong, nullable) NyansCapture *standIn;
@property (nonatomic, copy, nullable) void (^reply)(NSDictionary *_Nullable, NSString *_Nullable);
@end

@implementation NyansGrab
@end

// ------------------------------------------------------------------ the effect

@implementation NyansPlugIn {
    os_unfair_lock _grabLock;   // guards _grab (renders run on many threads)
    NyansGrab *_grab;
    NyansPanel *_panel;         // (main thread)
    NSHashTable<NyansHeaderView *> *_headers;
    NSString *_title;           // the applied look's name (main thread)
}

- (instancetype)initWithAPIManager:(id<NyFxAPIManager>)apiManager {
    if ((self = [super init])) {
        _apiManager = apiManager;
        _grabLock = OS_UNFAIR_LOCK_INIT;
        _headers = [NSHashTable weakObjectsHashTable];
    }
    return self;
}

- (void)dealloc {
    NyansPanel *panel = _panel;
    if (panel) dispatch_async(dispatch_get_main_queue(), ^{ [panel close]; });
}

- (nullable id)api:(const char *)protocolName {
    return NyFxAPI(_apiManager, protocolName);
}

// ------------------------------------------------------------------ FxTileableEffect

- (BOOL)properties:(NSDictionary **)properties error:(NSError **)error {
    NSMutableDictionary *p = [NSMutableDictionary dictionary];
    void (^put)(const char *, id) = ^(const char *key, id value) {
        NSString *k = NyFxString(key);
        if (k) p[k] = value;
        else NSLog(@"[Nyans] FxPlug does not export %s", key);
    };
    put("kFxPropertyKey_NeedsFullBuffer", @YES);          // (the whole frame at once: Grab frame copies all of it)
    put("kFxPropertyKey_ChangesOutputSize", @NO);
    put("kFxPropertyKey_VariesWhenParamsAreStatic", @NO);
    put("kFxPropertyKey_MayRemapTime", @NO);
    put("kFxPropertyKey_DesiredProcessingColorInfo", @(NyFxImageColorInfo_RGB_GAMMA_VIDEO));   // (the code values the look was made for)
    *properties = p;
    return YES;
}

- (BOOL)addParametersWithError:(NSError **)error {
    id<NyFxParamCreate> create = [self api:"FxParameterCreationAPI_v5"];
    if (!create) return NyError(error, @"Final Cut Pro did not offer the parameter API");
    const NyFxParameterFlags hidden = NyFxFlag_HIDDEN | NyFxFlag_NOT_ANIMATABLE;
    BOOL ok = [create addCustomParameterWithName:@"Look" parameterID:kNyansParam_Look defaultValue:@0
                                  parameterFlags:NyFxFlag_CUSTOM_UI | NyFxFlag_NOT_ANIMATABLE];
    ok = [create addPercentSliderWithName:@"Mix" parameterID:kNyansParam_Mix defaultValue:1.0 parameterMin:0.0 parameterMax:1.0
                                sliderMin:0.0 sliderMax:1.0 delta:0.01 parameterFlags:NyFxFlag_DEFAULT] && ok;
    ok = [create addStringParameterWithName:@"Look ID" parameterID:kNyansParam_LookID defaultValue:@"" parameterFlags:hidden] && ok;
    ok = [create addStringParameterWithName:@"Look Data" parameterID:kNyansParam_LookData defaultValue:@"" parameterFlags:hidden] && ok;
    ok = [create addStringParameterWithName:@"Look Title" parameterID:kNyansParam_LookTitle defaultValue:@"" parameterFlags:hidden] && ok;
    ok = [create addIntSliderWithName:@"Frame Request" parameterID:kNyansParam_FrameRequest defaultValue:0 parameterMin:0
                         parameterMax:1000000000 sliderMin:0 sliderMax:1000000000 delta:1 parameterFlags:hidden] && ok;
    if (!ok) return NyError(error, @"Final Cut Pro did not take the Nyans parameters");
    return YES;
}

- (BOOL)parameterChanged:(UInt32)paramID atTime:(CMTime)time error:(NSError **)error {
    if (paramID == kNyansParam_LookTitle || paramID == kNyansParam_LookID) {   // (an undo, a paste of attributes, our own Apply)
        id<NyFxParamGet> get = [self api:"FxParameterRetrievalAPI_v6"];
        NSString *title = nil;
        if (get) [get getStringParameterValue:&title fromParameter:kNyansParam_LookTitle];
        __weak NyansPlugIn *weakSelf = self;
        dispatch_async(dispatch_get_main_queue(), ^{ [weakSelf setTitle:title]; });
    }
    return YES;
}

- (BOOL)pluginState:(NSData **)pluginState atTime:(CMTime)renderTime quality:(NSUInteger)quality error:(NSError **)error {
    id<NyFxParamGet> get = [self api:"FxParameterRetrievalAPI_v6"];
    if (!get) return NyError(error, @"Final Cut Pro did not offer the parameter API");
    NyState s;
    memset(&s, 0, sizeof s);
    s.magic = kNyStateMagic;
    double mix = 1.0;
    [get getFloatValue:&mix fromParameter:kNyansParam_Mix atTime:renderTime];
    s.mix = isfinite(mix) ? MIN(MAX(mix, 0.0), 1.0) : 1.0;
    int request = 0;
    [get getIntValue:&request fromParameter:kNyansParam_FrameRequest atTime:renderTime];
    s.frameRequest = request;

    NSString *lookID = nil;
    [get getStringParameterValue:&lookID fromParameter:kNyansParam_LookID];
    if (lookID.length && lookID.length < sizeof s.lookID) {
        // (the look itself is read from the clip only the first time this process sees its id)
        NSString *problem = nil;
        NyansLUT *lut = [NyansLookStore.shared lutForID:lookID payload:^NSString * {
            NSString *data = nil;
            [get getStringParameterValue:&data fromParameter:kNyansParam_LookData];
            return data;
        } error:&problem];
        if (lut) strlcpy(s.lookID, lookID.UTF8String, sizeof s.lookID);
        else NSLog(@"[Nyans] the look on this clip could not be read (%@): the clip shows without it", problem);
    }

    id<NyFxTiming> timing = [self api:"FxTimingAPI_v4"];
    if (timing) {
        CMTime tl = kCMTimeInvalid;
        [timing timelineTime:&tl fromInputTime:renderTime];
        if (CMTIME_IS_NUMERIC(tl)) { s.timeSec = CMTimeGetSeconds(tl); s.flags |= kNyStateTimed; }
    }
    *pluginState = [NSData dataWithBytes:&s length:sizeof s];
    return YES;
}

- (BOOL)destinationImageRect:(NyFxRect *)destinationImageRect sourceImages:(NSArray *)sourceImages destinationImage:(id<NyFxImageTile>)destinationImage
                 pluginState:(NSData *)pluginState atTime:(CMTime)renderTime error:(NSError **)error {
    if (sourceImages.count < 1) return NyError(error, @"the effect received no image");
    *destinationImageRect = [(id<NyFxImageTile>)sourceImages[0] imagePixelBounds];
    return YES;
}

- (BOOL)sourceTileRect:(NyFxRect *)sourceTileRect sourceImageIndex:(NSUInteger)sourceImageIndex sourceImages:(NSArray *)sourceImages
   destinationTileRect:(NyFxRect)destinationTileRect destinationImage:(id<NyFxImageTile>)destinationImage pluginState:(NSData *)pluginState
                atTime:(CMTime)renderTime error:(NSError **)error {
    *sourceTileRect = destinationTileRect;   // (a colour effect: each pixel from the same pixel)
    return YES;
}

- (BOOL)renderDestinationImage:(id<NyFxImageTile>)destinationImage sourceImages:(NSArray *)sourceImages pluginState:(NSData *)pluginState
                        atTime:(CMTime)renderTime error:(NSError **)error {
    if (sourceImages.count < 1) return NyError(error, @"the effect received no image");
    NyState s;
    if (!NyReadState(pluginState, &s)) NSLog(@"[Nyans] a frame came without its state: rendering the clip as it is");
    NyansLUT *lut = s.lookID[0] ? [NyansLookStore.shared lutForID:[NSString stringWithUTF8String:s.lookID]] : nil;
    NyansGrab *grab = nil;
    NyansCapture *capture = [self captureForState:&s grab:&grab];
    BOOL ok = [NyansRenderer.shared renderSource:sourceImages[0] destination:destinationImage lut:lut mix:(float)s.mix capture:capture error:error];
    if (capture) {
        __weak NyansPlugIn *weakSelf = self;
        dispatch_async(dispatch_get_main_queue(), ^{ [weakSelf captured:capture grab:grab]; });
    }
    return ok;
}

// ------------------------------------------------------------------ the inspector row

- (NSView *)createViewForParameterID:(UInt32)parameterID {
    if (parameterID != kNyansParam_Look) return nil;
    NyansHeaderView *view = [[NyansHeaderView alloc] initWithPlugIn:self];
    [view setLookTitle:_title];
    @synchronized (_headers) { [_headers addObject:view]; }
    __weak NyansPlugIn *weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{ [weakSelf readTitle]; });   // (the clip's look, read in an action of our own)
    return view;
}

- (void)readTitle {
    id<NyFxAction> action = [self api:"FxCustomParameterActionAPI_v4"];
    id<NyFxParamGet> get = [self api:"FxParameterRetrievalAPI_v6"];
    if (!action || !get) return;
    NSString *title = nil;
    [action startAction:self];
    [get getStringParameterValue:&title fromParameter:kNyansParam_LookTitle];
    [action endAction:self];
    [self setTitle:title];
}

- (void)setTitle:(NSString *)title {
    _title = title.length ? [title copy] : nil;
    NSArray<NyansHeaderView *> *views;
    @synchronized (_headers) { views = _headers.allObjects; }
    for (NyansHeaderView *v in views) [v setLookTitle:_title];
    [_panel pushStatus:_title];
}

// ------------------------------------------------------------------ the window

- (void)openPanel {
    if (!NSThread.isMainThread) { dispatch_async(dispatch_get_main_queue(), ^{ [self openPanel]; }); return; }
    if (!_panel) _panel = [[NyansPanel alloc] initWithPlugIn:self];
    [_panel pushStatus:_title];
    [_panel show];
}

- (NSDictionary *)hello {
    return @{ @"status": _title ?: @"" };
}

// ------------------------------------------------------------------ Grab frame
// Nyans bumps the hidden Frame Request parameter (in an action of its own), which makes Final Cut Pro render the frame at the
// playhead again. That render carries the new value in its state, and the effect copies its input on the way through. If the
// renders that follow are of other frames only (the playhead is not over this clip, or a background render came first), the
// first of them stands in after a moment, and the page says so.

- (NyansGrab *)currentGrab {
    os_unfair_lock_lock(&_grabLock);
    NyansGrab *g = _grab;
    os_unfair_lock_unlock(&_grabLock);
    return g;
}

/** (any thread) a copy this render should make, or nil */
- (NyansCapture *)captureForState:(const NyState *)s grab:(NyansGrab **)grabOut {
    NyansCapture *capture = nil;
    os_unfair_lock_lock(&_grabLock);
    NyansGrab *g = _grab;
    if (g && !g.done && s->frameRequest == g.token) {
        BOOL timed = g.timed && (s->flags & kNyStateTimed);
        BOOL match = !timed || fabs(s->timeSec - g.playhead) <= g.tolerance;
        if ((match && !g.matchTaken) || (!match && !g.standInTaken)) {
            if (match) g.matchTaken = YES;
            else g.standInTaken = YES;
            capture = [[NyansCapture alloc] init];
            capture.maxSide = g.maxSide;
            capture.matched = match;
            capture.timeSec = (s->flags & kNyStateTimed) ? s->timeSec : g.playhead;
            *grabOut = g;
        }
    }
    os_unfair_lock_unlock(&_grabLock);
    return capture;
}

- (void)grabFrame:(NSDictionary *)request reply:(void (^)(NSDictionary *, NSString *))reply {
    id<NyFxAction> action = [self api:"FxCustomParameterActionAPI_v4"];
    id<NyFxParamGet> get = [self api:"FxParameterRetrievalAPI_v6"];
    id<NyFxParamSet> set = [self api:"FxParameterSettingAPI_v5"];
    id<NyFxTiming> timing = [self api:"FxTimingAPI_v4"];
    if (!action || !get || !set) { reply(nil, @"Final Cut Pro did not let Nyans read the frame"); return; }
    id ms = request[@"maxSide"];
    NSInteger maxSide = [ms respondsToSelector:@selector(integerValue)] ? [ms integerValue] : 1920;
    maxSide = MIN(MAX(maxSide, (NSInteger)256), (NSInteger)4096);

    NyansGrab *old = [self currentGrab];
    if (old && !old.done) [self finishGrab:old capture:nil error:@"A newer Grab frame took over"];

    CMTime now = [action currentTime];
    [action startAction:self];
    int current = 0;
    [get getIntValue:&current fromParameter:kNyansParam_FrameRequest atTime:now];
    double fps = 0;
    if (timing) {
        NSInteger num = [timing timelineFpsNumeratorForEffect:self], den = [timing timelineFpsDenominatorForEffect:self];
        if (num > 0 && den > 0) fps = (double)num / (double)den;
    }
    NyansGrab *g = [[NyansGrab alloc] init];
    g.token = (current < 0 || current >= 999999999) ? 1 : current + 1;
    g.timed = CMTIME_IS_NUMERIC(now);
    g.playhead = g.timed ? CMTimeGetSeconds(now) : 0;
    g.tolerance = fps > 0 ? 0.5 / fps : 1.0 / 120.0;
    g.fps = fps;
    g.maxSide = maxSide;
    g.reply = reply;
    os_unfair_lock_lock(&_grabLock);
    _grab = g;   // (before the change, so the render it causes finds the request)
    os_unfair_lock_unlock(&_grabLock);
    BOOL ok = [set setIntValue:g.token toParameter:kNyansParam_FrameRequest atTime:now];
    [action endAction:self];
    if (!ok) { [self finishGrab:g capture:nil error:@"Final Cut Pro did not take the frame request"]; return; }

    __weak NyansPlugIn *weakSelf = self;
    __weak NyansGrab *weakGrab = g;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NyansGrab *pending = weakGrab;
        if (!pending || pending.done) return;
        [weakSelf finishGrab:pending capture:pending.standIn
                       error:@"Final Cut Pro did not show this clip's frame. Put the playhead over the clip with Nyans, then press Grab frame again."];
    });
}

/** (main thread) a render copied a frame for a request */
- (void)captured:(NyansCapture *)capture grab:(NyansGrab *)g {
    if (!g || g.done) return;
    if (!capture.rgba) {
        if (capture.matched) [self finishGrab:g capture:g.standIn error:capture.failure ?: @"The frame could not be copied"];
        return;
    }
    if (capture.matched) { [self finishGrab:g capture:capture error:nil]; return; }
    if (g.standIn) return;
    g.standIn = capture;   // (a nearby frame: wait a moment for the playhead frame itself)
    __weak NyansPlugIn *weakSelf = self;
    __weak NyansGrab *weakGrab = g;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NyansGrab *pending = weakGrab;
        if (pending && !pending.done) [weakSelf finishGrab:pending capture:pending.standIn error:nil];
    });
}

/** (main thread) answers the page: the frame as a PNG, or why there is none */
- (void)finishGrab:(NyansGrab *)g capture:(NyansCapture *)capture error:(NSString *)error {
    os_unfair_lock_lock(&_grabLock);
    BOOL already = g.done;
    g.done = YES;
    if (_grab == g) _grab = nil;
    os_unfair_lock_unlock(&_grabLock);
    if (already) return;
    void (^reply)(NSDictionary *, NSString *) = g.reply;
    g.reply = nil;
    g.standIn = nil;
    if (!reply) return;
    if (!capture.rgba) { reply(nil, error ?: @"Final Cut Pro did not send the frame"); return; }
    NSString *name = NyFrameName(capture.timeSec, g.fps);
    NSString *note = capture.matched ? nil : @"Final Cut Pro sent a nearby frame. If it is not the one, put the playhead on the frame and press Grab frame again.";
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        size_t len = 0;
        uint8_t *png = ny_png_rgb(capture.rgba.bytes, capture.width, capture.height, (size_t)capture.width * 4, &len);
        NSString *base64 = png ? [[NSData dataWithBytesNoCopy:png length:len freeWhenDone:YES] base64EncodedStringWithOptions:0] : nil;
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!base64) { reply(nil, @"The frame could not be encoded"); return; }
            NSMutableDictionary *r = [NSMutableDictionary dictionaryWithDictionary:@{ @"data": base64, @"name": name }];
            if (note) r[@"note"] = note;
            reply(r, nil);
        });
    });
}

// ------------------------------------------------------------------ Apply

- (void)applyLook:(NSDictionary *)job reply:(void (^)(NSDictionary *, NSString *))reply {
    NSString *cube = [job[@"cube"] isKindOfClass:NSString.class] ? job[@"cube"] : nil;
    NSString *title = [job[@"title"] isKindOfClass:NSString.class] && [job[@"title"] length] ? job[@"title"] : @"Nyans look";
    if (!cube.length) { reply(nil, @"The look arrived empty"); return; }
    NSMutableDictionary *meta = [NSMutableDictionary dictionary];
    meta[@"v"] = @1;
    meta[@"title"] = title;
    for (NSString *k in @[ @"name", @"input", @"output" ])
        if ([job[k] isKindOfClass:NSString.class]) meta[k] = job[k];
    id spec = job[@"spec"];
    if (spec && [NSJSONSerialization isValidJSONObject:@[ spec ]]) meta[@"spec"] = spec;   // (the recipe, for a later version to reopen)
    NSISO8601DateFormatter *iso = [[NSISO8601DateFormatter alloc] init];
    meta[@"created"] = [iso stringFromDate:[NSDate date]];
    NSString *version = [[NSBundle bundleForClass:self.class] objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
    if (version) meta[@"app"] = version;

    __weak NyansPlugIn *weakSelf = self;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSString *payload = nil, *problem = nil;
        NyansLUT *lut = [NyansLUT lutWithCube:cube meta:meta payload:&payload error:&problem];
        dispatch_async(dispatch_get_main_queue(), ^{
            NyansPlugIn *s = weakSelf;
            if (!s) { reply(nil, @"The Nyans effect is no longer on this clip"); return; }
            if (!lut || !payload) { reply(nil, problem ? [@"The look could not be read: " stringByAppendingString:problem] : @"The look could not be read"); return; }
            [NyansLookStore.shared addLUT:lut];
            NSString *failure = [s storeLook:lut payload:payload title:title];
            if (failure) { reply(nil, failure); return; }
            reply(@{ @"message": @"Applied to the clip", @"note": @"The look is part of the clip now. Mix in the inspector blends it with the clip." }, nil);
        });
    });
}

- (NSString *)storeLook:(NyansLUT *)lut payload:(NSString *)payload title:(NSString *)title {
    id<NyFxAction> action = [self api:"FxCustomParameterActionAPI_v4"];
    id<NyFxParamSet> set = [self api:"FxParameterSettingAPI_v5"];
    if (!action || !set) return @"Final Cut Pro did not let Nyans change the effect";
    [action startAction:self];
    BOOL ok = [set setStringParameterValue:payload toParameter:kNyansParam_LookData];
    ok = [set setStringParameterValue:title toParameter:kNyansParam_LookTitle] && ok;
    ok = [set setStringParameterValue:lut.lookID toParameter:kNyansParam_LookID] && ok;   // (last: the id points at data that is there)
    [action endAction:self];
    if (!ok) return @"Final Cut Pro did not take the look";
    [self setTitle:title];
    return nil;
}

@end
