// NyansPlugIn.h: the Nyans effect (an FxPlug 4 tileable filter, class name NyansPlugIn in Info.plist).
//
// Parameters (their ids never change: libraries store them):
//   1  Look           the inspector row: Open Nyans, and the name of the look on the clip (a custom view)
//   2  Mix            blends the look with the clip, 0..100%
//   10 Look ID        hidden: the applied look's id ("" until a look is applied)
//   11 Look Data      hidden: the applied look, packed (the library carries the grade)
//   12 Look Title     hidden: the applied look's technical name
//   13 Frame Request  hidden: Grab frame bumps it, so Final Cut Pro renders the frame at the playhead again and the effect
//                     can copy its input
#import "NyansFx.h"

NS_ASSUME_NONNULL_BEGIN

enum {
    kNyansParam_Look = 1,
    kNyansParam_Mix = 2,
    kNyansParam_LookID = 10,
    kNyansParam_LookData = 11,
    kNyansParam_LookTitle = 12,
    kNyansParam_FrameRequest = 13,
};

@interface NyansPlugIn : NSObject

@property (nonatomic, strong, readonly, nullable) id<NyFxAPIManager> apiManager;

- (nullable instancetype)initWithAPIManager:(id<NyFxAPIManager>)apiManager;

// ---- FxTileableEffect (Final Cut Pro calls these)
- (BOOL)properties:(NSDictionary *_Nullable *_Nonnull)properties error:(NSError *_Nullable *_Nullable)error;
- (BOOL)addParametersWithError:(NSError *_Nullable *_Nullable)error;
- (BOOL)parameterChanged:(UInt32)paramID atTime:(CMTime)time error:(NSError *_Nullable *_Nullable)error;
- (BOOL)pluginState:(NSData *_Nullable *_Nonnull)pluginState atTime:(CMTime)renderTime quality:(NSUInteger)quality error:(NSError *_Nullable *_Nullable)error;
- (BOOL)destinationImageRect:(NyFxRect *)destinationImageRect
                sourceImages:(NSArray *)sourceImages
            destinationImage:(id<NyFxImageTile>)destinationImage
                 pluginState:(nullable NSData *)pluginState
                      atTime:(CMTime)renderTime
                       error:(NSError *_Nullable *_Nullable)error;
- (BOOL)sourceTileRect:(NyFxRect *)sourceTileRect
      sourceImageIndex:(NSUInteger)sourceImageIndex
          sourceImages:(NSArray *)sourceImages
   destinationTileRect:(NyFxRect)destinationTileRect
      destinationImage:(id<NyFxImageTile>)destinationImage
           pluginState:(nullable NSData *)pluginState
                atTime:(CMTime)renderTime
                 error:(NSError *_Nullable *_Nullable)error;
- (BOOL)renderDestinationImage:(id<NyFxImageTile>)destinationImage
                  sourceImages:(NSArray *)sourceImages
                   pluginState:(nullable NSData *)pluginState
                        atTime:(CMTime)renderTime
                         error:(NSError *_Nullable *_Nullable)error;
// FxCustomParameterViewHost_v2: the inspector row (the host takes ownership of the view)
- (nullable NSView *)createViewForParameterID:(UInt32)parameterID NS_RETURNS_RETAINED;

// ---- the inspector row and the window (main thread)
- (void)openPanel;
/** for the page's hello: the line next to "Final Cut Pro" */
- (NSDictionary *)hello;
/** the frame under the playhead, as the effect receives it (the clip and every effect above Nyans): a PNG for the page */
- (void)grabFrame:(NSDictionary *)request reply:(void (^)(NSDictionary *_Nullable result, NSString *_Nullable error))reply;
/** the baked look (the app's .cube and recipe) onto this clip */
- (void)applyLook:(NSDictionary *)job reply:(void (^)(NSDictionary *_Nullable result, NSString *_Nullable error))reply;

@end

NS_ASSUME_NONNULL_END
