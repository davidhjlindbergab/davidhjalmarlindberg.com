// NyansRenderer.h: the effect's GPU work. Every frame: the clip through the look's 3D LUT (tetrahedral, as the Nyans viewer
// does it), blended by Mix. When Nyans asks for the frame under the playhead, the same pass also copies the clip as it enters the
// effect (before the look) into a small 8-bit image.
#import "NyansFx.h"

NS_ASSUME_NONNULL_BEGIN

@class NyansLUT;

/** a frame Nyans asked for: the effect's input, scaled to fit maxSide */
@interface NyansCapture : NSObject
@property (nonatomic) NSInteger maxSide;
/** YES when this render is the frame at the playhead (NO: a stand-in, kept in case the playhead frame never renders) */
@property (nonatomic) BOOL matched;
/** the timeline time of the frame, in seconds */
@property (nonatomic) double timeSec;
/** filled by the render: 8-bit RGBA, top row first */
@property (nonatomic, strong, nullable) NSData *rgba;
@property (nonatomic) int width;
@property (nonatomic) int height;
@property (nonatomic, copy, nullable) NSString *failure;
@end

@interface NyansRenderer : NSObject
+ (instancetype)shared;
/** src through the LUT into dst (a straight copy when lut is nil), mixed by mix (0..1); fills capture when one is given */
- (BOOL)renderSource:(id<NyFxImageTile>)src
         destination:(id<NyFxImageTile>)dst
                 lut:(nullable NyansLUT *)lut
                 mix:(float)mix
             capture:(nullable NyansCapture *)capture
               error:(NSError *_Nullable *_Nullable)error;
@end

NS_ASSUME_NONNULL_END
