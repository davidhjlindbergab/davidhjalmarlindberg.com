// NyansHeaderView.h: the effect's row in the Final Cut Pro inspector: Open Nyans, and the name of the look on the clip.
#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@class NyansPlugIn;

@interface NyansHeaderView : NSView
- (instancetype)initWithPlugIn:(NyansPlugIn *)plugIn;
/** the applied look's name (nil or empty: none yet) */
- (void)setLookTitle:(nullable NSString *)title;
@end

NS_ASSUME_NONNULL_END
