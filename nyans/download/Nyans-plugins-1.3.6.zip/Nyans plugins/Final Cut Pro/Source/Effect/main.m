// main.m: the Nyans effect's XPC service. Final Cut Pro starts it through PlugInKit; it loads FxPlug from its own Frameworks
// folder, makes NyansPlugIn an FxTileableEffect and hands over to FxPlug's service principal, which never returns.
#import "NyansFx.h"
#import "NyansPlugIn.h"

int main(int argc, const char *argv[]) {
    @autoreleasepool {
        NSString *problem = nil;
        if (!NyFxLoadFrameworks(&problem)) {
            NSLog(@"[Nyans] %@", problem);
            return 1;
        }
        NyFxAdopt(NyansPlugIn.class, "FxTileableEffect");
    }
    NyFxStartService();
}
