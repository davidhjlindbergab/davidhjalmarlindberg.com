/* Nyans inside Final Cut Pro: the web side of the bridge. The app runs in a WKWebView in the window the Nyans effect opens inside Final Cut
   Pro; the effect (Swift, NyansWindow.swift) answers through the "nyans" script message handler and replies with window.__nyansReply.
   grab: the frame the effect receives at the playhead (its input: the clip with every effect above Nyans, before the Nyans look).
   apply: the baked grade (a 65-point LUT) goes into the effect on that clip, so Final Cut Pro renders it in the viewer and in every export.
   save: exports the app makes (a LUT zip, a still, a clip) go to ~/Movies/Nyans. */
(function () {
  'use strict';
  const mh = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.nyans;
  if (!mh) return;
  let seq = 0, statusCb = null;
  const pending = new Map();
  window.__nyansReply = function (id, ok, result) {
    const p = pending.get(id); if (!p) return;
    pending.delete(id); clearTimeout(p.timer);
    if (ok) p.resolve(result); else p.reject(new Error((result && result.message) || String(result || 'Final Cut Pro did not answer')));
  };
  window.__nyansStatus = function (text) { if (statusCb) statusCb(text || ''); };
  function call(type, payload, ms) {
    return new Promise((resolve, reject) => {
      const id = 'f' + (++seq) + '_' + Date.now().toString(36);
      const timer = setTimeout(() => { pending.delete(id); reject(new Error('Final Cut Pro did not answer in time')); }, ms || 60000);
      pending.set(id, { resolve, reject, timer });
      mh.postMessage({ id, type, payload: payload || {} });
    });
  }
  const b64 = buf => { const u = new Uint8Array(buf); let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); };
  window.NyansHost = {
    name: 'Final Cut Pro',
    applyLabel: 'Apply to clip',
    defaults: { output: 'rec709a' },   // (Final Cut Pro shows Rec.709 on a Mac with Apple's display gamma: the viewer here matches it)
    targets: [],
    autoGrab: true,
    async grabFrame() {
      const r = await call('grab', { maxSide: 1920 }, 30000);
      return { data: r.data, type: 'image/png', name: r.name, note: r.note };
    },
    applyLook(job) { return call('apply', job, 120000); },
    async saveFile(name, blob) { return call('save', { name, data: b64(await blob.arrayBuffer()) }, 600000); },
    /** the page to buy a licence: a link the panel hands to the default browser (the licence check itself uses fetch) */
    async openUrl(url) { const a = document.createElement('a'); a.href = url; document.body.appendChild(a); a.click(); a.remove(); return true; },
    onStatus(cb) { statusCb = cb; call('hello', {}, 15000).then(r => { if (r && r.status) cb(r.status); }).catch(() => {}); },
  };
})();
