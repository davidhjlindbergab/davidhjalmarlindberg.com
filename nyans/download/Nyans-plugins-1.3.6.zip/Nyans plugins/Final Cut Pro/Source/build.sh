#!/bin/bash
# Rebuilds the two programs of Nyans for Final Cut Pro from this folder (Effect/ and App/) on a Mac, into the app next to it,
# then run "Install Nyans for Final Cut Pro.command" to install that app.
# Needs Apple's command line tools (xcode-select --install). The FxPlug SDK is not needed: the effect loads Final Cut Pro's
# FxPlug at run time. If the SDK is installed, this also checks the FxPlug constants Nyans uses against its headers.
set -euo pipefail
cd "$(dirname "$0")"
APP="${1:-../Nyans for Final Cut Pro.app}"
EFFECT="$APP/Contents/PlugIns/NyansEffect.pluginkit"
[ -d "$APP" ] || { echo "The app was not found at $APP (pass its path as the first argument)."; exit 1; }
xcrun --find clang >/dev/null 2>&1 || { echo "Install Apple's command line tools first: xcode-select --install"; exit 1; }

FLAGS=(-fobjc-arc -O2 -Wall -Wno-unused-parameter -arch arm64 -arch x86_64 -mmacosx-version-min=13.0)
echo "Building the effect"
xcrun clang "${FLAGS[@]}" -framework Cocoa -framework WebKit -framework Metal -framework CoreMedia -lz \
  -Wl,-rpath,@executable_path/../Frameworks -o "$EFFECT/Contents/MacOS/NyansEffect" \
  Effect/main.m Effect/NyansFx.m Effect/NyansPlugIn.m Effect/NyansLook.m Effect/NyansRenderer.m Effect/NyansPanel.m \
  Effect/NyansHeaderView.m Effect/nyans_core.c
cp Effect/NyansShaders.metal "$EFFECT/Contents/Resources/NyansShaders.metal"
echo "Building the app"
xcrun clang "${FLAGS[@]}" -framework Cocoa -o "$APP/Contents/MacOS/Nyans" App/main.m

# (with the FxPlug SDK installed: are the numbers in Effect/NyansFx.h the SDK's?)
SDKF="/Library/Developer/SDKs/FxPlug.sdk/Library/Frameworks"
if [ -d "$SDKF/FxPlug.framework" ] || [ -d "/Library/Developer/Frameworks/FxPlug.framework/Headers" ]; then
  TMP="$(mktemp -d)"
  if xcrun clang -fobjc-arc -F "$SDKF" -F /Library/Developer/Frameworks -I Effect -o "$TMP/check" check_constants.m -framework Foundation 2>"$TMP/err"; then
    "$TMP/check" || true
  else
    echo "(the FxPlug constants check did not compile; see $TMP/err)"
  fi
fi
echo "Built. Now run \"Install Nyans for Final Cut Pro.command\"."
