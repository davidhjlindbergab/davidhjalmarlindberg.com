// check_constants.m: compares the FxPlug numbers Nyans hard-codes (Effect/NyansFx.h) with the FxPlug SDK's headers.
// build.sh runs it when the SDK is installed. Headers only: nothing here links FxPlug.
#import <Foundation/Foundation.h>
#import <FxPlug/FxPlugSDK.h>
#import "NyansFx.h"

#define CHECK(sdk, nyans)                                                                                                      \
    do {                                                                                                                       \
        unsigned long a = (unsigned long)(sdk), b = (unsigned long)(nyans);                                                    \
        if (a != b) { printf("MISMATCH %-40s SDK %lu, Nyans %lu\n", #sdk, a, b); bad++; }                                      \
    } while (0)

int main(void) {
    int bad = 0;
    CHECK(kFxParameterFlag_DEFAULT, NyFxFlag_DEFAULT);
    CHECK(kFxParameterFlag_NOT_ANIMATABLE, NyFxFlag_NOT_ANIMATABLE);
    CHECK(kFxParameterFlag_HIDDEN, NyFxFlag_HIDDEN);
    CHECK(kFxParameterFlag_CUSTOM_UI, NyFxFlag_CUSTOM_UI);
    CHECK(kFxImageColorInfo_RGB_GAMMA_VIDEO, NyFxImageColorInfo_RGB_GAMMA_VIDEO);
    CHECK(kFxImageOrigin_BOTTOM_LEFT, NyFxImageOrigin_BOTTOM_LEFT);
    CHECK(sizeof(FxRect), sizeof(NyFxRect));
    if (bad) printf("%d FxPlug constants differ: fix Effect/NyansFx.h and build again.\n", bad);
    else printf("The FxPlug constants Nyans uses match the SDK.\n");
    return bad;
}
