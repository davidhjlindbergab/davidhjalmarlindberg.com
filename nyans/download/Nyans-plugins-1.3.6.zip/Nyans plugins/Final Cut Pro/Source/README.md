# Nyans for Final Cut Pro: how it is built

The same Nyans app as the web version runs inside Final Cut Pro, in a window Final Cut Pro opens for the effect. The look you
apply is rendered by Final Cut Pro itself, in the viewer, in background renders and in every export.

## The pieces

| | |
|---|---|
| `Nyans for Final Cut Pro.app` | A small Mac app. Opening it checks the installation and puts the effect template in place. It carries the effect. |
| `…/Contents/PlugIns/NyansEffect.pluginkit` | The effect: an FxPlug 4 tileable filter (class `NyansPlugIn`) running out of process, as all FxPlug 4 effects do. |
| `…/NyansEffect.pluginkit/Contents/Resources/nyans/index.html` | The Nyans app: the v2 engine, the interface and `bridge.js`, built by `build.js` (variant `fcp`). |
| `…/Contents/Resources/Motion Templates/Nyans/Nyans.moef` | The Final Cut effect template. Final Cut Pro lists FxPlug effects only through such Motion templates; this one wraps the effect and publishes its Look row and Mix. |
| `Install Nyans for Final Cut Pro.command` | Copies the app to Applications, copies Final Cut Pro's own `FxPlug.framework` and `PluginManager.framework` into the effect, signs everything for this Mac, installs the template and registers the effect. |

## In Final Cut Pro

1. Effects browser › Nyans › drag **Nyans** onto a clip.
2. Video inspector › **Open Nyans**. Final Cut Pro opens a window with the Nyans app; it reads the frame under the playhead.
3. Generate, pick, refine, then **Apply to clip**. The inspector shows the look's name; **Mix** blends it with the clip.

Closing the window keeps the session (looks, variations, refinements) for the next Open Nyans, for the two most recent clips.
Exports from the app (LUT zip, stills, clips) go to `Movies/Nyans`.

## How it works

- **Grab frame**: the page asks the effect; the effect bumps its hidden *Frame Request* parameter (in an action of its own),
  so Final Cut Pro renders the frame at the playhead again. That render carries the new value in its state, and the effect
  copies its input (the clip with every effect above Nyans, before the look) into an 8-bit image of at most 1920 pixels,
  sends it to the page as a PNG with no colour tag, and the page takes it like an opened still. Renders of other frames stand
  in only if the playhead frame never renders (the page says so).
- **Apply**: the page bakes the grade (the whole v2 chain, 65 points) and sends its `.cube`. The effect stores it losslessly
  at 16 bits in the hidden *Look Data* parameter (about 0.7 MB, so the library carries the grade), its id in *Look ID* and its
  name in *Look Title*. A frame's render state carries only the id; the LUT is read from the clip once per process.
- **Render**: Metal, one pass: the clip through the LUT with tetrahedral interpolation (as the Nyans viewer does it), mixed by
  Mix. The effect asks for gamma-encoded video (`kFxImageColorInfo_RGB_GAMMA_VIDEO`): in a Rec.709 library these are the
  clip's own code values, so the LUT sees what the app graded. In a wide-gamut library they are Rec.2020; the shader takes
  them to Rec.709 for the LUT and back. The app's output defaults to Rec.709-A, which is how Final Cut Pro shows Rec.709 on
  a Mac.
- **No FxPlug SDK at build time.** The effect never links FxPlug. `main.m` loads the two frameworks from the effect's own
  Frameworks folder (the installer copies them from Final Cut Pro), makes `NyansPlugIn` adopt `FxTileableEffect`, and starts
  FxPlug's service principal. Every FxPlug class, protocol and constant is looked up by name at run time (`NyansFx.h/.m`); the
  few numbers FxPlug keeps in its headers are written out in `NyansFx.h`, and `check_constants.m` compares them with the SDK
  when it is installed.

## Files

| File | |
|---|---|
| `Effect/main.m` | the XPC service's entry point |
| `Effect/NyansFx.h/.m` | the FxPlug interface Nyans uses, under Nyans' own names, and the run-time loading |
| `Effect/NyansPlugIn.h/.m` | the effect: parameters, render state, render, Grab frame, Apply |
| `Effect/NyansRenderer.h/.m`, `Effect/NyansShaders.metal` | Metal (the shaders compile at run time on the GPU Final Cut Pro uses) |
| `Effect/NyansLook.h/.m`, `Effect/nyans_core.h/.c` | the `.cube` reader, the lossless LUT packing, the look id, the PNG writer |
| `Effect/NyansPanel.h/.m` | the window and the page (WKWebView) and the page's requests |
| `Effect/NyansHeaderView.h/.m` | the inspector row: Open Nyans and the look's name |
| `App/main.m` | the app |
| `bridge.js` | the page's side (`window.NyansHost` for Final Cut Pro) |
| `build.sh` | rebuilds both programs on a Mac with Apple's command line tools (`xcode-select --install`) |

## Building

`build.js` cross-compiles both programs as universal binaries (arm64 and x86_64, macOS 13 or later) with clang and lld
against a macOS SDK (`NYANS_MACOS_SDK=/path/to/MacOSX.sdk node build.js`), assembles the app and writes the template.
On a Mac, `./build.sh` rebuilds the programs into the app next to this folder.

## When something does not work

- The effect logs to Console with the prefix `[Nyans]` (process `NyansEffect`).
- `pluginkit -m -v -i com.nyans.fcp.effect` shows whether macOS knows the effect.
- If Final Cut Pro's window stays empty, `defaults write com.nyans.fcp.effect NyansOwnWindow -bool YES` makes the effect open
  a window of its own instead (`defaults delete com.nyans.fcp.effect NyansOwnWindow` undoes it).
- Safari's Develop menu can inspect the page (macOS 13.3 or later).

Ids that must never change: the effect's FxPlug UUID `A049BF24-92E4-41C9-BE18-72EDC6592D72`, its group
`25F8412F-E83E-45BD-BB3E-3E3093E4B319`, and the parameter ids in `NyansPlugIn.h`.
