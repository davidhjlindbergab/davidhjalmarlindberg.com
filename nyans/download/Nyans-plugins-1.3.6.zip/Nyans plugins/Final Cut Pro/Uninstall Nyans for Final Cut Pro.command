#!/bin/bash
# Removes Nyans for Final Cut Pro: the app, the Final Cut effect template and the effect's registration.
# Clips that wear a Nyans look keep their settings in the library; they show without the look until Nyans is installed again.
set -u
TEMPLATES="$HOME/Movies/Motion Templates.localized/Effects.localized/Nyans"
echo ""
echo "Removing Nyans for Final Cut Pro"
/usr/bin/pkill -x "Nyans" >/dev/null 2>&1
/usr/bin/pkill -x "NyansEffect" >/dev/null 2>&1
for D in "/Applications/Nyans for Final Cut Pro.app" "$HOME/Applications/Nyans for Final Cut Pro.app"; do
  if [ -d "$D" ]; then
    /usr/bin/pluginkit -r "$D/Contents/PlugIns/NyansEffect.pluginkit" >/dev/null 2>&1
    rm -rf "$D" && echo "Removed $D"
  fi
done
[ -d "$TEMPLATES" ] && rm -rf "$TEMPLATES" && echo "Removed the effect template"
echo ""
echo "Done. Quit and reopen Final Cut Pro."
read -r -p "Press Return to close."
