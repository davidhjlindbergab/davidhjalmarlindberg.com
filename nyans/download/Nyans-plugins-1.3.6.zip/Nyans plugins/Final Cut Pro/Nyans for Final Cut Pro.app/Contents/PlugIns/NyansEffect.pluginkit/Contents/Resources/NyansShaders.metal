// NyansShaders.metal: compiled by the effect at run time (Metal's own compiler, on the GPU Final Cut Pro renders with).
//
// nyans_fs: one pass per frame. The clip as it enters the effect, through the look's 3D LUT with tetrahedral interpolation (the
// interpolation the Nyans viewer uses), mixed with the clip by Mix. Final Cut Pro hands the effect gamma-encoded values in its
// working space (the effect asks for gamma video); in a wide-gamut library they are Rec.2020, so they go to Rec.709 for the LUT
// and back. Alpha is premultiplied: the colour is graded unpremultiplied.
// nyans_cap: the frame Nyans asks for (Grab frame), scaled down with a 2x2 box per output pixel, as 8-bit Rec.709.
#include <metal_stdlib>
using namespace metal;

struct NyV {
    float4 pos [[position]];
};

// one triangle that covers the viewport
vertex NyV nyans_vs(uint vid [[vertex_id]]) {
    float2 p = float2(float((vid << 1) & 2u), float(vid & 2u));
    NyV o;
    o.pos = float4(p * 2.0 - 1.0, 0.0, 1.0);
    return o;
}

struct NyU {
    float mix;    // 0..1
    uint size;    // LUT points per axis (0: no look)
    uint wide;    // 1: Rec.2020 working space
    uint pad;
};

struct NyC {
    float rx;     // source pixels per output pixel
    float ry;
    float srcW;
    float srcH;
    uint flipY;   // 1: the frame's rows run bottom-up
    uint wide;
    uint pad0;
    uint pad1;
};

constant float NY_GAMMA = 1.961;   // (Final Cut Pro shows Rec.709 with the Mac's display gamma: the looks are made for it)

static float3 nyDec(float3 c) { return sign(c) * pow(abs(c), float3(NY_GAMMA)); }
static float3 nyEnc(float3 c) { return sign(c) * pow(abs(c), float3(1.0 / NY_GAMMA)); }

static float3 nyTo709(float3 c) {
    float3 l = nyDec(c);
    return nyEnc(float3(dot(float3( 1.6605, -0.5876, -0.0728), l),
                        dot(float3(-0.1246,  1.1329, -0.0083), l),
                        dot(float3(-0.0182, -0.1006,  1.1187), l)));
}

static float3 nyTo2020(float3 c) {
    float3 l = nyDec(c);
    return nyEnc(float3(dot(float3(0.6274, 0.3293, 0.0433), l),
                        dot(float3(0.0691, 0.9195, 0.0114), l),
                        dot(float3(0.0164, 0.0880, 0.8956), l)));
}

static float3 nyAt(texture3d<float, access::read> t, uint x, uint y, uint z) {
    return t.read(uint3(x, y, z)).rgb;
}

// tetrahedral interpolation in an n-point LUT (x = R, y = G, z = B)
static float3 nyTetra(texture3d<float, access::read> t, float3 c, uint n) {
    float m = float(n - 1u);
    float3 p = clamp(c, 0.0, 1.0) * m;
    float3 b = min(floor(p), float3(m - 1.0));
    uint3 i0 = uint3(b);
    uint3 i1 = i0 + 1u;
    float3 f = p - b;
    float3 c000 = nyAt(t, i0.x, i0.y, i0.z);
    float3 c111 = nyAt(t, i1.x, i1.y, i1.z);
    float3 r;
    if (f.x > f.y) {
        if (f.y > f.z) {
            r = (1.0 - f.x) * c000 + (f.x - f.y) * nyAt(t, i1.x, i0.y, i0.z) + (f.y - f.z) * nyAt(t, i1.x, i1.y, i0.z) + f.z * c111;
        } else if (f.x > f.z) {
            r = (1.0 - f.x) * c000 + (f.x - f.z) * nyAt(t, i1.x, i0.y, i0.z) + (f.z - f.y) * nyAt(t, i1.x, i0.y, i1.z) + f.y * c111;
        } else {
            r = (1.0 - f.z) * c000 + (f.z - f.x) * nyAt(t, i0.x, i0.y, i1.z) + (f.x - f.y) * nyAt(t, i1.x, i0.y, i1.z) + f.y * c111;
        }
    } else {
        if (f.z > f.y) {
            r = (1.0 - f.z) * c000 + (f.z - f.y) * nyAt(t, i0.x, i0.y, i1.z) + (f.y - f.x) * nyAt(t, i0.x, i1.y, i1.z) + f.x * c111;
        } else if (f.z > f.x) {
            r = (1.0 - f.y) * c000 + (f.y - f.z) * nyAt(t, i0.x, i1.y, i0.z) + (f.z - f.x) * nyAt(t, i0.x, i1.y, i1.z) + f.x * c111;
        } else {
            r = (1.0 - f.y) * c000 + (f.y - f.x) * nyAt(t, i0.x, i1.y, i0.z) + (f.x - f.z) * nyAt(t, i1.x, i1.y, i0.z) + f.z * c111;
        }
    }
    return r;
}

fragment float4 nyans_fs(NyV in [[stage_in]],
                         texture2d<float, access::read> src [[texture(0)]],
                         texture3d<float, access::read> lut [[texture(1)]],
                         constant NyU &u [[buffer(0)]]) {
    uint2 xy = uint2(in.pos.xy);
    float4 s = src.read(xy);
    if (u.size < 2u || u.mix <= 0.0) return s;
    float a = s.a;
    float3 c = (a > 0.00001 && a < 0.99999) ? s.rgb / a : s.rgb;
    float3 g = nyTetra(lut, u.wide != 0u ? nyTo709(c) : c, u.size);
    if (u.wide != 0u) g = nyTo2020(g);
    float3 o = mix(c, g, min(u.mix, 1.0));
    if (a < 0.99999) o *= max(a, 0.0);
    return float4(o, a);
}

fragment float4 nyans_cap(NyV in [[stage_in]],
                          texture2d<float, access::read> src [[texture(0)]],
                          constant NyC &k [[buffer(0)]]) {
    float2 p = in.pos.xy * float2(k.rx, k.ry);
    if (k.flipY != 0u) p.y = k.srcH - p.y;
    float2 q = 0.25 * float2(k.rx, k.ry);
    int2 hi = int2(int(k.srcW) - 1, int(k.srcH) - 1);
    float4 v = float4(0.0);
    for (int j = 0; j < 4; j++) {
        float2 o = float2((j & 1) != 0 ? q.x : -q.x, (j & 2) != 0 ? q.y : -q.y);
        int2 ip = clamp(int2(floor(p + o)), int2(0), hi);
        v += src.read(uint2(ip));
    }
    v *= 0.25;
    float3 rgb = k.wide != 0u ? nyTo709(v.rgb) : v.rgb;
    return float4(saturate(rgb), 1.0);
}
