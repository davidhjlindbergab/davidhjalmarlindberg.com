#!/bin/bash
# Installs Nyans for DaVinci Resolve Studio on this Mac (Workspace > Workflow Integrations > Nyans).
cd "$(dirname "$0")" || exit 1
SRC="com.nyans.resolve"
ROOT="/Library/Application Support/Blackmagic Design/DaVinci Resolve"
DEST="$ROOT/Workflow Integration Plugins"
LUT="$ROOT/LUT/Nyans"
echo ""
echo "Nyans for DaVinci Resolve Studio"
echo "Copies the plugin into Resolve's Workflow Integration Plugins folder and makes a Nyans LUT folder the plugin can write to."
echo "macOS asks for your password once."
echo ""
if [ ! -d "$SRC" ]; then echo "Run this from the folder that holds com.nyans.resolve."; read -r -p "Press Return to close."; exit 1; fi
sudo mkdir -p "$DEST" "$LUT" || exit 1
sudo rm -rf "$DEST/$SRC"
sudo cp -R "$SRC" "$DEST/" || exit 1
sudo xattr -dr com.apple.quarantine "$DEST/$SRC" 2>/dev/null
sudo chmod -R a+rX "$DEST/$SRC"
sudo chmod 777 "$LUT"
echo ""
echo "Done. Restart DaVinci Resolve Studio, then open Workspace > Workflow Integrations > Nyans."
read -r -p "Press Return to close."
