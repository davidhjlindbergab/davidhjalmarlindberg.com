@echo off
:: Installs Nyans for DaVinci Resolve Studio on this PC (Workspace > Workflow Integrations > Nyans).
net session >nul 2>&1 || (powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs" & exit /b)
set "SRC=%~dp0com.nyans.resolve"
set "ROOT=%PROGRAMDATA%\Blackmagic Design\DaVinci Resolve\Support"
set "DEST=%ROOT%\Workflow Integration Plugins"
set "LUT=%ROOT%\LUT\Nyans"
echo.
echo Nyans for DaVinci Resolve Studio
echo Copies the plugin into Resolve's Workflow Integration Plugins folder and makes a Nyans LUT folder the plugin can write to.
echo.
if not exist "%SRC%" (echo Run this from the folder that holds com.nyans.resolve. & pause & exit /b 1)
if not exist "%DEST%" mkdir "%DEST%"
if exist "%DEST%\com.nyans.resolve" rmdir /s /q "%DEST%\com.nyans.resolve"
xcopy "%SRC%" "%DEST%\com.nyans.resolve\" /e /i /y /q >nul
if not exist "%LUT%" mkdir "%LUT%"
icacls "%LUT%" /grant *S-1-5-32-545:(OI)(CI)M >nul
echo Done. Restart DaVinci Resolve Studio, then open Workspace ^> Workflow Integrations ^> Nyans.
pause
