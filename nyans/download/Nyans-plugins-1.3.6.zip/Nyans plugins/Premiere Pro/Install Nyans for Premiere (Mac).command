#!/bin/bash
# Installs Nyans for Premiere Pro (Window > UXP Plugins > Nyans) through Adobe's plugin installer.
cd "$(dirname "$0")" || exit 1
CCX="$(ls ../Nyans\ for\ Premiere\ Pro*.ccx 2>/dev/null | head -1)"
UPIA="/Library/Application Support/Adobe/Adobe Desktop Common/RemoteComponents/UPI/UnifiedPluginInstallerAgent/UnifiedPluginInstallerAgent.app/Contents/MacOS/UnifiedPluginInstallerAgent"
echo ""
echo "Nyans for Premiere Pro"
if [ -z "$CCX" ]; then echo "The .ccx file was not found next to this folder."; read -r -p "Press Return to close."; exit 1; fi
xattr -d com.apple.quarantine "$CCX" 2>/dev/null
if [ -x "$UPIA" ]; then "$UPIA" --install "$CCX"; else open "$CCX"; fi
echo ""
echo "Restart Premiere Pro, then open Window > UXP Plugins > Nyans."
read -r -p "Press Return to close."
