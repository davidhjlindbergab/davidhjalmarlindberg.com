@echo off
:: Installs Nyans for Premiere Pro (Window > UXP Plugins > Nyans) through Adobe's plugin installer.
for %%f in ("%~dp0..\Nyans for Premiere Pro*.ccx") do set "CCX=%%~ff"
set "UPIA=%CommonProgramFiles%\Adobe\Adobe Desktop Common\RemoteComponents\UPI\UnifiedPluginInstallerAgent\UnifiedPluginInstallerAgent.exe"
echo.
echo Nyans for Premiere Pro
if not defined CCX (echo The .ccx file was not found next to this folder. & pause & exit /b 1)
if exist "%UPIA%" ("%UPIA%" /install "%CCX%") else (start "" "%CCX%")
echo.
echo Restart Premiere Pro, then open Window ^> UXP Plugins ^> Nyans.
pause
