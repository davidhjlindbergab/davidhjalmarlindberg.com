/* Nyans for Premiere Pro: the panel around the app. The app runs in the WebView below; this side speaks to Premiere Pro through its UXP API.
   grab: exports the frame under the playhead of the active sequence and hands it to the app.
   apply: writes the baked grade as a .cube LUT and puts Lumetri Color on the clips, with its Look pointed at the LUT wherever Premiere's
   API takes a path for it (otherwise the LUT's location is on the clipboard for Lumetri's Browse).
   save: writes an export the app makes (a LUT zip, a still) where the user chooses. */
(function () {
  'use strict';
  const ppro = require('premierepro');
  const uxp = require('uxp');
  let fs = null; try { fs = require('fs'); } catch (e) { /* the storage API covers it */ }
  let os = null; try { os = require('os'); } catch (e) { /* derived from the data folder instead */ }
  const { localFileSystem, types, formats } = uxp.storage;
  const web = document.getElementById('nyans');
  const PART = 262144;
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // ------------------------------------------------------------------ transport (parts of at most 256K characters each way)
  let seq = 0;
  const parts = new Map();
  function send(obj) {
    const s = JSON.stringify(obj), id = 'h' + (++seq), n = Math.max(1, Math.ceil(s.length / PART));
    for (let i = 0; i < n; i++) web.postMessage({ __nyans: 1, kind: 'part', id, i, n, s: s.slice(i * PART, (i + 1) * PART) });
  }
  window.addEventListener('message', ev => {
    let m = ev.data;
    if (typeof m === 'string') { try { m = JSON.parse(m); } catch (e) { return; } }
    if (!m || m.__nyans !== 1 || m.kind !== 'part') return;
    let a = parts.get(m.id); if (!a) parts.set(m.id, a = { got: 0, s: new Array(m.n) });
    if (a.s[m.i] == null) { a.s[m.i] = m.s; a.got++; }
    if (a.got < m.n) return;
    parts.delete(m.id);
    let call; try { call = JSON.parse(a.s.join('')); } catch (e) { return; }
    if (call && call.kind === 'call') handle(call);
  });
  async function handle(c) {
    const fn = HANDLERS[c.type];
    try {
      if (!fn) throw new Error('Unknown request: ' + c.type);
      send({ __nyans: 1, kind: 'reply', id: c.id, ok: true, result: await fn(c.payload || {}) });
    } catch (e) { send({ __nyans: 1, kind: 'reply', id: c.id, ok: false, error: (e && e.message) || String(e) }); }
  }

  // ------------------------------------------------------------------ helpers
  const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  function toBase64(buf) {
    const u = new Uint8Array(buf), out = []; let i = 0;
    for (; i + 2 < u.length; i += 3) { const v = (u[i] << 16) | (u[i + 1] << 8) | u[i + 2]; out.push(B64[v >> 18] + B64[(v >> 12) & 63] + B64[(v >> 6) & 63] + B64[v & 63]); }
    if (i < u.length) { const v = (u[i] << 16) | ((i + 1 < u.length ? u[i + 1] : 0) << 8); out.push(B64[v >> 18] + B64[(v >> 12) & 63] + (i + 1 < u.length ? B64[(v >> 6) & 63] : '=') + '='); }
    return out.join('');
  }
  function fromBase64(s) {
    const L = new Int16Array(128).fill(0); for (let i = 0; i < 64; i++) L[B64.charCodeAt(i)] = i;
    s = s.replace(/[^A-Za-z0-9+/]/g, '');
    const full = Math.floor(s.length / 4), rem = s.length % 4, out = new Uint8Array(full * 3 + (rem > 1 ? rem - 1 : 0));
    let o = 0, i = 0;
    for (let q = 0; q < full; q++, i += 4) { const v = (L[s.charCodeAt(i)] << 18) | (L[s.charCodeAt(i + 1)] << 12) | (L[s.charCodeAt(i + 2)] << 6) | L[s.charCodeAt(i + 3)]; out[o++] = v >> 16; out[o++] = (v >> 8) & 255; out[o++] = v & 255; }
    if (rem > 1) { const v = (L[s.charCodeAt(i)] << 18) | (L[s.charCodeAt(i + 1)] << 12) | (rem > 2 ? L[s.charCodeAt(i + 2)] << 6 : 0); out[o++] = v >> 16; if (rem > 2) out[o++] = (v >> 8) & 255; }
    return out.buffer;
  }
  const pngComplete = buf => { if (!buf || buf.byteLength < 64) return false; const u = new Uint8Array(buf), k = u.length - 8; return u[k] === 0x49 && u[k + 1] === 0x45 && u[k + 2] === 0x4E && u[k + 3] === 0x44; };   // IEND
  function tc(t) { const s = Math.max(0, (t && t.seconds) || 0), m = Math.floor(s / 60), r = s - m * 60; return String(m).padStart(2, '0') + ':' + r.toFixed(2).padStart(5, '0'); }
  const plural = (n, w) => n + ' ' + w + (n === 1 ? '' : 's');
  async function active() {
    const project = await ppro.Project.getActiveProject(); if (!project) throw new Error('Open a project in Premiere Pro first');
    const sequence = await project.getActiveSequence(); if (!sequence) throw new Error('Open a sequence in the timeline first');
    return { project, sequence };
  }
  function transact(project, label, build) {
    let ok = false;
    project.lockedAccess(() => { ok = project.executeTransaction(ca => build(ca), label); });
    return ok;
  }
  const CLIP = ppro.Constants && ppro.Constants.TrackItemType ? ppro.Constants.TrackItemType.CLIP : 1;
  async function selectedVideoItems(sequence) {
    const sel = await sequence.getSelection(); const items = sel ? await sel.getTrackItems() : [];
    return items.filter(it => (ppro.VideoClipTrackItem ? it instanceof ppro.VideoClipTrackItem : typeof it.getComponentChain === 'function'));
  }
  async function clipAtPlayhead(sequence) {
    const t = (await sequence.getPlayerPosition()).seconds, n = await sequence.getVideoTrackCount();
    for (let i = n - 1; i >= 0; i--) {   // (the topmost clip is the one seen)
      const track = await sequence.getVideoTrack(i); if (!track) continue;
      for (const it of track.getTrackItems(CLIP, false) || []) {
        const s = (await it.getStartTime()).seconds, e = (await it.getEndTime()).seconds;
        if (t >= s && t < e && !(await it.isDisabled())) return [it];
      }
    }
    return [];
  }

  // ------------------------------------------------------------------ where the LUTs go
  function platform() { try { if (os && os.platform) return os.platform(); } catch (e) { /* below */ } return /^[A-Za-z]:[\\/]/.test(dataPath || '') ? 'win32' : 'darwin'; }
  let dataPath = null;
  async function homeDir() {
    try { if (os && os.homedir) { const h = os.homedir(); if (h) return h.replace(/\\/g, '/'); } } catch (e) { /* below */ }
    try { const d = await localFileSystem.getDataFolder(); dataPath = d.nativePath; const m = /^(\/Users\/[^/]+|[A-Za-z]:[\\/]Users[\\/][^\\/]+)/.exec(d.nativePath); if (m) return m[1].replace(/\\/g, '/'); } catch (e) { /* none */ }
    return null;
  }
  async function ensureFolder(path) {
    const url = p => 'file:' + (p.startsWith('/') ? p : '/' + p);
    const segs = path.split('/'); let cur = '';
    for (let i = 0; i < segs.length; i++) {
      cur = i === 0 ? segs[0] : cur + '/' + segs[i]; if (!cur || /^[A-Za-z]:$/.test(cur)) continue;
      let ok = false; try { const e = await localFileSystem.getEntryWithUrl(url(cur)); ok = !!(e && e.isFolder); } catch (e) { ok = false; }
      if (!ok) await localFileSystem.createEntryWithUrl(url(cur), { type: types.folder });
    }
    return localFileSystem.getEntryWithUrl(url(path));
  }
  /** Premiere's own Creative LUT folder for this user (the LUT is also listed under Lumetri > Creative > Look after a restart), else the
      plugin's data folder */
  async function saveLut(fileName, cube) {
    const home = await homeDir();
    if (home) {
      const dir = platform() === 'win32' ? home + '/AppData/Roaming/Adobe/Common/LUTs/Creative/Nyans' : home + '/Library/Application Support/Adobe/Common/LUTs/Creative/Nyans';
      try { const folder = await ensureFolder(dir); const f = await folder.createFile(fileName, { overwrite: true }); await f.write(cube, { format: formats.utf8 }); return { path: f.nativePath, listed: true }; }
      catch (e) { console.warn('Nyans: could not write to the Lumetri LUT folder', e); }
    }
    const data = await localFileSystem.getDataFolder(); const f = await data.createFile(fileName, { overwrite: true }); await f.write(cube, { format: formats.utf8 });
    return { path: f.nativePath, listed: false };
  }

  // ------------------------------------------------------------------ Lumetri
  const LUMETRI = 'AE.ADBE Lumetri';
  async function lumetriOf(chain) {
    let found = null; const n = chain.getComponentCount();
    for (let i = 0; i < n; i++) { const c = chain.getComponentAtIndex(i); try { if ((await c.getMatchName()) === LUMETRI) found = c; } catch (e) { /* skip */ } }
    return found;
  }
  async function addLumetri(project, chain) {
    const comp = await ppro.VideoFilterFactory.createComponent(LUMETRI);
    if (!transact(project, 'Nyans: add Lumetri Color', ca => ca.addAction(chain.createAppendComponentAction(comp)))) return null;
    return chain.getComponentAtIndex(chain.getComponentCount() - 1);
  }
  /** Lumetri's Look (Creative): 'free' when this Premiere takes a path for it and it holds none or a Nyans one, 'taken' when it holds
      someone else's look, 'list' when Premiere offers it only as a list (chosen by hand) */
  async function lookParam(comp) {
    const n = comp.getParamCount();
    for (let i = 0; i < n; i++) { const p = comp.getParam(i); if (p && /^look$/i.test((p.displayName || '').trim())) return p; }
    return null;
  }
  async function lookState(comp) {
    const p = await lookParam(comp); if (!p) return 'list';
    try { const v = await p.getValueAtTime(ppro.TickTime.TIME_ZERO); if (!v || typeof v.value !== 'string') return 'list'; return !v.value || /nyans/i.test(v.value) ? 'free' : 'taken'; }
    catch (e) { return 'list'; }
  }
  async function pointLook(project, comp, path) {
    const p = await lookParam(comp); if (!p) return false;
    try { const kf = p.createKeyframe(path); return transact(project, 'Nyans: Look', ca => ca.addAction(p.createSetValueAction(kf, true))); }
    catch (e) { return false; }
  }
  async function copyText(t) { try { await navigator.clipboard.setContent({ 'text/plain': t }); return true; } catch (e) { return false; } }

  // ------------------------------------------------------------------ requests
  const HANDLERS = {
    async hello() { return { status: await statusText() }; },
    async grab({ maxSide }) {
      const { sequence } = await active();
      const t = await sequence.getPlayerPosition();
      let w = 1920, h = 1080;
      try { const r = await sequence.getFrameSize(); if (r && r.width > 0 && r.height > 0) { w = r.width; h = r.height; } } catch (e) { /* the default size */ }
      const k = Math.min(1, (maxSide || 1920) / Math.max(w, h)); w = Math.max(2, Math.round(w * k / 2) * 2); h = Math.max(2, Math.round(h * k / 2) * 2);
      const tmp = await localFileSystem.getTemporaryFolder(), name = 'nyans-frame-' + Date.now() + '.png';
      if (!(await ppro.Exporter.exportSequenceFrame(sequence, t, name, tmp.nativePath, w, h))) throw new Error('Premiere Pro could not export the frame at the playhead');
      let entry = null, buf = null;
      for (let i = 0; i < 100 && !pngComplete(buf); i++) {   // (written in the background: wait for the whole file)
        try { if (!entry) entry = await tmp.getEntry(name); buf = await entry.read({ format: formats.binary }); } catch (e) { /* not there yet */ }
        if (!pngComplete(buf)) await sleep(100);
      }
      if (!pngComplete(buf)) throw new Error('The frame Premiere Pro exported could not be read');
      try { await entry.delete(); } catch (e) { /* temporary folder */ }
      const where = (sequence.name || 'the sequence') + ' at ' + tc(t);
      return { data: toBase64(buf), name: (sequence.name || 'Sequence') + ' ' + tc(t), note: 'Frame read from ' + where + '. Press Generate.' };
    },
    async apply({ name, cube, target }) {
      const { project, sequence } = await active();
      let items = target === 'playhead' ? [] : await selectedVideoItems(sequence);
      if (!items.length) items = await clipAtPlayhead(sequence);
      if (!items.length) throw new Error('Select the clips to grade, or put the playhead over one');
      const fileName = String(name || 'Nyans').replace(/[\\/:*?"<>|]+/g, '') + '.cube', lut = await saveLut(fileName, cube);
      let added = 0, pointed = 0;
      for (const it of items) {
        const chain = await it.getComponentChain();
        let lum = await lumetriOf(chain), st = lum ? await lookState(lum) : null;
        if (!lum || st === 'taken') { lum = await addLumetri(project, chain); if (lum) { added++; st = await lookState(lum); } }   // (someone's Look is never replaced)
        if (lum && st === 'free' && (await pointLook(project, lum, lut.path))) pointed++;
      }
      const clips = plural(items.length, 'clip');
      if (pointed === items.length) return { ok: true, message: 'Applied to ' + clips, note: '' };
      const copied = await copyText(lut.path);
      return {
        ok: true,
        message: (added ? 'Lumetri Color added to ' + plural(added, 'clip') : 'LUT ready for ' + clips) + '. Pick it under Look.',
        note: 'In Lumetri Color › Creative › Look, choose Browse… and pick “' + fileName + '”' + (copied ? ' (its location is on your clipboard)' : ' in ' + lut.path) + '.' +
          (lut.listed ? ' After Premiere restarts, it is also listed under Look.' : ''),
      };
    },
    async save({ name, data }) {
      const ext = (String(name).split('.').pop() || '').toLowerCase();
      const f = await localFileSystem.getFileForSaving(name, ext ? { types: [ext] } : undefined);
      if (!f) return { cancelled: true };
      await f.write(fromBase64(data), { format: formats.binary });
      return { path: f.nativePath };
    },
  };

  // ------------------------------------------------------------------ the sequence and playhead, shown in the app's bar
  async function statusText() {
    try { const p = await ppro.Project.getActiveProject(); const s = p && (await p.getActiveSequence()); if (!s) return 'no sequence'; return (s.name || 'Sequence') + '  ' + tc(await s.getPlayerPosition()); }
    catch (e) { return ''; }
  }
  let lastStatus = null;
  setInterval(async () => { const t = await statusText(); if (t !== lastStatus) { lastStatus = t; try { web.postMessage({ __nyans: 1, kind: 'status', text: t }); } catch (e) { /* not loaded yet */ } } }, 1500);

  // ------------------------------------------------------------------ the WebView fills the panel
  function fit() { web.style.width = window.innerWidth + 'px'; web.style.height = window.innerHeight + 'px'; }
  window.addEventListener('resize', fit); fit();
  window.__nyansHost = { HANDLERS, toBase64, fromBase64 };   // (for tests)
})();
