#!/bin/bash
# Installs Colobri for DaVinci Resolve Studio on this Mac (Workspace > Workflow Integrations > Colobri).
cd "$(dirname "$0")" || exit 1
SRC="com.colobri.resolve"
ROOT="/Library/Application Support/Blackmagic Design/DaVinci Resolve"
DEST="$ROOT/Workflow Integration Plugins"
LUT="$ROOT/LUT/Colobri"
echo ""
echo "Colobri for DaVinci Resolve Studio"
echo "Copies the plugin into Resolve's Workflow Integration Plugins folder and makes a Colobri LUT folder the plugin can write to."
echo "macOS asks for your password once."
echo ""
if [ ! -d "$SRC" ]; then echo "Run this from the folder that holds com.colobri.resolve."; read -r -p "Press Return to close."; exit 1; fi
sudo mkdir -p "$DEST" "$LUT" || exit 1
sudo rm -rf "$DEST/$SRC" "$DEST/com.colobri.resolve.test"
sudo cp -R "$SRC" "$DEST/" || exit 1
sudo xattr -dr com.apple.quarantine "$DEST/$SRC" 2>/dev/null
sudo chmod -R a+rX "$DEST/$SRC"
sudo chmod 777 "$LUT"
echo ""
echo "Done. Restart DaVinci Resolve Studio, then open Workspace > Workflow Integrations > Colobri."
read -r -p "Press Return to close."
