/* Colobri for Premiere Pro: the panel around the app. The app runs in a WebView this script makes; this side speaks to Premiere Pro through
   its UXP API.
   grab: exports the frame under the playhead of the active sequence and hands it to the app.
   apply: writes the baked grade as a .cube LUT and puts Lumetri Color on the clips, with its Look pointed at the LUT wherever Premiere's
   API takes a path for it (otherwise the LUT's location is on the clipboard for Lumetri's Browse).
   save: writes an export the app makes (a LUT zip, a still) where the user chooses. */
(function () {
  'use strict';
  // ------------------------------------------------------------------ what this panel did lately, for Colobri's diagnostics (Alt+Shift+D in
  // the app): UXP keeps a plugin's console to its developer tool, so the panel keeps the last lines itself
  const LOG = [];
  ['log', 'warn', 'error'].forEach(k => {
    const f = console[k] ? console[k].bind(console) : () => {};
    console[k] = (...a) => {
      try { LOG.push(new Date().toISOString().slice(11, 19) + ' ' + k + ' ' + a.map(x => (x && x.message) || (typeof x === 'object' ? JSON.stringify(x) : String(x))).join(' ').slice(0, 400)); if (LOG.length > 200) LOG.shift(); } catch (e) { /* the line is skipped */ }
      f(...a);
    };
  });
  // ------------------------------------------------------------------ the panel's menu (≡): Reload Colobri, for a view that ever stops
  // showing the app. Set up at once, as UXP asks; the panel's content stays this page.
  let reloadApp = () => {};
  try {
    require('uxp').entrypoints.setup({ panels: { colobriPanel: {
      show() { setTimeout(() => { try { guard('show'); } catch (e) { /* later */ } }, 0); },
      menuItems: [{ id: 'reload', label: 'Reload Colobri' }],
      invokeMenu(id) { if (id === 'reload') reloadApp('menu'); },
    } } });
  } catch (e) { console.warn('Colobri: no panel menu', e); }
  // ------------------------------------------------------------------ the WebView with the app. It is made first, before anything that
  // touches Premiere, so the app shows even if part of Premiere's API is missing. The panel's own text (index.html) stays visible only
  // while the app is not on screen, and says why.
  const APP = 'plugin:/app/index.html';
  const BOOT_MS = window.__nyansBootMs || 12000;   // time for the app to say it is running, before one reload and then a message
  const boot = document.getElementById('boot'), bootText = document.getElementById('bootText'), bootRetry = document.getElementById('bootRetry');
  function say(text, retry) { try { bootText.textContent = text; bootRetry.style.display = retry ? 'inline-block' : 'none'; if (boot) boot.style.display = text ? 'block' : 'none'; } catch (e) { /* no panel text */ } }
  // (UXP's WebView has no reload(), and setting the same src again does nothing: a reload is a fresh WebView in place of the old one)
  function makeWeb() {
    const w = document.createElement('webview');
    w.id = 'nyans'; w.className = 'app';
    try { w.uxpAllowInspector = 'true'; w.setAttribute('uxpAllowInspector', 'true'); } catch (e) { /* inspector is optional */ }
    w.addEventListener('loadstart', e => console.log('Colobri: loading ' + ((e && e.url) || APP)));
    w.addEventListener('loadstop', e => console.log('Colobri: loaded ' + ((e && e.url) || APP)));
    w.addEventListener('loaderror', e => {
      if (w !== web || (e && Number(e.code) === -999)) return;   // (an old WebView, or macOS cancelling a load for the next one)
      console.error('Colobri: load error', e && e.url, e && e.code, e && e.message);
      if (!ready) fail('Colobri could not open its page (' + ((e && e.message) || 'no reason given') + (e && e.code != null ? ', code ' + e.code : '') + ').');
    });
    return w;
  }
  let web = makeWeb();
  function freshWeb() {
    const old = web;
    web = makeWeb(); web.style.width = old.style.width; web.style.height = old.style.height;
    try { old.remove(); } catch (e) { try { old.parentNode.removeChild(old); } catch (err) { /* it stays hidden */ old.style.display = 'none'; } }
    web.src = APP; document.body.appendChild(web);
  }
  let ready = false, reloads = 0, watchdog = 0;
  function watch() {
    clearTimeout(watchdog);
    watchdog = setTimeout(() => {
      if (ready) return;
      if (reloads < 1) {   // (a WebView can come up blank once; a fresh one brings it)
        reloads++; console.warn('Colobri: the app did not start, opening it again');
        freshWeb(); watch(); return;
      }
      fail('Colobri did not start in this panel.');
    }, BOOT_MS);
  }
  function fail(why) {
    console.error('Colobri: ' + why);
    clearTimeout(watchdog);
    web.style.display = 'none';
    try { bootRetry.textContent = 'Try again'; } catch (e) { /* the button keeps its label */ }
    say(why + ' Press Try again, or close this panel and open it again from Window › UXP Plugins › Colobri. If it stays empty, restart Premiere Pro.', true);
  }
  let lastHeard = 0, asleep = false, restarted = '';
  function appReady() {
    lastHeard = Date.now();
    if (asleep) { asleep = false; say(''); web.style.display = ''; console.log('Colobri: the app answers again'); }
    if (ready) return;
    ready = true; clearTimeout(watchdog); say(''); web.style.display = '';   // (also after a load error that did not stop the app)
    console.log('Colobri: the app is running');
    pushStatus(true);
    if (restarted) { const why = restarted; restarted = ''; setTimeout(() => { try { web.postMessage({ __nyans: 1, kind: 'restarted', why }); } catch (e) { /* it shows without the note */ } }, 600); }
    setTimeout(() => guard('ready'), 0);
  }
  reloadApp = why => {
    console.warn('Colobri: reloading the app (' + why + ')');
    ready = false; reloads = 0; asleep = false; restarted = why; say('Opening Colobri…');
    freshWeb(); watch();
  };
  bootRetry.addEventListener('click', () => reloadApp(asleep ? 'stopped' : 'retry'));
  web.src = APP;
  document.body.appendChild(web);
  watch();

  // ------------------------------------------------------------------ the WebView's size. In a browser the stylesheet alone (html, body and
  // the WebView at 100%, index.html) fills the panel. Premiere's UXP lays heights out its own way, so the panel is also measured several
  // ways (probes pinned to its edges, the window, the document) and, when the stylesheet leaves the WebView without a size, the WebView is
  // given one of those measures in pixels. What each measure says, and what the WebView got, is kept for the diagnostics (Alt+Shift+D, or
  // three clicks on the logo), where another measure can be tried by name.
  const rectOf = el => { try { const r = el.getBoundingClientRect(); return { x: Math.round(r.left), y: Math.round(r.top), w: Math.round(r.width), h: Math.round(r.height) }; } catch (e) { return null; } };
  const pair = (w, h) => (typeof w === 'number' && typeof h === 'number' && isFinite(w) && isFinite(h) ? { x: 0, y: 0, w: Math.round(w), h: Math.round(h) } : null);
  function inner() { try { const r = pair(window.innerWidth, window.innerHeight); return r && r.w > 40 && r.h > 40 ? r : null; } catch (e) { return null; } }
  const probes = {};
  function probe(id, css) { try { const d = document.createElement('div'); d.id = 'probe-' + id; d.style.cssText = css + ';visibility:hidden;pointer-events:none'; document.body.insertBefore(d, document.body.firstChild); probes[id] = d; } catch (e) { /* that measure is missing */ } }
  probe('abs', 'position:absolute;left:0;top:0;right:0;bottom:0');
  probe('fixed', 'position:fixed;left:0;top:0;right:0;bottom:0');
  probe('vp', 'position:absolute;left:0;top:0;width:100vw;height:100vh');
  function measures() {
    const de = document.documentElement, b = document.body, m = {};
    try { m.inner = pair(window.innerWidth, window.innerHeight); } catch (e) { m.inner = null; }
    try { m.outer = pair(window.outerWidth, window.outerHeight); } catch (e) { m.outer = null; }
    try { m.docClient = pair(de.clientWidth, de.clientHeight); } catch (e) { m.docClient = null; }
    try { m.bodyClient = pair(b.clientWidth, b.clientHeight); } catch (e) { m.bodyClient = null; }
    m.html = rectOf(de); m.body = rectOf(b);
    for (const k of Object.keys(probes)) m[k] = rectOf(probes[k]);
    m.web = rectOf(web);
    return m;
  }
  const MODES = ['auto', 'css', 'inner', 'outer', 'docClient', 'bodyClient', 'html', 'body', 'abs', 'fixed', 'vp', 'vw'];
  let mode = 'auto', pinned = false, last = null;
  const ok = r => !!(r && r.w > 40 && r.h > 40);
  function guard(why) {
    if (web.style.display === 'none') return;
    const m = measures(); last = m;
    let w = '', h = '';
    if (mode === 'vw') { w = '100vw'; h = '100vh'; }
    else if (mode !== 'auto' && mode !== 'css') { if (ok(m[mode])) { w = m[mode].w + 'px'; h = m[mode].h + 'px'; } }
    else if (mode === 'auto') {
      // (1.3.1: the stylesheet, unless it leaves the WebView without a size; then the body's size, else the window's)
      if (pinned || !ok(m.web)) { const p = ok(m.body) ? m.body : inner(); if (p) { pinned = true; w = p.w + 'px'; h = p.h + 'px'; } }
    }
    if (web.style.width !== w || web.style.height !== h) {
      web.style.width = w; web.style.height = h;
      console.log('Colobri: WebView ' + (w || '100%') + ' x ' + (h || '100%') + ' (' + mode + ', ' + why + ')');
    }
    record(why, m);
  }
  function sizes() {
    let dpr = null; try { dpr = window.devicePixelRatio; } catch (e) { /* none */ }
    return Object.assign({ mode, pinned, dpr, style: [web.style.width || '', web.style.height || '', web.style.display || ''].join(' | ') }, last || measures());
  }
  // the record, for the diagnostics: the last forty changes of any measure
  const samples = []; let lastKey = '';
  function record(why, m) {
    const key = JSON.stringify(m) + mode + web.style.width + web.style.height;
    if (key === lastKey) return;
    lastKey = key;
    samples.push({ t: new Date().toISOString().slice(11, 19), why, mode, style: (web.style.width || '-') + ' x ' + (web.style.height || '-'), m });
    if (samples.length > 40) samples.shift();
  }
  window.addEventListener('resize', () => guard('resize'));
  setInterval(() => guard('poll'), 1000);
  // ------------------------------------------------------------------ the app answers the panel's pings. A view that stops answering (its
  // page gone, or held while Premiere hides the panel) gives way to the panel's own text with a Reload button; if it answers again it simply
  // comes back, so nothing is lost when it was only hidden.
  setInterval(() => {
    if (!ready || web.style.display === 'none' && !asleep) return;
    try { web.postMessage({ __nyans: 1, kind: 'ping' }); } catch (e) { /* counted as silence */ }
    if (!asleep && Date.now() - lastHeard > 16000) {
      asleep = true; console.warn('Colobri: the app has not answered for ' + Math.round((Date.now() - lastHeard) / 1000) + ' s');
      web.style.display = 'none'; say('Colobri stopped showing in this panel. Press Reload to open it again: the frame is read again from your playhead.', true);
      try { bootRetry.textContent = 'Reload'; } catch (e) { /* the button keeps its label */ }
    }
  }, 4000);

  // ------------------------------------------------------------------ Premiere and UXP
  let ppro = null, premiereError = '';
  try { ppro = require('premierepro'); } catch (e) { premiereError = (e && e.message) || String(e); console.error('Colobri: Premiere Pro\'s plugin API is not available', e); }
  const uxp = require('uxp');
  let fs = null; try { fs = require('fs'); } catch (e) { /* the storage API covers it */ }
  let os = null; try { os = require('os'); } catch (e) { /* derived from the data folder instead */ }
  const { localFileSystem, types, formats } = uxp.storage;
  const PART = 262144;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let HANDLERS = {};

  // ------------------------------------------------------------------ transport (parts of at most 256K characters each way)
  let seq = 0;
  const parts = new Map();
  function send(obj) {
    const s = JSON.stringify(obj), id = 'h' + (++seq), n = Math.max(1, Math.ceil(s.length / PART));
    for (let i = 0; i < n; i++) web.postMessage({ __nyans: 1, kind: 'part', id, i, n, s: s.slice(i * PART, (i + 1) * PART) });
  }
  window.addEventListener('message', ev => {
    let m = ev.data;
    if (typeof m === 'string') { try { m = JSON.parse(m); } catch (e) { return; } }
    if (!m || m.__nyans !== 1) return;
    appReady();   // (any message from the app means it is running)
    if (m.kind !== 'part') return;
    let a = parts.get(m.id); if (!a) parts.set(m.id, a = { got: 0, s: new Array(m.n) });
    if (a.s[m.i] == null) { a.s[m.i] = m.s; a.got++; }
    if (a.got < m.n) return;
    parts.delete(m.id);
    let call; try { call = JSON.parse(a.s.join('')); } catch (e) { return; }
    if (call && call.kind === 'call') handle(call);
  });
  async function handle(c) {
    try {
      if (!ppro && !['hello', 'http', 'open', 'store', 'looks', 'pick', 'save', 'copy', 'diag', 'sizing'].includes(c.type)) throw new Error('Premiere Pro\'s plugin API is not available here (' + premiereError + '). Colobri needs Premiere Pro 25.6 or later.');
      const fn = HANDLERS[c.type];
      if (!fn) throw new Error('Unknown request: ' + c.type);
      send({ __nyans: 1, kind: 'reply', id: c.id, ok: true, result: await fn(c.payload || {}) });
    } catch (e) { send({ __nyans: 1, kind: 'reply', id: c.id, ok: false, error: (e && e.message) || String(e) }); }
  }

  // ------------------------------------------------------------------ helpers
  const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  function toBase64(buf) {   // (in pieces of 48K bytes, a multiple of 3, so the pieces join into one base64 text; a 4K frame is tens of MB)
    const u = new Uint8Array(buf), n = u.length, CH = 49152, out = [];
    for (let o = 0; o < n; o += CH) {
      const end = Math.min(n, o + CH);
      if (typeof btoa === 'function') { let s = ''; for (let i = o; i < end; i += 8192) s += String.fromCharCode.apply(null, u.subarray(i, Math.min(end, i + 8192))); out.push(btoa(s)); continue; }
      const q = []; let i = o;
      for (; i + 2 < end; i += 3) { const v = (u[i] << 16) | (u[i + 1] << 8) | u[i + 2]; q.push(B64[v >> 18] + B64[(v >> 12) & 63] + B64[(v >> 6) & 63] + B64[v & 63]); }
      if (i < end) { const v = (u[i] << 16) | ((i + 1 < end ? u[i + 1] : 0) << 8); q.push(B64[v >> 18] + B64[(v >> 12) & 63] + (i + 1 < end ? B64[(v >> 6) & 63] : '=') + '='); }
      out.push(q.join(''));
    }
    return out.join('');
  }
  function fromBase64(s) {
    const L = new Int16Array(128).fill(0); for (let i = 0; i < 64; i++) L[B64.charCodeAt(i)] = i;
    s = s.replace(/[^A-Za-z0-9+/]/g, '');
    const full = Math.floor(s.length / 4), rem = s.length % 4, out = new Uint8Array(full * 3 + (rem > 1 ? rem - 1 : 0));
    let o = 0, i = 0;
    for (let q = 0; q < full; q++, i += 4) { const v = (L[s.charCodeAt(i)] << 18) | (L[s.charCodeAt(i + 1)] << 12) | (L[s.charCodeAt(i + 2)] << 6) | L[s.charCodeAt(i + 3)]; out[o++] = v >> 16; out[o++] = (v >> 8) & 255; out[o++] = v & 255; }
    if (rem > 1) { const v = (L[s.charCodeAt(i)] << 18) | (L[s.charCodeAt(i + 1)] << 12) | (rem > 2 ? L[s.charCodeAt(i + 2)] << 6 : 0); out[o++] = v >> 16; if (rem > 2) out[o++] = (v >> 8) & 255; }
    return out.buffer;
  }
  /** 'image/png' or 'image/jpeg' when buf is a whole image of that kind (written to its end), else null */
  function wholeImage(buf) {
    if (!buf || buf.byteLength < 64) return null;
    const u = new Uint8Array(buf), n = u.length;
    if (u[0] === 0x89 && u[1] === 0x50 && u[2] === 0x4E && u[3] === 0x47) return u[n - 8] === 0x49 && u[n - 7] === 0x45 && u[n - 6] === 0x4E && u[n - 5] === 0x44 ? 'image/png' : null;   // IEND
    if (u[0] === 0xFF && u[1] === 0xD8) return u[n - 2] === 0xFF && u[n - 1] === 0xD9 ? 'image/jpeg' : null;   // EOI
    return null;
  }
  // ------------------------------------------------------------------ the frame under the playhead
  // Premiere's Exporter writes the frame in the background (its promise says only that the export started), and some versions put the
  // extension on twice ("….png.png"). So the frame goes to a folder of Colobri's own, is found by the start of its name, and is read once
  // it is whole.
  const listed = async folder => { try { return (await folder.getEntries()) || []; } catch (e) { return []; } };
  async function framesFolder() {
    const data = await localFileSystem.getDataFolder();
    let f = null;
    try { f = await data.getEntry('frames'); } catch (e) { f = null; }
    if (!f || !f.isFolder) f = await data.createFolder('frames');
    return { folder: f, parent: data };
  }
  /** sizes: [[w, h], …] tried in turn (a smaller frame first, then the sequence's own size), each given its time to arrive */
  async function exportFrame(sequence, t, sizes) {
    const { folder, parent } = await framesFolder();
    for (const e of await listed(folder)) if (!e.isFolder) { try { await e.delete(); } catch (err) { /* removed next time */ } }   // (earlier grabs)
    // (the folder without a closing separator, as Adobe's own example passes it: if Premiere joins it to the name without one, the file
    // lands beside the folder, named "frames…", and is found there too)
    const dir = folder.nativePath, sep = dir.indexOf('\\') >= 0 ? '\\' : '/', into = dir.endsWith(sep) ? dir.slice(0, -1) : dir;
    const bases = []; let seen = [], said = false;
    for (let k = 0; k < sizes.length; k++) {
      const [w, h] = sizes[k], base = 'nyans-frame-' + Date.now() + '-' + k;
      let ok = false;
      try { ok = await ppro.Exporter.exportSequenceFrame(sequence, t, base + '.png', into, w, h); }
      catch (e) { console.warn('Colobri: exportSequenceFrame ' + w + 'x' + h + ' failed', e); }
      console.log('Colobri: exportSequenceFrame ' + w + 'x' + h + ' to ' + into + ' -> ' + ok);
      if (!ok) continue;
      said = true; bases.push(base);
      const t0 = Date.now(), wait = k === sizes.length - 1 ? 30000 : 8000;
      while (Date.now() - t0 < wait) {
        const mine = e => bases.some(b => String(e.name).indexOf(b) >= 0);
        const found = (await listed(folder)).concat((await listed(parent)).filter(mine));   // (also beside the folder)
        seen = found.map(e => e.name);
        for (const e of found) {
          if (e.isFolder) continue;
          let buf = null; try { buf = await e.read({ format: formats.binary }); } catch (err) { buf = null; }
          const type = wholeImage(buf);
          if (type) { try { await e.delete(); } catch (err) { /* removed on the next grab */ } return { buf, type }; }
        }
        await sleep(150);
      }
    }
    if (!said) throw new Error('Premiere Pro could not export the frame at the playhead. Put the playhead over a clip in the active sequence and press Grab frame again.');
    console.error('Colobri: no frame from Premiere Pro in ' + into + ' (there: ' + (seen.join(', ') || 'nothing') + ')');
    throw new Error('Premiere Pro did not write the frame. Press Grab frame again. If it keeps happening, export the frame with the camera button under the Program monitor and open it in Colobri.');
  }
  function tc(t) { const s = Math.max(0, (t && t.seconds) || 0), m = Math.floor(s / 60), r = s - m * 60; return String(m).padStart(2, '0') + ':' + r.toFixed(2).padStart(5, '0'); }
  const plural = (n, w) => n + ' ' + w + (n === 1 ? '' : 's');
  async function active() {
    const project = await ppro.Project.getActiveProject(); if (!project) throw new Error('Open a project in Premiere Pro first');
    const sequence = await project.getActiveSequence(); if (!sequence) throw new Error('Open a sequence in the timeline first');
    return { project, sequence };
  }
  function transact(project, label, build) {
    let ok = false;
    project.lockedAccess(() => { ok = project.executeTransaction(ca => build(ca), label); });
    return ok;
  }
  const CLIP = ppro && ppro.Constants && ppro.Constants.TrackItemType ? ppro.Constants.TrackItemType.CLIP : 1;
  async function selectedVideoItems(sequence) {
    const sel = await sequence.getSelection(); const items = sel ? await sel.getTrackItems() : [];
    return items.filter(it => (ppro.VideoClipTrackItem ? it instanceof ppro.VideoClipTrackItem : typeof it.getComponentChain === 'function'));
  }
  async function clipAtPlayhead(sequence) {
    const t = (await sequence.getPlayerPosition()).seconds, n = await sequence.getVideoTrackCount();
    for (let i = n - 1; i >= 0; i--) {   // (the topmost clip is the one seen)
      const track = await sequence.getVideoTrack(i); if (!track) continue;
      for (const it of track.getTrackItems(CLIP, false) || []) {
        const s = (await it.getStartTime()).seconds, e = (await it.getEndTime()).seconds;
        if (t >= s && t < e && !(await it.isDisabled())) return [it];
      }
    }
    return [];
  }

  // ------------------------------------------------------------------ where the LUTs go
  function platform() { try { if (os && os.platform) return os.platform(); } catch (e) { /* below */ } return /^[A-Za-z]:[\\/]/.test(dataPath || '') ? 'win32' : 'darwin'; }
  let dataPath = null;
  async function homeDir() {
    try { if (os && os.homedir) { const h = os.homedir(); if (h) return h.replace(/\\/g, '/'); } } catch (e) { /* below */ }
    try { const d = await localFileSystem.getDataFolder(); dataPath = d.nativePath; const m = /^(\/Users\/[^/]+|[A-Za-z]:[\\/]Users[\\/][^\\/]+)/.exec(d.nativePath); if (m) return m[1].replace(/\\/g, '/'); } catch (e) { /* none */ }
    return null;
  }
  async function ensureFolder(path) {
    const url = p => 'file:' + (p.startsWith('/') ? p : '/' + p);
    const segs = path.split('/'); let cur = '';
    for (let i = 0; i < segs.length; i++) {
      cur = i === 0 ? segs[0] : cur + '/' + segs[i]; if (!cur || /^[A-Za-z]:$/.test(cur)) continue;
      let ok = false; try { const e = await localFileSystem.getEntryWithUrl(url(cur)); ok = !!(e && e.isFolder); } catch (e) { ok = false; }
      if (!ok) await localFileSystem.createEntryWithUrl(url(cur), { type: types.folder });
    }
    return localFileSystem.getEntryWithUrl(url(path));
  }
  /** Premiere's own Creative LUT folder for this user (the LUT is also listed under Lumetri > Creative > Look after a restart), else the
      plugin's data folder */
  async function saveLut(fileName, cube) {
    const home = await homeDir();
    if (home) {
      const dir = platform() === 'win32' ? home + '/AppData/Roaming/Adobe/Common/LUTs/Creative/Colobri' : home + '/Library/Application Support/Adobe/Common/LUTs/Creative/Colobri';
      try { const folder = await ensureFolder(dir); const f = await folder.createFile(fileName, { overwrite: true }); await f.write(cube, { format: formats.utf8 }); return { path: f.nativePath, listed: true }; }
      catch (e) { console.warn('Colobri: could not write to the Lumetri LUT folder', e); }
    }
    const data = await localFileSystem.getDataFolder(); const f = await data.createFile(fileName, { overwrite: true }); await f.write(cube, { format: formats.utf8 });
    return { path: f.nativePath, listed: false };
  }

  // ------------------------------------------------------------------ Lumetri
  const LUMETRI = 'AE.ADBE Lumetri';
  async function lumetriOf(chain) {
    let found = null; const n = chain.getComponentCount();
    for (let i = 0; i < n; i++) { const c = chain.getComponentAtIndex(i); try { if ((await c.getMatchName()) === LUMETRI) found = c; } catch (e) { /* skip */ } }
    return found;
  }
  async function addLumetri(project, chain) {
    const comp = await ppro.VideoFilterFactory.createComponent(LUMETRI);
    if (!transact(project, 'Colobri: add Lumetri Color', ca => ca.addAction(chain.createAppendComponentAction(comp)))) return null;
    return chain.getComponentAtIndex(chain.getComponentCount() - 1);
  }
  /** Lumetri's Look (Creative). Premiere's API shows it either as a path (a Look Colobri can set) or, as in Premiere 25 and 26, as the
      position in Lumetri's own list of looks, which only lists the LUTs it found when it started; a look Colobri just made is never in it.
      'free' when it holds no look (or a Colobri one), 'taken' when it holds someone's look, 'unknown' when it cannot be read. */
  async function lookParam(comp) {
    const n = comp.getParamCount();
    for (let i = 0; i < n; i++) { const p = comp.getParam(i); if (p && /^look$/i.test((p.displayName || '').trim())) return p; }
    return null;
  }
  async function lookValue(p) { try { const v = await p.getValueAtTime(ppro.TickTime.TIME_ZERO); return v ? v.value : undefined; } catch (e) { return undefined; } }
  async function lookState(comp) {
    const p = await lookParam(comp); if (!p) return 'unknown';
    const v = await lookValue(p);
    if (typeof v === 'string') return !v || /colobri/i.test(v) ? 'free' : 'taken';
    if (typeof v === 'number') return v === 0 ? 'free' : 'taken';   // (the list's first entry is None)
    return 'unknown';
  }
  /** points a Lumetri's Look at the LUT, where this Premiere takes a path for it; true only when it reads back as that LUT */
  let lookTries = [];
  async function pointLook(project, comp, path) {
    const p = await lookParam(comp); if (!p) { lookTries = ['no Look parameter']; return false; }
    lookTries = [];
    for (const v of [path, 'file://' + (path.startsWith('/') ? '' : '/') + path.replace(/\\/g, '/')]) {
      let kf;
      try { kf = p.createKeyframe(v); } catch (e) { lookTries.push('createKeyframe("' + v.slice(-40) + '"): ' + ((e && e.message) || e)); continue; }
      let ok = false;
      try { ok = transact(project, 'Colobri: Look', ca => ca.addAction(p.createSetValueAction(kf, true))); } catch (e) { lookTries.push('set: ' + ((e && e.message) || e)); continue; }
      const back = await lookValue(p);
      lookTries.push('set ' + (ok ? 'ok' : 'refused') + ', reads back ' + JSON.stringify(back));
      if (ok && typeof back === 'string' && back.replace(/\\/g, '/').toLowerCase().endsWith(path.replace(/\\/g, '/').toLowerCase().split('/').pop())) return true;
    }
    return false;
  }
  /** what Premiere shows of a Lumetri Color: each parameter's name and the kind of value it holds (for the diagnostics) */
  let lumetriSeen = null;
  async function describe(comp) {
    const out = []; let n = 0;
    try { n = comp.getParamCount(); } catch (e) { return [{ error: (e && e.message) || String(e) }]; }
    for (let i = 0; i < Math.min(n, 160); i++) {
      try {
        const p = comp.getParam(i), v = await lookValue(p);
        out.push([i, (p && p.displayName) || '', v === undefined ? 'unreadable' : Array.isArray(v) ? 'point' : typeof v, typeof v === 'string' ? v.slice(-60) : typeof v === 'number' ? Math.round(v * 1000) / 1000 : '']);
      } catch (e) { out.push([i, '?', 'error', (e && e.message) || String(e)]); }
    }
    return out;
  }
  async function copyText(t) { try { await navigator.clipboard.setContent({ 'text/plain': t }); return true; } catch (e) { return false; } }

  // ------------------------------------------------------------------ the licence's notes, in the data folder (licence.json)
  let notes = null, notesWrite = Promise.resolve();
  async function readNotes() {
    if (notes) return notes;
    try { const f = await (await localFileSystem.getDataFolder()).getEntry('licence.json'); notes = JSON.parse(await f.read({ format: formats.utf8 })) || {}; }
    catch (e) { notes = {}; }
    if (typeof notes !== 'object' || Array.isArray(notes)) notes = {};
    return notes;
  }
  function writeNotes(all) {   // (one write at a time, each with everything)
    notesWrite = notesWrite.then(async () => {
      const f = await (await localFileSystem.getDataFolder()).createFile('licence.json', { overwrite: true });
      await f.write(JSON.stringify(all), { format: formats.utf8 });
    }).catch(e => console.warn('Colobri: could not keep the licence notes', e));
    return notesWrite;
  }

  // ------------------------------------------------------------------ saved looks: one file for the user, outside any project, shared with
  // Colobri in DaVinci Resolve on this computer (~/Library/Application Support/Colobri/looks.json, %APPDATA%\Colobri\looks.json); the plugin's own
  // data folder if that folder cannot be written
  const validLook = r => !!(r && typeof r.id === 'string' && r.look && r.look.v === 2 && r.look.base && r.look.grade && r.look.post);
  let looksWrite = Promise.resolve(), looksAt = null;
  async function looksFile(create) {
    if (looksAt) return create ? looksAt.folder.createFile('looks.json', { overwrite: true }) : looksAt.folder.getEntry('looks.json');
    const home = await homeDir();
    if (home) {
      const dir = platform() === 'win32' ? home + '/AppData/Roaming/Colobri' : home + '/Library/Application Support/Colobri';
      try { looksAt = { folder: await ensureFolder(dir) }; } catch (e) { console.warn('Colobri: saved looks stay in the plugin\'s folder', e); }
    }
    if (!looksAt) looksAt = { folder: await localFileSystem.getDataFolder() };
    return looksFile(create);
  }
  async function readLooks() {
    try { const f = await looksFile(false); const j = JSON.parse(await f.read({ format: formats.utf8 })); return (j && Array.isArray(j.looks) ? j.looks : []).filter(validLook); }
    catch (e) { return []; }
  }
  function changeLooks(fn) {   // (one change at a time, each on the file as it is now: Colobri in Resolve may have written it meanwhile)
    const job = looksWrite.then(async () => {
      const list = fn(await readLooks());
      const f = await looksFile(true);
      await f.write(JSON.stringify({ nyans: 'looks', v: 1, looks: list }), { format: formats.utf8 });
      return list;
    });
    looksWrite = job.catch(() => {});
    return job;
  }

  // ------------------------------------------------------------------ requests
  HANDLERS = {
    /** saved looks: list, put (add or replace by id), remove */
    async looks({ op, rec, id }) {
      if (op === 'list') return { list: await readLooks() };
      if (op === 'put') {
        if (!validLook(rec)) throw new Error('That is not a Colobri look');
        return { list: await changeLooks(list => { const i = list.findIndex(r => r.id === rec.id); if (i >= 0) list[i] = rec; else list.unshift(rec); return list; }) };
      }
      if (op === 'remove') return { list: await changeLooks(list => list.filter(r => r.id !== id)) };
      throw new Error('Unknown looks request');
    },
    /** a file the user picks (Open, Import a look): Premiere's own dialog, since the WebView's file field may not open one */
    async pick({ types }) {
      const opts = Array.isArray(types) && types.length ? { types } : undefined;
      const f = await localFileSystem.getFileForOpening(opts);
      if (!f) return { cancelled: true };
      const buf = await f.read({ format: formats.binary });
      return { name: f.name, data: toBase64(buf) };
    },
    async hello() { return { status: await statusText() }; },
    /** the licence check: Lemon Squeezy's licence API only */
    async http({ url, body }) {
      if (!/^https:\/\/api\.lemonsqueezy\.com\/v1\/licenses\/(activate|validate|deactivate)$/.test(String(url))) throw new Error('Colobri talks only to Lemon Squeezy here');
      const r = await fetch(url, { method: 'POST', headers: { Accept: 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' }, body: String(body || '') });
      return { status: r.status, text: await r.text() };
    },
    /** what the licence keeps between sessions (the trial's start, the key): Premiere's WebView has no localStorage for a plugin's own
        page, so the panel keeps it, in the plugin's data folder */
    async store({ op, k, v }) {
      const all = await readNotes();
      if (op === 'all') return { all };
      if (op !== 'set' || typeof k !== 'string' || !/^nyans\./.test(k)) throw new Error('Unknown store request');
      if (v == null) delete all[k]; else all[k] = String(v);
      await writeNotes(all);
      return { ok: true };
    },
    /** the page to buy a licence, in the default browser */
    async open({ url }) {
      if (!/^https:\/\/davidhjalmarlindberg\.com\//.test(String(url))) throw new Error('Colobri opens only its own pages');
      await uxp.shell.openExternal(url, 'Colobri opens the page where you can buy a licence.');
      return { opened: true };
    },
    async grab({ maxSide }) {
      const { sequence } = await active();
      const t = await sequence.getPlayerPosition();
      let w = 1920, h = 1080;
      try { const r = await sequence.getFrameSize(); if (r && r.width > 0 && r.height > 0) { w = r.width; h = r.height; } } catch (e) { /* the default size */ }
      const k = Math.min(1, (maxSide || 1920) / Math.max(w, h)), sw = Math.max(2, Math.round(w * k / 2) * 2), sh = Math.max(2, Math.round(h * k / 2) * 2);
      const got = await exportFrame(sequence, t, sw === w && sh === h ? [[w, h]] : [[sw, sh], [w, h]]);   // (the sequence's own size if a smaller one never comes)
      const where = (sequence.name || 'the sequence') + ' at ' + tc(t);
      return { data: toBase64(got.buf), type: got.type, name: (sequence.name || 'Sequence') + ' ' + tc(t), note: 'Frame read from ' + where + '. Press Generate.' };
    },
    async apply({ name, cube, target }) {
      const { project, sequence } = await active();
      let items = target === 'playhead' ? [] : await selectedVideoItems(sequence);
      if (!items.length) items = await clipAtPlayhead(sequence);
      if (!items.length) throw new Error('Select the clips to grade, or put the playhead over one');
      const fileName = String(name || 'Colobri').replace(/[\\/:*?"<>|]+/g, '') + '.cube', lut = await saveLut(fileName, cube);
      let added = 0, pointed = 0, withLum = 0;
      for (const it of items) {
        const chain = await it.getComponentChain();
        let lum = await lumetriOf(chain), st = lum ? await lookState(lum) : null;
        if (!lum || st === 'taken') { lum = await addLumetri(project, chain); if (lum) { added++; st = await lookState(lum); } }   // (someone's Look is never replaced)
        if (!lum) continue;
        withLum++;
        if (st !== 'taken' && (await pointLook(project, lum, lut.path))) pointed++;
        else if (!lumetriSeen) { lumetriSeen = { state: st, tries: lookTries.slice(), params: await describe(lum) }; console.log('Colobri: Lumetri\'s Look could not be set: ' + lookTries.join(' / ')); }
      }
      const clips = plural(items.length, 'clip');
      if (!withLum) throw new Error('Premiere Pro did not take Lumetri Color on ' + (items.length === 1 ? 'that clip' : 'those clips') + '. Try again, or add Lumetri Color yourself and choose the LUT under Look.');
      if (pointed === items.length) return { ok: true, message: 'Applied to ' + clips, note: '' };
      // Premiere offers Lumetri's Look to plugins only as its own list of looks, so the last step is a Browse in Lumetri
      const copied = await copyText(lut.path), mac = platform() !== 'win32';
      return {
        ok: true, pending: true,
        message: 'Lumetri Color is on ' + plural(withLum, 'clip') + '. One step left: load the look into it',
        guide: {
          title: 'Load the look in Lumetri Color',
          why: 'Premiere doesn’t let plugins pick the file in Lumetri’s Look, so this one is yours.',
          steps: [
            'In Effect Controls, open Lumetri Color › Creative.',
            'Under Look, choose Browse…',
            mac ? 'Press ⌘⇧G, paste with ⌘V, press Return, then Open.' : 'Paste with Ctrl+V into File name and press Enter.',
          ],
          path: lut.path, file: fileName, copied,
          after: lut.listed ? 'After Premiere restarts, Colobri looks are also in the Look list.' : '',
        },
        note: 'In Lumetri Color › Creative › Look, choose Browse… and pick “' + fileName + '”' + (copied ? ' (its location is on your clipboard)' : ' in ' + lut.path) + '.',
      };
    },
    /** copies a text (the LUT's location, again) */
    async copy({ text }) { return { copied: await copyText(String(text || '')) }; },
    /** the WebView's sizing, by one measure of the panel (from the diagnostics) */
    async sizing({ mode: m }) { if (!MODES.includes(m)) throw new Error('Unknown sizing ' + m); mode = m; pinned = false; console.log('Colobri: sizing mode ' + mode); guard('mode'); return { sizes: sizes(), modes: MODES }; },
    /** what Colobri's diagnostics show: the panel's sizes, its last lines, what Premiere shows of Lumetri */
    async diag() {
      let versions = {}, host = {}; try { versions = Object.assign({}, uxp.versions || {}); } catch (e) { /* none */ }
      try { host = { name: uxp.host && uxp.host.name, version: uxp.host && uxp.host.version, locale: uxp.host && uxp.host.uiLocale }; } catch (e) { /* none */ }
      return { versions, host, platform: platform(), sizes: sizes(), modes: MODES, samples: samples.slice(-12), log: LOG.slice(-80), lumetri: lumetriSeen };
    },
    async save({ name, data }) {
      const ext = (String(name).split('.').pop() || '').toLowerCase();
      const f = await localFileSystem.getFileForSaving(name, ext ? { types: [ext] } : undefined);
      if (!f) return { cancelled: true };
      await f.write(fromBase64(data), { format: formats.binary });
      return { path: f.nativePath };
    },
  };

  // ------------------------------------------------------------------ the sequence and playhead, shown in the app's bar
  async function statusText() {
    if (!ppro) return '';
    try { const p = await ppro.Project.getActiveProject(); const s = p && (await p.getActiveSequence()); if (!s) return 'no sequence'; return (s.name || 'Sequence') + '  ' + tc(await s.getPlayerPosition()); }
    catch (e) { return ''; }
  }
  let lastStatus = null;
  async function pushStatus(force) {
    const t = await statusText();
    if (t === lastStatus && !force) return;
    lastStatus = t;
    if (ready) { try { web.postMessage({ __nyans: 1, kind: 'status', text: t }); } catch (e) { /* the page is reloading */ } }
  }
  setInterval(() => { pushStatus(false); }, 1500);
  window.__nyansHost = { HANDLERS, toBase64, fromBase64, state: () => ({ ready, reloads, asleep, pinned, mode, shown: web.style.display !== 'none', text: bootText ? bootText.textContent : '', boot: boot ? boot.style.display : '' }), fail, reloadApp: why => reloadApp(why), guard, sizes, quiet: ms => { lastHeard = Date.now() - ms; } };   // (for tests)
})();
