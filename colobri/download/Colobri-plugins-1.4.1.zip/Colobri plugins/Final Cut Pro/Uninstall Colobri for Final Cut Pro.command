#!/bin/bash
# Removes Colobri for Final Cut Pro: the app, the Final Cut effect template and the effect's registration.
# Clips that wear a Colobri look keep their settings in the library; they show without the look until Colobri is installed again.
set -u
TEMPLATES="$HOME/Movies/Motion Templates.localized/Effects.localized/Colobri"
echo ""
echo "Removing Colobri for Final Cut Pro"
/usr/bin/pkill -x "Colobri" >/dev/null 2>&1
/usr/bin/pkill -x "ColobriEffect" >/dev/null 2>&1
for D in "/Applications/Colobri for Final Cut Pro.app" "$HOME/Applications/Colobri for Final Cut Pro.app"; do
  if [ -d "$D" ]; then
    /usr/bin/pluginkit -r "$D/Contents/PlugIns/ColobriEffect.pluginkit" >/dev/null 2>&1
    rm -rf "$D" && echo "Removed $D"
  fi
done
[ -d "$TEMPLATES" ] && rm -rf "$TEMPLATES" && echo "Removed the effect template"
echo ""
echo "Done. Quit and reopen Final Cut Pro."
read -r -p "Press Return to close."
