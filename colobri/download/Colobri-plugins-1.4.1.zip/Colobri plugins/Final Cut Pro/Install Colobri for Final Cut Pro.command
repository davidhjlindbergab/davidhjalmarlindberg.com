#!/bin/bash
# Installs Colobri for Final Cut Pro on this Mac:
#   - the app "Colobri for Final Cut Pro" (it carries the Colobri effect) in Applications
#   - Final Cut Pro's own FxPlug frameworks copied into the effect, and the effect signed for this Mac
#   - the Final Cut effect template in Movies > Motion Templates > Effects > Colobri
#   - the effect registered with macOS, so Final Cut Pro finds it
# Nothing in Final Cut Pro itself is changed.
set -u
cd "$(dirname "$0")" || exit 1
HERE="$(pwd)"
NAME="Colobri for Final Cut Pro.app"
SRC="$HERE/$NAME"
EFFECT_REL="Contents/PlugIns/ColobriEffect.pluginkit"
TEMPLATES="$HOME/Movies/Motion Templates.localized/Effects.localized/Colobri"
LSREGISTER="/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"

say() { printf '%s\n' "$1"; }
fail() {
  printf '\nColobri was not installed: %s\n\n' "$1" >&2
  /usr/bin/osascript -e "display alert \"Colobri was not installed\" message \"$1\"" >/dev/null 2>&1
  read -r -p "Press Return to close."
  exit 1
}

say ""
say "Colobri for Final Cut Pro"
say ""

# ---- this Mac
OS="$(/usr/bin/sw_vers -productVersion 2>/dev/null)"
case "$OS" in 1[3-9].*|2[0-9].*) ;; *) fail "Colobri needs macOS 13 Ventura or later (this Mac runs ${OS:-an unknown version})." ;; esac
[ -d "$SRC" ] || fail "\"$NAME\" was not found next to this installer. Keep the folder together and run it again."

FCP=""
for ID in com.apple.FinalCut com.apple.FinalCutTrial; do
  [ -z "$FCP" ] && FCP="$(/usr/bin/mdfind "kMDItemCFBundleIdentifier == '$ID'" 2>/dev/null | grep -v '/Volumes/' | head -1)"
done
[ -z "$FCP" ] && [ -d "/Applications/Final Cut Pro.app" ] && FCP="/Applications/Final Cut Pro.app"

# ---- FxPlug: Final Cut Pro's own copy (else the FxPlug SDK's)
FW=""
if [ -n "$FCP" ] && [ -d "$FCP/Contents/Frameworks/FxPlug.framework" ] && [ -d "$FCP/Contents/Frameworks/PluginManager.framework" ]; then
  FW="$FCP/Contents/Frameworks"
elif [ -d "/Library/Developer/Frameworks/FxPlug.framework" ] && [ -d "/Library/Developer/Frameworks/PluginManager.framework" ]; then
  FW="/Library/Developer/Frameworks"
fi
[ -n "$FCP" ] || fail "Final Cut Pro was not found on this Mac. Install it, open it once, then run this installer again."
[ -n "$FW" ] || fail "Final Cut Pro's FxPlug frameworks were not found. Update Final Cut Pro, then run this installer again."
say "Final Cut Pro: $FCP"
if /usr/bin/pgrep -x "Final Cut Pro" >/dev/null 2>&1 || /usr/bin/pgrep -x "Final Cut Pro Trial" >/dev/null 2>&1; then
  say "(Final Cut Pro is open. Quit it after this and open it again, so it finds Colobri.)"
fi

# ---- the app
if [ -w "/Applications" ]; then DEST_DIR="/Applications"; else DEST_DIR="$HOME/Applications"; mkdir -p "$DEST_DIR" || fail "Could not make $DEST_DIR."; fi
DEST="$DEST_DIR/$NAME"
/usr/bin/pkill -x "Colobri" >/dev/null 2>&1
/usr/bin/pkill -x "ColobriEffect" >/dev/null 2>&1
if [ -d "$DEST" ]; then rm -rf "$DEST" || fail "Could not replace the earlier $DEST."; fi
/usr/bin/ditto "$SRC" "$DEST" || fail "Could not copy the app to $DEST_DIR."
/usr/bin/xattr -dr com.apple.quarantine "$DEST" 2>/dev/null
chmod 755 "$DEST/Contents/MacOS/Colobri" "$DEST/$EFFECT_REL/Contents/MacOS/ColobriEffect" 2>/dev/null
say "App:           $DEST"

# ---- the effect: FxPlug inside it, then everything signed for this Mac (from the inside out)
FWD="$DEST/$EFFECT_REL/Contents/Frameworks"
mkdir -p "$FWD" || fail "Could not make the effect's Frameworks folder."
for F in PluginManager FxPlug; do
  rm -rf "$FWD/$F.framework"
  /usr/bin/ditto "$FW/$F.framework" "$FWD/$F.framework" || fail "Could not copy $F.framework."
done
for F in PluginManager FxPlug; do
  /usr/bin/codesign --force --sign - --timestamp=none "$FWD/$F.framework" >/dev/null 2>&1 || fail "Could not sign $F.framework."
done
/usr/bin/codesign --force --sign - --timestamp=none "$DEST/$EFFECT_REL" >/dev/null 2>&1 || fail "Could not sign the Colobri effect."
/usr/bin/codesign --force --sign - --timestamp=none "$DEST" >/dev/null 2>&1 || fail "Could not sign the app."
/usr/bin/codesign --verify --deep --strict "$DEST" >/dev/null 2>&1 || fail "The installed app did not pass macOS's signature check."
say "Effect:        signed for this Mac, with FxPlug from $FW"

# ---- the Final Cut effect template
mkdir -p "$TEMPLATES" || fail "Could not make $TEMPLATES."
rm -rf "$TEMPLATES/Colobri"
/usr/bin/ditto "$DEST/Contents/Resources/Motion Templates/Colobri" "$TEMPLATES/Colobri" || fail "Could not copy the effect template."
/usr/bin/xattr -dr com.apple.quarantine "$TEMPLATES/Colobri" 2>/dev/null
say "Template:      Movies/Motion Templates/Effects/Colobri"

# ---- registration
[ -x "$LSREGISTER" ] && "$LSREGISTER" -f "$DEST" >/dev/null 2>&1
/usr/bin/pluginkit -a "$DEST/$EFFECT_REL" >/dev/null 2>&1
sleep 1
if /usr/bin/pluginkit -m -i com.colobri.fcp.effect 2>/dev/null | grep -q "com.colobri.fcp.effect"; then
  say "Registered:    yes"
else
  say "Registered:    macOS registers it when the app opens"
fi
/usr/bin/open "$DEST"

say ""
say "Done. Open Final Cut Pro (quit and reopen it if it was running), choose Effects > Colobri and drag Colobri onto a clip."
say "Then click Open Colobri in the Video inspector."
say ""
read -r -p "Press Return to close."
