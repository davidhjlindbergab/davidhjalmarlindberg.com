@echo off
:: Installs Colobri for Premiere Pro (Window > UXP Plugins > Colobri) through Adobe's plugin installer.
for %%f in ("%~dp0..\Colobri for Premiere Pro*.ccx") do set "CCX=%%~ff"
for %%f in ("%~dp0Colobri for Premiere Pro*.ccx") do set "CCX=%%~ff"
set "UPIA=%CommonProgramFiles%\Adobe\Adobe Desktop Common\RemoteComponents\UPI\UnifiedPluginInstallerAgent\UnifiedPluginInstallerAgent.exe"
echo.
echo Colobri for Premiere Pro
if not defined CCX (echo The .ccx file was not found next to this installer. Keep the folder together and run it again. & pause & exit /b 1)
if exist "%UPIA%" ("%UPIA%" /install "%CCX%") else (start "" "%CCX%")
echo.
echo Restart Premiere Pro, then open Window ^> UXP Plugins ^> Colobri.
pause
