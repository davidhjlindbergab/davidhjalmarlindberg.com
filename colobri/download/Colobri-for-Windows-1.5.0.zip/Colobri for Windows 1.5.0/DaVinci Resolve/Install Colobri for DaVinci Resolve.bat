@echo off
:: Installs Colobri for DaVinci Resolve Studio on this PC (Workspace > Workflow Integrations > Colobri).
:: It copies into Resolve's folder for every user of this PC, so it asks Windows for permission first (fltmc runs only with it).
if "%~1"=="elevated" goto admin
fltmc >nul 2>&1 && goto admin
set "SELF=%~f0"
powershell -NoProfile -Command "try { Start-Process -FilePath $env:SELF -ArgumentList 'elevated' -Verb RunAs -ErrorAction Stop } catch { exit 1 }"
if errorlevel 1 (
  echo.
  echo Colobri needs your permission to install into the DaVinci Resolve folder.
  echo Run this installer again and choose Yes when Windows asks.
  echo.
  pause
)
exit /b
:admin
set "SRC=%~dp0com.colobri.resolve"
set "ROOT=%PROGRAMDATA%\Blackmagic Design\DaVinci Resolve\Support"
set "DEST=%ROOT%\Workflow Integration Plugins"
set "LUT=%ROOT%\LUT\Colobri"
echo.
echo Colobri for DaVinci Resolve Studio
echo Copies the plugin into Resolve's Workflow Integration Plugins folder and makes a Colobri LUT folder the plugin can write to.
echo.
if not exist "%SRC%" (echo Run this from the folder that holds com.colobri.resolve. & pause & exit /b 1)
if not exist "%DEST%" mkdir "%DEST%"
if exist "%DEST%\com.colobri.resolve.test" rmdir /s /q "%DEST%\com.colobri.resolve.test"
if exist "%DEST%\com.colobri.resolve" rmdir /s /q "%DEST%\com.colobri.resolve"
xcopy "%SRC%" "%DEST%\com.colobri.resolve\" /e /i /y /q >nul
if not exist "%LUT%" mkdir "%LUT%"
icacls "%LUT%" /grant *S-1-5-32-545:(OI)(CI)M >nul
echo Done. Restart DaVinci Resolve Studio, then open Workspace ^> Workflow Integrations ^> Colobri.
pause
