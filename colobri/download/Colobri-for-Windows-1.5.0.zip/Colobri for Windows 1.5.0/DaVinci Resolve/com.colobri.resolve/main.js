// Colobri for DaVinci Resolve Studio: the plugin's window (Workspace > Workflow Integrations > Colobri).
// The window runs with Node so the app can speak to Resolve through WorkflowIntegration.node (see bridge.js in index.html).
const { app, BrowserWindow } = require('electron');
const path = require('path');
try { app.allowRendererProcessReuse = false; } catch (e) { /* (older Electron: lets the window load Resolve's native module) */ }
let win = null;
function open() {
  win = new BrowserWindow({
    width: 1440, height: 900, minWidth: 820, minHeight: 600, useContentSize: true, backgroundColor: '#121212', title: 'Colobri', show: false,
    webPreferences: { nodeIntegration: true, contextIsolation: false, sandbox: false, backgroundThrottling: false },
  });
  win.once('ready-to-show', () => win.show());
  win.loadFile(path.join(__dirname, 'index.html'));
  win.on('closed', () => { win = null; app.quit(); });
}
app.on('ready', open);
app.on('window-all-closed', () => app.quit());
